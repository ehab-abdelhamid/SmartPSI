/*
 * GraphX.cpp
 *
 *  Created on: Mar 13, 2013
 *      Author: ehab
 */

#include <tr1/unordered_set>
#include <tr1/unordered_map>
#include<iostream>
#include<fstream>
#include<sstream>
#include <algorithm>
#include <vector>
#include <stdlib.h>
#include <sys/time.h>
#include "GraphX.h"
#include "EdgeX.h"
#include "utils.h"
#include "FastExistenceList.h"
#include "TimeUtility.h"
#include "Features.h"
#include "Statistics.h"

//int GraphX::numIterations = 0;
int GraphX::numIsSatisfied = 0;
long GraphX::time4IstSatisfied = 0;

/**
 * put the selected node in an earlier position
 */
bool putInEarlierPosition(NodeX* selectedNode, int*list, int listSize) {
	int selectedQNID = selectedNode->getID();

	//get its old position
	int oldPosition = 0;
	for(;oldPosition<listSize;oldPosition++) {
		if(list[oldPosition]==selectedQNID) {
			break;
		}
	}

	//get the new position if we can move it to an earlier position
	int newPosition = 1;
	for(;newPosition<oldPosition;newPosition++) {
		if(selectedNode->getEdgeForDestNode(list[newPosition-1])!=NULL)
			break;
	}

	//if we can, move it
	if(newPosition<oldPosition) {
		for(int i=oldPosition;i>newPosition;i--) {
			list[i] = list[i-1];
		}
		list[newPosition] = selectedQNID;
	}
	//otherwise, try to move one of its direct neighbors
	else {
		bool b = false;

		for(map<int, void*>::iterator iter = selectedNode->getEdgesIterator();iter!=selectedNode->getEdgesEndIterator();iter++) {
			EdgeX* edge = (EdgeX*)iter->second;
			NodeX* otherNode = edge->getOtherNode();
			int pos = 0;
			for(;pos<oldPosition;pos++) {
				if(list[pos]==otherNode->getID()) {
					break;
				}
			}

			if(pos<oldPosition) {
				b = putInEarlierPosition(otherNode, list, listSize);
				break;
			}
		}

		//if one of the preceding nodes can be made earlier
		if(b) {
			return putInEarlierPosition(selectedNode, list, listSize);
		}
		else
			return false;
	}

	return true;
}

/**
 * put the selected node in a later position
 */
bool putInLaterPosition(NodeX* selectedNode, int*list, int listSize, GraphX* queryGraph) {
	int selectedQNID = selectedNode->getID();

	//get its old position
	int oldPosition = 0;
	for(;oldPosition<listSize;oldPosition++) {
		if(list[oldPosition]==selectedQNID) {
			break;
		}
	}

	//get the new position if we can move it to a later position
	int newPosition = oldPosition+1;
	bool canMove = false;
	for(;newPosition<listSize;newPosition++) {
		//if the current node (at new position) is connected to the selected node
		if(selectedNode->getEdgeForDestNode(list[newPosition])!=NULL)
		{
			bool b = false;
			NodeX* currentNode = queryGraph->getNodeWithID(list[newPosition]);

			for(int i=0;i<oldPosition;i++)
			{
				if(currentNode->getEdgeForDestNode(list[i])!=NULL)
				{
					b = true;
					break;
				}
			}

			if(!b)
				break;
		}
		canMove = true;
	}
	if(newPosition==listSize) newPosition--;

	//if we can, move it
	if(canMove) {
		for(int i=oldPosition;i<newPosition;i++) {
			list[i] = list[i+1];
		}
		list[newPosition] = selectedQNID;

		return true;
	}

	return false;
}

bool checkCurrentStatus(GraphX* graph1, GraphX* graph2, vector<Set_Iterator* >& currentS, int* nodesOrder, tr1::unordered_map<int, int>& selectedQueryMap)
{
	NodeX* dataGraphNode = graph2->getNodeWithID(*(currentS[currentS.size()-1]->it));
	NodeX* queryGraphNode = graph1->getNodeWithID(nodesOrder[currentS.size()-1]);

	for(map<int, void*>::iterator iter = queryGraphNode->getEdgesIterator();iter!=queryGraphNode->getEdgesEndIterator();++iter)
	{
		int otherNodeID = iter->first;
		EdgeX* edge = (EdgeX*)(iter->second);

		if(selectedQueryMap.find(otherNodeID)==selectedQueryMap.end())
			continue;

		//get the data node that the current data node should be connected with
		//cout<<"dataGraphNode:"<<dataGraphNode->getID()<<", queryGraphNode:"<<queryGraphNode->getID()<<endl;
		//cout<<otherNodeID<<","<<selectedQueryMap.find(otherNodeID)->second<<endl;
		int dataNodeID = *(currentS[selectedQueryMap.find(otherNodeID)->second]->it);

		//check the current graph edges, whether it has a connection to dataNodeID or not
		//cout<<"checking node connection:"<<dataGraphNode->getID()<<" with "<<dataNodeID<<endl;
		if(!dataGraphNode->isItConnectedWithNodeID(dataNodeID, edge->getLabel()))
		{
			//cout<<"false"<<endl;
			return false;
		}
	}

	return true;
}

bool checkCurrentStatus_Fast_2(GraphX* graph1, GraphX* graph2, vector<Edge_Iterator* >& currentS, int* nodesOrder, int* selectedQueryMap)
{
	NodeX* dataGraphNode = currentS[currentS.size()-1]->getCurrentNode();
	NodeX* queryGraphNode = graph1->getNodeWithID(nodesOrder[currentS.size()-1]);

	for(map<int, void*>::iterator iter = queryGraphNode->getEdgesIterator();iter!=queryGraphNode->getEdgesEndIterator();++iter)
	{
		int otherNodeID = iter->first;
		EdgeX* edge = (EdgeX*)(iter->second);

		if(selectedQueryMap[otherNodeID]==-1)
			continue;

		//get the data node that the current data node should be connected with
		//cout<<"dataGraphNode:"<<dataGraphNode->getID()<<", queryGraphNode:"<<queryGraphNode->getID()<<endl;
		//cout<<otherNodeID<<","<<selectedQueryMap.find(otherNodeID)->second<<endl;
		int dataNodeID = (currentS[selectedQueryMap[otherNodeID]]->getCurrentNode())->getID();

		//check the current graph edges, whether it has a connection to dataNodeID or not
		//cout<<"checking node connection:"<<dataGraphNode->getID()<<" with "<<dataNodeID<<endl;
		if(!dataGraphNode->isItConnectedWithNodeID(dataNodeID, edge->getLabel()))
		{
			//cout<<"false"<<endl;
			return false;
		}
	}

	return true;
}

bool checkCurrentStatus_Fast(GraphX* graph1, GraphX* graph2, vector<Set_Nodes_Iterator* >& currentS, int* nodesOrder, int* selectedQueryMap)
{
	NodeX* dataGraphNode = *(currentS[currentS.size()-1]->it);
	NodeX* queryGraphNode = graph1->getNodeWithID(nodesOrder[currentS.size()-1]);

	for(map<int, void*>::iterator iter = queryGraphNode->getEdgesIterator();iter!=queryGraphNode->getEdgesEndIterator();++iter)
	{
		int otherNodeID = iter->first;
		EdgeX* edge = (EdgeX*)(iter->second);

		if(selectedQueryMap[otherNodeID]==-1)
			continue;

		//get the data node that the current data node should be connected with
		//cout<<"dataGraphNode:"<<dataGraphNode->getID()<<", queryGraphNode:"<<queryGraphNode->getID()<<endl;
		//cout<<otherNodeID<<","<<selectedQueryMap.find(otherNodeID)->second<<endl;
		int dataNodeID = (*(currentS[selectedQueryMap[otherNodeID]]->it))->getID();

		//check the current graph edges, whether it has a connection to dataNodeID or not
		//cout<<"checking node connection:"<<dataGraphNode->getID()<<" with "<<dataNodeID<<endl;
		if(!dataGraphNode->isItConnectedWithNodeID(dataNodeID, edge->getLabel()))
		{
			//cout<<"false"<<endl;
			return false;
		}
	}

	return true;
}

bool checkCurrentStatus_Fast(GraphX* graph1, GraphX* graph2, vector<Set_Nodes_Prioritized_Iterator* >& currentS, int* nodesOrder, int* selectedQueryMap, int index=-1)
{
	if(index==-1) index = currentS.size()-1;
	NodeX* dataGraphNode = (*(currentS[index]->it))->node;
	NodeX* queryGraphNode = graph1->getNodeWithID(nodesOrder[index]);

	for(map<int, void*>::iterator iter = queryGraphNode->getEdgesIterator();iter!=queryGraphNode->getEdgesEndIterator();++iter)
	{
		int otherNodeID = iter->first;
		EdgeX* edge = (EdgeX*)(iter->second);

		if(selectedQueryMap[otherNodeID]==-1)
			continue;

		//get the data node that the current data node should be connected with
		//cout<<"dataGraphNode:"<<dataGraphNode->getID()<<", queryGraphNode:"<<queryGraphNode->getID()<<endl;
		//cout<<otherNodeID<<","<<selectedQueryMap.find(otherNodeID)->second<<endl;
		int dataNodeID = (*(currentS[selectedQueryMap[otherNodeID]]->it))->node->getID();

		//check the current graph edges, whether it has a connection to dataNodeID or not
		//cout<<"checking node connection:"<<dataGraphNode->getID()<<" with "<<dataNodeID<<endl;
		if(!dataGraphNode->isItConnectedWithNodeID(dataNodeID, edge->getLabel()))
		{
			//cout<<"false"<<endl;
			return false;
		}
	}

	return true;
}

NodeX* Edge_Iterator::getCurrentNode()
{
	return ((EdgeX*)it->second)->getOtherNode();
}

void Set_Iterator::print()
{
	for(set<int>::iterator iter = se->begin();iter!=se->end();iter++)
	{
		cout<<(*iter)<<", ";
	}
	cout<<endl<<flush;
}

void Set_Nodes_Iterator::print()
{
	for(set<NodeX*>::iterator iter = se->begin();iter!=se->end();iter++)
	{
		cout<<(*iter)->getID()<<", ";
	}
	cout<<endl<<flush;
}

void Set_Nodes_Prioritized_Iterator::print() {
	for(vector<Node_Score*>::iterator iter = se->begin();iter!=se->end();iter++)
	{
		cout<<(*iter)->node->getID()<<":"<<(*iter)->score<<", ";
	}
	cout<<endl<<flush;
}

void Set_Nodes_Prioritized_Iterator::replaceIfBetter(Node_Score* ns) {

	size = 1;

	if(se->size()==0) {
		minValue = ns->score;
		maxValue = ns->score;
		se->push_back(ns);
		return;
	}

	Node_Score* tempNS = *(se->begin());
	if(ns->score>tempNS->score) {
		se->clear();

		minValue = ns->score;
		maxValue = ns->score;
		se->push_back(ns);
	}
}

void Set_Nodes_Prioritized_Iterator::cutIfLarger(int s, bool maintainOnes){

	if(se->size()>s)
	{
		for(vector<Node_Score*>::iterator iter = se->begin()+s;iter!=se->end();iter++)
			delete *iter;

		se->erase(se->begin()+s);
		size = s;
		minValue = se->at(se->size()-1)->score;
	}
}

void Set_Nodes_Prioritized_Iterator::insertOrdered(Node_Score* ns) {

	size++;

	if(se->size()==0) {
		minValue = ns->score;
		maxValue = ns->score;
		se->push_back(ns);
		return;
	}

	if(ns->score<=minValue) {
		minValue = ns->score;
		se->push_back(ns);
	}
	else if(ns->score>=maxValue) {
		maxValue = ns->score;
		se->insert(se->begin(), ns);
	}
	else {
		vector<Node_Score*>::iterator iter = se->begin();
		for(;iter!=se->end();iter++)
		{
			if(ns->score>(*iter)->score)
				break;
		}
		se->insert(iter, ns);
	}
}

Set_Nodes_Prioritized_Iterator::~Set_Nodes_Prioritized_Iterator() {
	vector<Node_Score*>::iterator iter = se->begin();
	for(;iter!=se->end();iter++) {
		delete (*iter);
	}
	delete se;
}

/**
 * Constructor
 */
GraphX::GraphX()
{
	init(0,0);
}

GraphX::GraphX(int id, int type)
{
	init(id, type);
}

void GraphX::init(int id, int type)
{
	this->id = id;
	this->type = type;
	if(type==1)
	{
		cout<<"IMPORTANT! current set of algorithms do not support directed graphs!";
		exit(0);
	}
	numOfEdges = 0;
	maxLabel = -1;
}

GraphX::GraphX(GraphX* graph)
{
	this->id = graph->getID();
	this->type = graph->getType();
	numOfEdges = graph->getNumOfEdges();

	//copy nodes
	for(map<int, NodeX*>::const_iterator iter = graph->getNodesIterator();iter!=graph->getNodesEndIterator();++iter)
	{
		NodeX* oldNode = iter->second;
		this->AddNode(oldNode->getID(), oldNode->getLabel());
	}

	//copy edges
	for(map<int, NodeX*>::const_iterator iter = graph->getNodesIterator();iter!=graph->getNodesEndIterator();++iter)
	{
		NodeX* oldNode = iter->second;
		NodeX* node = nodes.at(oldNode->getID());

		for(map<int, void*>::iterator iter2 = oldNode->getEdgesIterator();iter2!=oldNode->getEdgesEndIterator();++iter2)
		{
			EdgeX* edge = (EdgeX*)(iter2->second);
			node->addEdge(nodes.at(edge->getOtherNode()->getID()) , edge->getLabel(), this->type);
		}
	}
}

/**
 * Add a node to the graph
 * Parameters are: node id, and node label
 */
NodeX* GraphX::AddNode(int id, double label)
{
	//assign the maximum label value (note: the current node label implementation is double!)
	if(maxLabel<label)
		maxLabel = label;

	if(maxNodeID<id)
		maxNodeID = id;

	map<int, NodeX*>::iterator temp = nodes.find(id);
	if(temp!=nodes.end())
		return temp->second;

	NodeX* node = new NodeX(id, label);
	nodes.insert(std::pair<int, NodeX*>(id, node));

	//add to the 'node IDs by label' map
	tr1::unordered_map<double, set<int>* >::iterator iter = nodeIDsByLabel.find(label);
	if(iter==nodeIDsByLabel.end())
	{
		nodeIDsByLabel.insert(std::pair<double, set<int>*>(label, new set<int>()));
		iter = nodeIDsByLabel.find(label);
	}
	iter->second->insert(id);

	//add to the 'nodes by label' map
	tr1::unordered_map<double, set<NodeX*>* >::iterator iter1 = nodesByLabel.find(label);
	if(iter1==nodesByLabel.end())
	{
		nodesByLabel.insert(std::pair<double, set<NodeX*>*>(label, new set<NodeX*>()));
		iter1 = nodesByLabel.find(label);
	}
	iter1->second->insert(node);

	return node;
}

/**
 * Add an edge between two nodes in the graph, the nodes must exist before adding the edge
 * Parameters: the source node ID, the destination node ID, and the edge label
 * For undirected graphs, one more edge will be added in the reverse direction
 */
void GraphX::addEdge(int srcID, int destID, double edgeLabel)
{
	nodes[srcID]->addEdge(nodes[destID], edgeLabel, this->type);

	if(this->type==0)
	{
		nodes[destID]->addEdge(nodes[srcID], edgeLabel, this->type);
	}

	numOfEdges++;
}

void GraphX::removeEdge(int id1, int id2)
{
	nodes[id1]->removeEdge(nodes[id2], this->type);
	if(nodes[id1]->getEdgesSize()==0)
		removeNode_IgnoreEdges(id1);

	if(this->type==0)
	{
		nodes[id2]->removeEdge(nodes[id1], this->type);
		if(nodes[id2]->getEdgesSize()==0)
			removeNode_IgnoreEdges(id2);
	}

	numOfEdges--;
}

/**
 * remove a node from the graph, ignoring edges (as a prepost all edges connecting to this node should be already removed)
 */
void GraphX::removeNode_IgnoreEdges(int nodeID)
{
	nodeIDsByLabel.find(getNodeWithID(nodeID)->getLabel())->second->erase(nodeID);
	delete nodes.find(nodeID)->second;
	nodes.erase(nodeID);
}

void GraphX::addEdge(int srcID, int destID, double edgeLabel, map<string, void* >& edgeToFreq)
{
	//cout<<"Adding edge: "<<srcID<<"---"<<destID<<"\n";
	this->addEdge(srcID, destID, edgeLabel);
}

/**
 * Load a graph file that has .lg format
 * return true if loading is done correctly, otherwise false
 */
bool GraphX::loadFromFile(string fileName)
{
	cout<<"Loading graph from file: "<<fileName<<endl;
	ifstream file (fileName.c_str(), ios::in);
	if(!file)
	{
		cout << "While opening a file an error is encountered" << endl;
		return false;
    }

	if(!parseData(file))
		return false;

	file.close();

	return true;
}

bool GraphX::loadFromString(string data)
{
	cout<<"Loading graph from string: "<<data<<endl;
	istringstream str(data);

	bool b = parseData(str);

	if(!b)
		return false;

	return true;
}

bool GraphX::parseData(istream& data)
{
	//read the first line
	char temp_ch;
	data>>temp_ch;data>>temp_ch;data>>temp_ch;

	int numEdgesLoaded = 0;

	while (true)
	{
		char ch;
		data>>ch;

		if(data.eof()) break;

		//to add nodes
		if(ch=='v')
		{
			int id;
			double label;
			data>>id;
			data>>label;
//			if(id<100000)//remove me
				this->AddNode(id, label);
		}
		else if(ch=='e')//to add edges
		{
			numNodesBeforeDeletingNodes = nodes.size();
			int id1;
			int id2;
			double label;
			data>>id1;
			data>>id2;
			data>>label;
//			if(id1<100000 && id2<100000)//remove me
			{
			this->addEdge(id1, id2, label);
			if(numEdgesLoaded%1000000==0)
				cout<<"Loaded edges = "<<numEdgesLoaded<<endl;
			numEdgesLoaded++;
			}
		}
	}

	return true;
}

void GraphX::storeNodeFeatures(string fileName) {
	ofstream file (fileName.c_str(), ios::out);

	//output the nodes
	for( map<int,NodeX*>::const_iterator ii=nodes.begin(); ii!=nodes.end(); ++ii)
	{
		NodeX* node = ii->second;
		file<<node->getID();

		for(vector<Feature*>::iterator iter = ((Features*)node->getFeatures())->getVectorBegin();iter!=((Features*)node->getFeatures())->getVectorEnd();iter++) {
			Feature* tempFeature = (*iter);
			double tempValue = tempFeature->getValue();
			int featureName = tempFeature->getName();
			file<<","<<featureName<<","<<tempValue;
		}

		file<<"|\n";
	}
}

void GraphX::loadNodeFeatures(string fileName) {
	ifstream file (fileName.c_str(), ios::in);

	int c = 0;
	//read features data from file
	while(true)
	{
		c++;
		if(c%1000000==0) cout<<"Loading nodes features "<<c<<endl;
		int nodeID;
		file>>nodeID;
		if(file.eof()) break;
		Features* fs = new Features();
		NodeX* node = this->getNodeWithID(nodeID);
		node->setFeatures(fs);

//		cout<<"NodeID = "<<nodeID<<endl;

		while(true) {
			char c;
			file>>c;
//			cout<<c<<",";
			if(c=='|' || file.eof()) {
				break;
			}
			int featureName;
			file>>featureName;
			file>>c;
			double tempValue;
			file>>tempValue;

//			cout<<featureName<<", "<<tempValue<<endl;

			fs->addFeature(featureName, tempValue);
		}

		if(file.eof()) break;
	}
}
void GraphX::generateFeaturesKeys()
{
	if(nodes.size()>1000)
		cout<<"Generating node neighbors keys."<<endl;
	int counter = 0;
	for(map<int,NodeX*>::iterator ii=nodes.begin(); ii!=nodes.end(); ++ii) {
		NodeX* node = ii->second;
		node->generateFeaturesKey();
		counter++;
		if(counter%1000000==0) cout<<counter<<endl;
	}
}

NodeX* GraphX::getNodeWithID(int nodeID)
{
	map<int, NodeX*>::iterator iter = nodes.find(nodeID);
	if(iter==nodes.end())
		return NULL;
	else
		return iter->second;
}

set<int>* GraphX::getNodeIDsByLabel(double label)
{
	tr1::unordered_map<double, set<int>* >::iterator iter = nodeIDsByLabel.find(label);
	if(iter==nodeIDsByLabel.end())
		return NULL;
	return iter->second;
}

set<NodeX*>* GraphX::getNodesByLabel(double label)
{
	tr1::unordered_map<double, set<NodeX*>* >::iterator iter = nodesByLabel.find(label);
	if(iter==nodesByLabel.end())
		return NULL;
	return iter->second;
}

map<int,NodeX*>::const_iterator GraphX::getNodesIterator()
{
	return nodes.begin();
}

map<int,NodeX*>::const_iterator GraphX::getNodesEndIterator()
{
	return nodes.end();
}

/**
 * get edge label from the scr node to the destination node
 * if either the src node is not found, or the detination node is not found from the src node, then return 0.0001
 */
double GraphX::getEdgeLabel(int srcNodeID, int destNodeID)
{
	NodeX* srcNode;
	map<int, NodeX* >::iterator temp = nodes.find(srcNodeID);
	if(temp==nodes.end())
			return 0.0001;
	srcNode = (*temp).second;

	EdgeX* edge = (EdgeX*)srcNode->getEdgeForDestNode(destNodeID);
	if(edge==NULL)
		return 0.0001;

	return edge->getLabel();
}

int GraphX::getNumOfNodes()
{
	return this->nodes.size();
}

bool GraphX::isConnected()
{
	if(nodes.size()<2)
		return true;

	//start from any node
	NodeX* node = nodes.begin()->second;
	map<int,NodeX*> visited;
	map<int,NodeX*> toVisit;

	toVisit.insert(std::pair<int, NodeX*>(node->getID(), node));
	while(toVisit.size()>0)
	{
		//1- pop a node for the to be visited list, 2- remove it from toVisit, and 3- add it to the visited list
		node = toVisit.begin()->second;//1
		toVisit.erase(toVisit.begin());//2
		visited.insert(std::pair<int, NodeX*>(node->getID(), node));//3
		//add its neighbors
		for(map<int, void*>::iterator iter = node->getEdgesIterator();iter!=node->getEdgesEndIterator();++iter)
		{
			int id = iter->first;
			if(visited.find(id)!=visited.end())
				continue;
			EdgeX* edge = (EdgeX*)iter->second;
			toVisit.insert(std::pair<int, NodeX*>(id, edge->getOtherNode()));
		}
	}

	if(visited.size()==nodes.size())
		return true;
	else
		return false;

}

/**
 * check whether two graphs are isomorphic or not
 * if isomorphic, then 'results' will have mapping between nodes from this graph to nodes in the given graph
 * 'this' is the query graph, while graph i the data graph, this means I can query this (smaller) in the data (Bigger)
 *  [*] this function does not consider edge label! FIX IT!!!!
 */
void GraphX::isIsomorphic(GraphX* graph, vector<map<int, int>* >& results, tr1::unordered_map<int, tr1::unordered_set<int>*>& domains_values, int* plan , int restrictedDomainID, int restrictedNodeID, bool pruneByDomainValues)
{
	//set limitation on the number of results
//	if(results.size()>1000)
//		return;

	//populate the order in which query graph will be traversed
	tr1::unordered_set<int> checked;
	int nodesOrder[getNumOfNodes()];//the result of this part

	//get the nodes order
	if(plan==0)
	{
		tr1::unordered_set<int> available;
		//check for the restricted node, if it exists let it be the first to check
		if(restrictedDomainID==-1)
			available.insert(nodes.begin()->second->getID());
		else
			available.insert(restrictedDomainID);

		int count = 0;
		while(available.size()>0)
		{
			//select the best node from available
			tr1::unordered_set<int>::iterator iter1 = available.begin();
			set<int>* nodesWithLabel = graph->getNodeIDsByLabel(nodes[(*iter1)]->getLabel());
			double bestScore = 0;
			if(nodesWithLabel!=NULL)
				bestScore = nodesWithLabel->size()/((double)nodes[(*iter1)]->getEdgesSize());
			int bestNode = *iter1;
			iter1++;

			for(;iter1!=available.end();++iter1)
			{
				double currScore = 0;
				nodesWithLabel = graph->getNodeIDsByLabel(nodes[(*iter1)]->getLabel());
				if(nodesWithLabel!=NULL)
					currScore = nodesWithLabel->size()/((double)nodes[(*iter1)]->getEdgesSize());
				int currID = *iter1;

				if(currScore<bestScore) {
					bestScore = currScore;
					bestNode = currID;
				}
			}

			int current = bestNode;

			available.erase(bestNode);
			if(checked.find(current)!=checked.end())
				continue;
			nodesOrder[count] = current;
			checked.insert(current);
			count++;
			NodeX* currNode = nodes[current];

			for(map<int, void*>::iterator iter = currNode->getEdgesIterator();iter!=currNode->getEdgesEndIterator();++iter)
			{
				int otherID = iter->first;
				if(checked.find(otherID)==checked.end())
				{
					available.insert(otherID);
				}
			}
		}
	}
	else
	{
		for(int i=0;i<nodes.size();i++)
		{
			nodesOrder[i] = plan[i];
		}
	}

	//print nodes order
//	cout<<"Query nodes order: ";
//	for(int i=0;i<getNumOfNodes();i++)
//		cout<<nodesOrder[i]<<",";
//	cout<<endl;

	vector<Set_Iterator* > selected;
	tr1::unordered_set<int> selectedDataMap;//only for fast check for existence
	tr1::unordered_map<int, int> selectedQueryMap;//map value is query node id, value is its order
	//add it to the selected list
	Set_Iterator* isi = new Set_Iterator();

	//if the restricted node ID exists, then limit its domain to the restricted node
	if(restrictedNodeID==-1)//if(restrictedDomainID==-1)
	{
		isi->se = graph->getNodeIDsByLabel(this->getNodeWithID(nodesOrder[0])->getLabel());
		if(isi->se==NULL)
		{
			delete isi;
			return;
		}
	}
	else
	{
		isi->se = new set<int>();
		isi->se->insert(restrictedNodeID);
	}
	isi->it = isi->se->begin();
	selected.push_back(isi);
	selectedDataMap.insert(*(isi->it));
	selectedQueryMap.insert(std::pair<int, int>(nodesOrder[selected.size()-1], selected.size()-1));

	int tempCounter = 0;
	long numIterations = 0;
	while(true)
	{
		numIterations++;
		//take care of the counting part
		Set_Iterator* currentISI = selected.back();//.at(selected.size()-1);


//		if(selected.size()==1)
//		{
//			for(vector<Set_Iterator* >::iterator i = selected.begin();i!=selected.end();++i)
//			{
//				cout<<(*((*i)->it))<<",";
//			}
//			cout<<endl;
//		}

		//cout<<"current set length = "<<currentISI->se->size()<<endl<<flush;
		while(currentISI->isIterEnd())
		{
			//if we finished the domain of the first node
			if(selected.size()==1)
			{
				delete (*(selected.begin()));
				selected.clear();
//				cout<<"numIterations = "<<numIterations<<endl;
				return;
			}

			/*if((*(selected.back()->it))==16)
			{
				cout<<(*(selected.front()->it));

				for(tr1::unordered_set<int>::iterator iter = selectedDataMap.begin();iter!=selectedDataMap.end();iter++)
				{
					cout<<(*iter)<<",";
				}

				cout<<endl;

				cout<<"front: ";
				selected.front()->print();
				cout<<"back: ";
				selected.back()->print();
				cout<<(selected.back()->it==selected.back()->se->end());

				cout<<flush;
				cout<<"blabla";
			}*/

			//clear the data node associated with the last selected
			//selectedDataMap.erase(*(selected.back()->it));//commented on 27/10/2015
			//remove the last selected
			Set_Iterator* tempToDel = selected.back();
			selected.pop_back();
			delete tempToDel->se;
			delete tempToDel;
			//delete the query node associated with the last selected
			selectedQueryMap.erase(nodesOrder[selected.size()]);

			currentISI = selected.back();//.at(selected.size()-1);

			selectedDataMap.erase(*(currentISI->it));
			currentISI->it++;
			if(!currentISI->isIterEnd())//only the if line is added on 27/10/2015
				selectedDataMap.insert(*(currentISI->it));
		}

		//check current status
		bool b = checkCurrentStatus(this, graph, selected, nodesOrder, selectedQueryMap);
		tempCounter++;
		//if valid
		if(b)
		{
			//cout<<"Check result is true"<<endl;
			//I found a solution
			if(selected.size()==this->getNumOfNodes())
			{
				map<int, int>* m = new map<int,int>();

				//adding result
				int c = 0;
				for(vector<Set_Iterator* >::iterator i = selected.begin();i!=selected.end();++i,c++)
				{
					m->insert(std::pair<int, int>(nodesOrder[c], *((*i)->it)));
//					cout<<nodesOrder[c]<<":"<<(*((*i)->it))<<",";
				}
//				cout<<endl;

				results.push_back(m);

//				cout<<results.size()<<endl;

				if(results.size()>10000000000)
					return;

				//cout<<"A solution is found"<<endl;
//				if(restrictedDomainID!=-1)
//				{
//					//delete elements in selected
//					for(vector<Set_Iterator* >::iterator iter = selected.begin();iter!=selected.end();iter++)
//					{
//						(*iter)->se->clear();
//						delete (*iter)->se;
//						delete (*iter);
//					}
//
//					//cout<<tempCounter<<": "<<restrictedDomainID<<" , "<<restrictedNodeID<<flush;
//					return;
//				}

				selectedDataMap.erase(*(selected.back()->it));
				selected.back()->it++;
				if(!selected.back()->isIterEnd())//only the if line is added on 27/10/2015
					selectedDataMap.insert(*(selected.back()->it));
			}
			else//no solution found yet!
			{
				Set_Iterator* si = new Set_Iterator();
				si->se = new set<int>();
				//get extension from current selected (last si)
				//get the index of a query node connected to the query node to be selected for the check
				NodeX* temp = NULL;
				/*if(nodesOrder[selected.size()]==1)
				{
					int c= 0;
					int score = 0;
					for(vector<Set_Iterator* >::iterator i = selected.begin();i!=selected.end();++i,c++)
					{
//						cout<<nodesOrder[c]<<":"<<(*((*i)->it))<<",";
						if(nodesOrder[c]==2 && (*((*i)->it))==16)
							score++;
						if(nodesOrder[c]==0 && (*((*i)->it))==2376)
							score++;
//						if(nodesOrder[c]==16 && (*((*i)->it))==190)
//							score++;
//						if(nodesOrder[c]==17 && (*((*i)->it))==1620)
//							score++;
//						if(nodesOrder[c]==18 && (*((*i)->it))==1385)
//							score++;
//						if(nodesOrder[c]==9 && (*((*i)->it))==1235)
//							score++;
//						if(nodesOrder[c]==14 && (*((*i)->it))==2834)
//							score++;
//						if(nodesOrder[c]==15 && (*((*i)->it))==890)
//							score++;
//						if(nodesOrder[c]==5 && (*((*i)->it))==2834)
//							score++;
					}

					if(score==2)
					{
						cout<<flush;
						cout<<endl;
					}
					else
					{
//						cout<<endl;
					}
				}*/
				NodeX* tempN1 = this->getNodeWithID(nodesOrder[selected.size()]);
				vector<Set_Iterator* >::iterator tempIT = selected.begin();
				for(int i=0;i<selected.size();i++, tempIT++)
				{
//					cout<<"bestNodeID = "<<restrictedDomainID<<endl;
//					cout<<"tempN1 ID = "<<tempN1->getID()<<endl;
//					cout<<"selected.size() = "<<selected.size()<<endl;
					if(tempN1->isItConnectedWithNodeID(nodesOrder[i]))
					{
						temp = graph->getNodeWithID((*(*tempIT)->it));
						break;
					}
				}
				if(temp==NULL)
				{
					for(int i=0;i<getNumOfNodes();i++)
						cout<<nodesOrder[i]<<",";
					cout<<"Error90890"<<flush;
					exit(0);
				}
				for(map<int, void*>::iterator iter = temp->getEdgesIterator();iter!=temp->getEdgesEndIterator();++iter)
				{
					int otherNodeID = iter->first;

					NodeX* otherNode = graph->getNodeWithID(otherNodeID);
					//check for the AC_3ed domain, to check for node occurrence, if not then no need to check it
					if(pruneByDomainValues && domains_values.size()>0)
					{
						tr1::unordered_set<int>* tempD = domains_values[nodesOrder[selected.size()]];
						if(tempD->find(otherNodeID)==tempD->end())
						{
							continue;
						}
					}

					//check for node label
					if(otherNode->getLabel()!=tempN1->getLabel())
						continue;

					if(selectedDataMap.find(otherNodeID)==selectedDataMap.end())
					{
						bool b = true;
						//check for other edges
						for(map<int, void*>::iterator iter1 = tempN1->getEdgesIterator();iter1!=tempN1->getEdgesEndIterator();++iter1)
						{
							EdgeX* edge = (EdgeX*)iter1->second;
							tr1::unordered_map<int, int>::iterator itr = selectedQueryMap.find(edge->getOtherNode()->getID());
							if(itr == selectedQueryMap.end())
								continue;
							int tempOrder = itr->second;
							double edgeLabel = edge->getLabel();
							if(!otherNode->isItConnectedWithNodeID((*(selected[tempOrder]->it)), edgeLabel))
							{
								b = false;
								break;
							}
						}

						if(b)
						{
							si->se->insert(otherNodeID);

//							if(otherNodeID==16 && selected.size()>1)
//							{
//								cout<<"bang!"<<endl;
//								for(tr1::unordered_set<int>::iterator iter1 = selectedDataMap.begin();iter1!=selectedDataMap.end();iter1++)
//								{
//									cout<<(*iter1)<<",";
//								}
//								cout<<endl<<flush;
//								cout<<"";
//							}
						}
					}
					else
					{
						//cout<<"[->"<<otherNodeID<<"<-],";
					}
				}

				//I discovered a bug when testing the efficient graph, this fix should work now, otherwise the old code is below
				if(si->se->size()>0)
				{
					si->it = si->se->begin();
					selected.push_back(si);
					selectedDataMap.insert(*(si->it));
					selectedQueryMap.insert(std::pair<int, int>(nodesOrder[selected.size()-1], selected.size()-1));
				}
				else
				{
					si->it = si->se->end();
					//valgrind effect
					delete si->se;
					delete si;
					//
					selectedDataMap.erase(*(selected.back()->it));
					selected.back()->it++;
					if(!selected.back()->isIterEnd())//only the if line is added on 27/10/2015
						selectedDataMap.insert(*(selected.back()->it));//added on 25_10_2015
				}
			}
		}
		else
		{
			//cout<<"Check result is false"<<endl;
			selectedDataMap.erase(*(selected.back()->it));
			selected.back()->it++;
			if(!selected.back()->isIterEnd())//only the if line is added on 27/10/2015
				selectedDataMap.insert(*(selected.back()->it));
		}
	}

	//delete elements in selected
	for(vector<Set_Iterator* >::iterator iter = selected.begin();iter!=selected.end();iter++)
	{
		(*iter)->se->clear();
//		if(restrictedDomainID!=-1)
//			delete (*iter)->se;
		delete (*iter);
	}
	selected.clear();
}

/**
 * check whether the restricted node ID (or the list of nodes for the restricted domain) is part of this graph inside the data graph
 * if yes, then 'results' will have the list of valid graph nodes
 * 'this' is the query graph, while graph i the data graph, this means I can query this (smaller) in the data (Bigger)
 *  [*] this function does not consider edge label! FIX IT!!!!
 */
void GraphX::isIsomorphic_OneMatch(GraphX* graph, vector<int>& results, tr1::unordered_map<int, tr1::unordered_set<int>*>& domains_values, int* plan , int restrictedDomainID, int restrictedNodeID, bool pruneByDomainValues)
{
	//populate the order in which query graph will be traversed
	tr1::unordered_set<int> checked;
	int nodesOrder[getNumOfNodes()];//the result of this part

	//get the nodes order
	if(plan==0)
	{
		tr1::unordered_set<int> available;
		//check for the restricted node, if it exists let it be the first to check
		if(restrictedDomainID==-1)
			available.insert(nodes.begin()->second->getID());
		else
			available.insert(restrictedDomainID);

		int count = 0;
		while(available.size()>0)
		{
			//select the best node from available
			tr1::unordered_set<int>::iterator iter1 = available.begin();
			set<int>* nodesWithLabel = graph->getNodeIDsByLabel(nodes[(*iter1)]->getLabel());
			double bestScore = 0;
			if(nodesWithLabel!=NULL)
				bestScore = nodesWithLabel->size()/((double)nodes[(*iter1)]->getEdgesSize());
			int bestNode = *iter1;
			iter1++;

			for(;iter1!=available.end();++iter1)
			{
				double currScore = 0;
				nodesWithLabel = graph->getNodeIDsByLabel(nodes[(*iter1)]->getLabel());
				if(nodesWithLabel!=NULL)
					currScore = nodesWithLabel->size()/((double)nodes[(*iter1)]->getEdgesSize());
				int currID = *iter1;

				if(currScore<bestScore) {
					bestScore = currScore;
					bestNode = currID;
				}
			}

			int current = bestNode;

			available.erase(bestNode);
			if(checked.find(current)!=checked.end())
				continue;
			nodesOrder[count] = current;
			checked.insert(current);
			count++;
			NodeX* currNode = nodes[current];

			for(map<int, void*>::iterator iter = currNode->getEdgesIterator();iter!=currNode->getEdgesEndIterator();++iter)
			{
				int otherID = iter->first;
				if(checked.find(otherID)==checked.end())
				{
					available.insert(otherID);
				}
			}
		}
	}
	else
	{
		for(int i=0;i<nodes.size();i++)
		{
			nodesOrder[i] = plan[i];
		}
	}

	//print nodes order
//	cout<<"Query nodes order: ";
//	for(int i=0;i<getNumOfNodes();i++)
//		cout<<nodesOrder[i]<<",";
//	cout<<endl;

	vector<Set_Iterator* > selected;
	tr1::unordered_set<int> selectedDataMap;//only for fast check for existence
	tr1::unordered_map<int, int> selectedQueryMap;//map value is query node id, value is its order
	//add it to the selected list
	Set_Iterator* isi = new Set_Iterator();

	//if the restricted node ID exists, then limit its domain to the restricted node
	if(restrictedNodeID==-1)//if(restrictedDomainID==-1)
	{
		isi->se = graph->getNodeIDsByLabel(this->getNodeWithID(nodesOrder[0])->getLabel());
		if(isi->se==NULL)
		{
			delete isi;
			return;
		}
	}
	else
	{
		isi->se = new set<int>();
		isi->se->insert(restrictedNodeID);
	}
	isi->it = isi->se->begin();
	selected.push_back(isi);
	selectedDataMap.insert(*(isi->it));
	selectedQueryMap.insert(std::pair<int, int>(nodesOrder[selected.size()-1], selected.size()-1));

	int tempCounter = 0;
	long numIterations = 0;
	while(true)
	{
		numIterations++;
		//take care of the counting part
		Set_Iterator* currentISI = selected.back();//.at(selected.size()-1);

		//cout<<"current set length = "<<currentISI->se->size()<<endl<<flush;
		while(currentISI->isIterEnd())
		{
			//if we finished the domain of the first node
			if(selected.size()==1)
			{
				delete (*(selected.begin()));
				selected.clear();
//				cout<<"numIterations = "<<numIterations<<endl;
				return;
			}

			//clear the data node associated with the last selected
			//selectedDataMap.erase(*(selected.back()->it));//commented on 27/10/2015
			//remove the last selected
			Set_Iterator* tempToDel = selected.back();
			selected.pop_back();
			delete tempToDel->se;
			delete tempToDel;
			//delete the query node associated with the last selected
			selectedQueryMap.erase(nodesOrder[selected.size()]);

			currentISI = selected.back();

			selectedDataMap.erase(*(currentISI->it));
			currentISI->it++;
			if(!currentISI->isIterEnd())//only the if line is added on 27/10/2015
				selectedDataMap.insert(*(currentISI->it));
		}

		//check current status
		bool b = checkCurrentStatus(this, graph, selected, nodesOrder, selectedQueryMap);
		tempCounter++;
		//if valid
		if(b)
		{
			//cout<<"Check result is true"<<endl;
			//I found a solution
			if(selected.size()==this->getNumOfNodes())
			{
//				cout<<"Result found ..."<<endl;
				//adding result
				results.push_back((*(*(selected.begin()))->it));

				//resetting to one selected query node
				//1- clear selected data graph nodes
				selectedDataMap.clear();
				//2- clear data graph iterators
				for(vector<Set_Iterator* >::iterator iter = selected.begin()+1;iter!=selected.end();iter++)
					delete *iter;
				selected.erase(selected.begin()+1, selected.end());
				//3- advance the data graph nodes iterators
				selected.back()->it++;
				if(!selected.back()->isIterEnd())//only the if line is added on 27/10/2015
					selectedDataMap.insert(*(selected.back()->it));
				//4- clear selected query nodes
				for(int j=1;j<=this->getNumOfNodes();j++)
					selectedQueryMap.erase(nodesOrder[j]);
			}
			else//no solution found yet!
			{
				Set_Iterator* si = new Set_Iterator();
				si->se = new set<int>();
				//get extension from current selected (last si)
				//get the index of a query node connected to the query node to be selected for the check
				NodeX* temp = NULL;

				NodeX* tempN1 = this->getNodeWithID(nodesOrder[selected.size()]);
				vector<Set_Iterator* >::iterator tempIT = selected.begin();
				for(int i=0;i<selected.size();i++, tempIT++)
				{
					if(tempN1->isItConnectedWithNodeID(nodesOrder[i]))
					{
						temp = graph->getNodeWithID((*(*tempIT)->it));
						break;
					}
				}
				if(temp==NULL)
				{
					for(int i=0;i<getNumOfNodes();i++)
						cout<<nodesOrder[i]<<",";
					cout<<"Error90891"<<flush;
					exit(0);
				}
				for(map<int, void*>::iterator iter = temp->getEdgesIterator();iter!=temp->getEdgesEndIterator();++iter)
				{
					int otherNodeID = iter->first;

					NodeX* otherNode = graph->getNodeWithID(otherNodeID);
					//check for the AC_3ed domain, to check for node occurrence, if not then no need to check it
					if(pruneByDomainValues && domains_values.size()>0)
					{
						tr1::unordered_set<int>* tempD = domains_values[nodesOrder[selected.size()]];
						if(tempD->find(otherNodeID)==tempD->end())
						{
							continue;
						}
					}

					//check for node label
					if(otherNode->getLabel()!=tempN1->getLabel())
						continue;

					if(selectedDataMap.find(otherNodeID)==selectedDataMap.end())
					{
						bool b = true;
						//check for other edges
						for(map<int, void*>::iterator iter1 = tempN1->getEdgesIterator();iter1!=tempN1->getEdgesEndIterator();++iter1)
						{
							EdgeX* edge = (EdgeX*)iter1->second;
							tr1::unordered_map<int, int>::iterator itr = selectedQueryMap.find(edge->getOtherNode()->getID());
							if(itr == selectedQueryMap.end())
								continue;
							int tempOrder = itr->second;
							double edgeLabel = edge->getLabel();
							if(!otherNode->isItConnectedWithNodeID((*(selected[tempOrder]->it)), edgeLabel))
							{
								b = false;
								break;
							}
						}

						if(b)
						{
							si->se->insert(otherNodeID);
						}
					}
					else
					{
						//cout<<"[->"<<otherNodeID<<"<-],";
					}
				}

				//I discovered a bug when testing the efficient graph, this fix should work now, otherwise the old code is below
				if(si->se->size()>0)
				{
					si->it = si->se->begin();
					selected.push_back(si);
					selectedDataMap.insert(*(si->it));
					selectedQueryMap.insert(std::pair<int, int>(nodesOrder[selected.size()-1], selected.size()-1));
				}
				else
				{
					si->it = si->se->end();
					//valgrind effect
					delete si->se;
					delete si;
					//
					selectedDataMap.erase(*(selected.back()->it));
					selected.back()->it++;
					if(!selected.back()->isIterEnd())//only the if line is added on 27/10/2015
						selectedDataMap.insert(*(selected.back()->it));//added on 25_10_2015
				}
			}
		}
		else
		{
			//cout<<"Check result is false"<<endl;
			selectedDataMap.erase(*(selected.back()->it));
			selected.back()->it++;
			if(!selected.back()->isIterEnd())//only the if line is added on 27/10/2015
				selectedDataMap.insert(*(selected.back()->it));
		}
	}

	//delete elements in selected
	for(vector<Set_Iterator* >::iterator iter = selected.begin();iter!=selected.end();iter++)
	{
		(*iter)->se->clear();
		delete (*iter);
	}
	selected.clear();
}

/**
 * check whether the restricted node ID (or the list of nodes for the restricted domain) is part of this graph inside the data graph
 * if yes, then 'results' will have the list of valid graph nodes
 * 'this' is the query graph, while graph i the data graph, this means I can query this (smaller) in the data (Bigger)
 *  [*] this function does not consider edge label! FIX IT!!!!
 */
void GraphX::isIsomorphic_OneMatch_Fast(GraphX* graph, vector<int>& results, int* plan , int restrictedDomainID, int restrictedNodeID)
{
	//populate the order in which query graph will be traversed
	int nodesOrder[getNumOfNodes()];//the result of this part

	//get the nodes order
	if(plan==0)
	{
		tr1::unordered_set<int> checked;
		tr1::unordered_set<int> available;
		//check for the restricted node, if it exists let it be the first to check
		if(restrictedDomainID==-1)
			available.insert(nodes.begin()->second->getID());
		else
			available.insert(restrictedDomainID);

		int count = 0;
		while(available.size()>0)
		{
			//select the best node from available
			tr1::unordered_set<int>::iterator iter1 = available.begin();
			set<int>* nodesWithLabel = graph->getNodeIDsByLabel(nodes[(*iter1)]->getLabel());
			double bestScore = 0;
			if(nodesWithLabel!=NULL)
				bestScore = nodesWithLabel->size()/((double)nodes[(*iter1)]->getEdgesSize());
			int bestNode = *iter1;
			iter1++;

			for(;iter1!=available.end();++iter1)
			{
				double currScore = 0;
				nodesWithLabel = graph->getNodeIDsByLabel(nodes[(*iter1)]->getLabel());
				if(nodesWithLabel!=NULL)
					currScore = nodesWithLabel->size()/((double)nodes[(*iter1)]->getEdgesSize());
				int currID = *iter1;

				if(currScore<bestScore) {
					bestScore = currScore;
					bestNode = currID;
				}
			}

			int current = bestNode;

			available.erase(bestNode);
			if(checked.find(current)!=checked.end())
				continue;
			nodesOrder[count] = current;
			checked.insert(current);
			count++;
			NodeX* currNode = nodes[current];

			for(map<int, void*>::iterator iter = currNode->getEdgesIterator();iter!=currNode->getEdgesEndIterator();++iter)
			{
				int otherID = iter->first;
				if(checked.find(otherID)==checked.end())
				{
					available.insert(otherID);
				}
			}
		}
	}
	else
	{
		for(int i=0;i<nodes.size();i++)
		{
			nodesOrder[i] = plan[i];
		}
	}

	//print nodes order
//	cout<<"Query nodes order: ";
//	for(int i=0;i<getNumOfNodes();i++)
//		cout<<nodesOrder[i]<<",";
//	cout<<endl;

	vector<Set_Nodes_Iterator* > selected;

	//map value is query node id, value is its order *** this is one thing that you can improve
//	tr1::unordered_map<int, int> selectedQueryMap;
	//instead of the above, use an array
	int* selectedQueryMap = new int[this->getNumOfNodes()];
	for(int i=0;i<this->getNumOfNodes();i++)
		selectedQueryMap[i]=-1;

	//add it to the selected list
	Set_Nodes_Iterator* isi = new Set_Nodes_Iterator();

	//if the restricted node ID exists, then limit its domain to the restricted node
	if(restrictedNodeID==-1)//if(restrictedDomainID==-1)
	{
		isi->se = graph->getNodesByLabel(this->getNodeWithID(nodesOrder[0])->getLabel());
		if(isi->se==NULL)
		{
			delete isi;
			delete[] selectedQueryMap;
			return;
		}
	}
	else
	{
		isi->se = new set<NodeX*>();
		isi->se->insert(graph->getNodeWithID(restrictedNodeID));
	}
	isi->it = isi->se->begin();
	selected.push_back(isi);
	FastExistenceList* selectedDataMap = new FastExistenceList(this->getNumOfNodes());//only for fast check for existence
	selectedDataMap->add(*(isi->it));
	selectedQueryMap[nodesOrder[selected.size()-1]] = (selected.size()-1);

	//list of nodes
//	NodeX** nodesList = new NodeX*[this->getNumOfNodes()];
//	for(int i=0;i<this->getNumOfNodes();i++)
//		nodesList[i] = this->getNodeWithID(i);

	//prepare nodesList for this graph
	NodeX** nodesList = new NodeX*[this->getNumOfNodes()];
	for(int i=0;i<this->getNumOfNodes();i++) {
		nodesList[i] = this->getNodeWithID(i);
	}

	long numIterations = 0;
	while(true)
	{
		numIterations++;
		//take care of the counting part
		Set_Nodes_Iterator* currentISI = selected.back();//.at(selected.size()-1);

		//cout<<"current set length = "<<currentISI->se->size()<<endl<<flush;
		while(currentISI->isIterEnd())
		{
			//if we finished the domain of the first node
			if(selected.size()==1)
			{
				delete (*(selected.begin()));
				selected.clear();
//				cout<<"numIterations = "<<numIterations<<endl;
				delete[] selectedQueryMap;
				delete[] nodesList;
				return;
			}

			//clear the data node associated with the last selected
			//selectedDataMap.erase(*(selected.back()->it));//commented on 27/10/2015
			//remove the last selected
			Set_Nodes_Iterator* tempToDel = selected.back();
			selected.pop_back();
			delete tempToDel->se;
			delete tempToDel;
			//delete the query node associated with the last selected
			selectedQueryMap[nodesOrder[selected.size()]] = -1;

			currentISI = selected.back();

			selectedDataMap->remove(*(currentISI->it));
			currentISI->it++;
			if(!currentISI->isIterEnd())//only the if line is added on 27/10/2015
				selectedDataMap->add(*(currentISI->it));
		}

		//check current status
		bool b = true;
		if(selected.size()>2)
			b = checkCurrentStatus_Fast(this, graph, selected, nodesOrder, selectedQueryMap);
		//if valid
		if(b)
		{
			//cout<<"Check result is true"<<endl;
			//I found a solution
			if(selected.size()==this->getNumOfNodes())
			{
//				cout<<"Result found ..."<<endl;
				//adding result
				results.push_back((*(*(selected.begin()))->it)->getID());

				//resetting to one selected query node
				//1- clear selected data graph nodes
				selectedDataMap->clear();
				//2- clear data graph iterators
				for(vector<Set_Nodes_Iterator* >::iterator iter = selected.begin()+1;iter!=selected.end();iter++)
					delete *iter;
				selected.erase(selected.begin()+1, selected.end());
				//3- advance the data graph nodes iterators
				selected.back()->it++;
				if(!selected.back()->isIterEnd())//only the if line is added on 27/10/2015
					selectedDataMap->add(*(selected.back()->it));
				//4- clear selected query nodes
				for(int j=1;j<this->getNumOfNodes();j++) {
					selectedQueryMap[nodesOrder[j]] = -1;
				}
			}
			else//no solution found yet!
			{
				Set_Nodes_Iterator* si = NULL;
				//get extension from current selected (last si)
				//get the index of a query node connected to the query node to be selected for the check
				NodeX* temp = NULL;

				NodeX* tempN1 = nodesList[nodesOrder[selected.size()]];//this->getNodeWithID(nodesOrder[selected.size()]);
				//NodeX* tempN1 = nodesList[nodesOrder[selected.size()]];
				vector<Set_Nodes_Iterator* >::iterator tempIT = selected.begin();
				for(int i=0;i<selected.size();i++, tempIT++)
				{
					if(tempN1->isItConnectedWithNodeID(nodesOrder[i]))
					{
						temp = (*(*tempIT)->it);
						break;
					}
				}
				if(temp==NULL)
				{
					for(int i=0;i<getNumOfNodes();i++)
						cout<<nodesOrder[i]<<",";
					cout<<"Error90892"<<flush;
					exit(0);
				}
				for(map<int, void*>::iterator iter = temp->getEdgesIterator();iter!=temp->getEdgesEndIterator();++iter)
				{
					NodeX* otherNode = ((EdgeX*)iter->second)->getOtherNode();

//					NodeX* otherNode = graph->getNodeWithID(otherNodeID);
					//check for the AC_3ed domain, to check for node occurrence, if not then no need to check it

					//check for node label
					if(otherNode->getLabel()!=tempN1->getLabel() || selectedDataMap->exists(otherNode))
						continue;

					bool b = true;
					//check for other edges
					for(map<int, void*>::iterator iter1 = tempN1->getEdgesIterator();iter1!=tempN1->getEdgesEndIterator();++iter1)
					{
						EdgeX* edge = (EdgeX*)iter1->second;
						int tempOrder = selectedQueryMap[edge->getOtherNode()->getID()];
						if(tempOrder == -1)
							continue;
						double edgeLabel = edge->getLabel();
						if(!otherNode->isItConnectedWithNodeID((*(selected[tempOrder]->it))->getID(), edgeLabel))
						{
							b = false;
							break;
						}
					}

					if(b)
					{
						if(si==NULL) {
							si = new Set_Nodes_Iterator();
							si->se = new set<NodeX*>();
						}
						si->se->insert(otherNode);
					}
				}

				//I discovered a bug when testing the efficient graph, this fix should work now, otherwise the old code is below
				if(si!=NULL)//si->se->size()>0)
				{
					si->it = si->se->begin();
					selected.push_back(si);
					selectedDataMap->add(*(si->it));
					selectedQueryMap[nodesOrder[selected.size()-1]] = (selected.size()-1);
				}
				else
				{
					/*si->it = si->se->end();
					//valgrind effect
					delete si->se;
					delete si;*/
					//
					selectedDataMap->remove(*(selected.back()->it));
					selected.back()->it++;
					if(!selected.back()->isIterEnd())//only the if line is added on 27/10/2015
						selectedDataMap->add(*(selected.back()->it));//added on 25_10_2015
				}
			}
		}
		else
		{
			//cout<<"Check result is false"<<endl;
			selectedDataMap->remove(*(selected.back()->it));
			selected.back()->it++;
			if(!selected.back()->isIterEnd())//only the if line is added on 27/10/2015
				selectedDataMap->add(*(selected.back()->it));
		}
	}

	//delete elements in selected
	for(vector<Set_Nodes_Iterator* >::iterator iter = selected.begin();iter!=selected.end();iter++)
	{
		(*iter)->se->clear();
		delete (*iter);
	}
	selected.clear();
	delete[] selectedQueryMap;
	delete[] nodesList;
}

/**
 * check whether the restricted node ID (or the list of nodes for the restricted domain) is part of this graph inside the data graph
 * if yes, then 'results' will have the list of valid graph nodes
 * 'this' is the query graph, while graph i the data graph, this means I can query this (smaller) in the data (Bigger)
 *  [*] this function does not consider edge label! FIX IT!!!!
 *  This is a PESSIMISTIC function, which means that it tries to prune the nodes around the restricted nodeID
 *  return false if it did not complete the process due to limitedIteration, otherwise return true
 */
bool GraphX::isIsomorphic_OneMatch_Fast_Pessimistic(GraphX* graph, vector<int>& results, int* plan , bool& tryOpt, int restrictedDomainID, int restrictedNodeID, long limitedIterations, vector<int>* stuckQueryNodes, tr1::unordered_map<int, int>* foundEmbedding, long* takenIterations, long int maxTime)
{
	struct timeval tp;
	gettimeofday(&tp, NULL);
	long int start = tp.tv_sec * 1000000 + tp.tv_usec;
	long int elapsed = 0;

	//pruning from the first node
	if(restrictedNodeID!=-1)
	{
		Features* graphNodeFS = (Features*)graph->getNodeWithID(restrictedNodeID)->getFeatures();
		Features* queryNodeFS = (Features*)this->getNodeWithID(restrictedDomainID)->getFeatures();
		if(graphNodeFS!=NULL && queryNodeFS!=NULL && queryNodeFS->isSatisfiedBy(graphNodeFS)==-1) {
			if(takenIterations!=NULL)
				takenIterations = 0;
			return true;
		}
	}

	//populate the order in which query graph will be traversed
	int nodesOrder[getNumOfNodes()];//the result of this part

	//get the nodes order
	if(plan==0)
	{
		tr1::unordered_set<int> checked;
		tr1::unordered_set<int> available;
		//check for the restricted node, if it exists let it be the first to check
		if(restrictedDomainID==-1)
			available.insert(nodes.begin()->second->getID());
		else
			available.insert(restrictedDomainID);

		int count = 0;
		while(available.size()>0)
		{
			//select the best node from available
			tr1::unordered_set<int>::iterator iter1 = available.begin();
			set<int>* nodesWithLabel = graph->getNodeIDsByLabel(nodes[(*iter1)]->getLabel());
			double bestScore = 0;
			if(nodesWithLabel!=NULL)
				bestScore = nodesWithLabel->size()/((double)nodes[(*iter1)]->getEdgesSize());
			int bestNode = *iter1;
			iter1++;

			for(;iter1!=available.end();++iter1)
			{
				double currScore = 0;
				nodesWithLabel = graph->getNodeIDsByLabel(nodes[(*iter1)]->getLabel());
				if(nodesWithLabel!=NULL)
					currScore = nodesWithLabel->size()/((double)nodes[(*iter1)]->getEdgesSize());
				int currID = *iter1;

				if(currScore<bestScore) {
					bestScore = currScore;
					bestNode = currID;
				}
			}

			int current = bestNode;

			available.erase(bestNode);
			if(checked.find(current)!=checked.end())
				continue;
			nodesOrder[count] = current;
			checked.insert(current);
			count++;
			NodeX* currNode = nodes[current];

			for(map<int, void*>::iterator iter = currNode->getEdgesIterator();iter!=currNode->getEdgesEndIterator();++iter)
			{
				int otherID = iter->first;
				if(checked.find(otherID)==checked.end())
				{
					available.insert(otherID);
				}
			}
		}
	}
	else
	{
		for(int i=0;i<nodes.size();i++)
		{
			nodesOrder[i] = plan[i];
		}
	}

	//print nodes order
//	cout<<"Query nodes order: ";
//	for(int i=0;i<getNumOfNodes();i++)
//		cout<<nodesOrder[i]<<",";
//	cout<<endl;

	vector<Set_Nodes_Iterator* > selected;

	//map value is query node id, value is its order *** this is one thing that you can improve
//	tr1::unordered_map<int, int> selectedQueryMap;
	//instead of the above, use an array
	int* selectedQueryMap = new int[this->getNumOfNodes()];
	for(int i=0;i<this->getNumOfNodes();i++)
		selectedQueryMap[i]=-1;

	//add it to the selected list
	Set_Nodes_Iterator* isi = new Set_Nodes_Iterator();

	//if the restricted node ID exists, then limit its domain to the restricted node
	if(restrictedNodeID==-1)//if(restrictedDomainID==-1)
	{
		isi->se = graph->getNodesByLabel(this->getNodeWithID(nodesOrder[0])->getLabel());
		if(isi->se==NULL)
		{
			delete isi;
			delete[] selectedQueryMap;

			if(takenIterations!=NULL) takenIterations = 0;

			return true;
		}
	}
	else
	{
		isi->se = new set<NodeX*>();
		isi->se->insert(graph->getNodeWithID(restrictedNodeID));
	}
	isi->it = isi->se->begin();
	selected.push_back(isi);
	FastExistenceList* selectedDataMap = new FastExistenceList(this->getNumOfNodes());//only for fast check for existence
	selectedDataMap->add(*(isi->it));
	selectedQueryMap[nodesOrder[selected.size()-1]] = (selected.size()-1);

	//list of nodes
//	NodeX** nodesList = new NodeX*[this->getNumOfNodes()];
//	for(int i=0;i<this->getNumOfNodes();i++)
//		nodesList[i] = this->getNodeWithID(i);

	//prepare nodesList for this graph
	NodeX** nodesList = new NodeX*[this->getNumOfNodes()];
	for(int i=0;i<this->getNumOfNodes();i++) {
		nodesList[i] = this->getNodeWithID(i);
	}

	long numIterations = 0;
	while(true)
	{
//		if(numIterations%100==0)
		{
			struct timeval tp;
			gettimeofday(&tp, NULL);
			long int current = tp.tv_sec * 1000000 + tp.tv_usec;

			elapsed+=(current-start);
			start = current;

			if(maxTime!=-1 && elapsed>=maxTime) {
				for(vector<Set_Nodes_Iterator* >::iterator iter = selected.begin();iter!=selected.end();iter++)
				{
					delete (*iter)->se;
					delete (*iter);
				}
				selected.clear();
				delete[] selectedQueryMap;
				delete[] nodesList;
				delete selectedDataMap;

				if(takenIterations!=NULL) *takenIterations = numIterations;

				return false;
			}
		}


#if allowThreaded
		if(Statistics::interrupt) {

			for(vector<Set_Nodes_Iterator* >::iterator iter = selected.begin();iter!=selected.end();iter++)
			{
				delete (*iter)->se;
				delete (*iter);
			}
			selected.clear();
			delete[] selectedQueryMap;
			delete[] nodesList;
			delete selectedDataMap;

//			double elapsed = TimeUtility::GetCounterMicro();
//			Statistics::threadedTime+=elapsed;
//			cout<<"Overhead P1 time = "<<elapsed<<endl;
//			TimeUtility::StartCounterMicro();

			if(takenIterations!=NULL) *takenIterations = numIterations;

			return false;
		}
#endif

		numIterations++;
		if(limitedIterations!=-1 && numIterations%(limitedIterations/10)==0)
		{
			if(numIterations%1000000==0) cout<<"numIterations = "<<numIterations<<", selected.size = "<<selected.size()<<endl;
			if(stuckQueryNodes!=NULL) {
				stuckQueryNodes->push_back(plan[selected.size()]);
//				cout<<"Adding Query node ID "<<plan[selected.size()]<<" to the stuck query nodes."<<endl;
			}
		}
		if(limitedIterations>-1 && numIterations>limitedIterations) {
			//remember to clear data here
			if(takenIterations!=NULL) *takenIterations = numIterations;
			return false;
		}
		//take care of the counting part
		Set_Nodes_Iterator* currentISI = selected.back();//.at(selected.size()-1);

		//cout<<"current set length = "<<currentISI->se->size()<<endl<<flush;
		while(currentISI->isIterEnd())
		{
			//if we finished the domain of the first node
			if(selected.size()==1)
			{
				Set_Nodes_Iterator* temp = (*(selected.begin()));
				delete temp->se;
				delete temp;
				selected.clear();
//				cout<<"numIterations = "<<numIterations<<endl;
				delete[] selectedQueryMap;
				delete[] nodesList;
				delete selectedDataMap;
				if(takenIterations!=NULL) *takenIterations = numIterations;
				return true;
			}

			//clear the data node associated with the last selected
			//selectedDataMap.erase(*(selected.back()->it));//commented on 27/10/2015
			//remove the last selected
			Set_Nodes_Iterator* tempToDel = selected.back();
			selected.pop_back();
			delete tempToDel->se;
			delete tempToDel;
			//delete the query node associated with the last selected
			selectedQueryMap[nodesOrder[selected.size()]] = -1;

			currentISI = selected.back();

			selectedDataMap->remove(*(currentISI->it));
			currentISI->it++;
			if(!currentISI->isIterEnd())//only the if line is added on 27/10/2015
				selectedDataMap->add(*(currentISI->it));
		}

		//check current status
		bool b = true;
		if(selected.size()>2)
			b = checkCurrentStatus_Fast(this, graph, selected, nodesOrder, selectedQueryMap);
//		selectedDataMap->print();cout<<endl;
		//if valid
		if(b)
		{
			//cout<<"Check result is true"<<endl;
			//I found a solution
			if(selected.size()==this->getNumOfNodes())
			{
//				cout<<"Result found ..."<<endl;
				//adding result
				results.push_back((*(*(selected.begin()))->it)->getID());

				if(foundEmbedding!=NULL)
				{
					int c = 0;
					for(vector<Set_Nodes_Iterator* >::iterator i = selected.begin();i!=selected.end();++i,c++)
					{
						foundEmbedding->insert(std::pair<int, int>(nodesOrder[c], (*((*i)->it))->getID()));
					}
				}

				//resetting to one selected query node
				//1- clear selected data graph nodes
				selectedDataMap->clear();
				//2- clear data graph iterators
				for(vector<Set_Nodes_Iterator* >::iterator iter = selected.begin()+1;iter!=selected.end();iter++) {
					delete (*iter)->se;
					delete *iter;
				}
				selected.erase(selected.begin()+1, selected.end());
				//3- advance the data graph nodes iterators
				selected.back()->it++;
				if(!selected.back()->isIterEnd())//only the if line is added on 27/10/2015
					selectedDataMap->add(*(selected.back()->it));
				//4- clear selected query nodes
				for(int j=1;j<this->getNumOfNodes();j++) {
					selectedQueryMap[nodesOrder[j]] = -1;
				}
			}
			else//no solution found yet!
			{
				Set_Nodes_Iterator* si = NULL;
				//get extension from current selected (last si)
				//get the index of a query node connected to the query node to be selected for the check
				NodeX* temp = NULL;

				NodeX* tempN1 = nodesList[nodesOrder[selected.size()]];//this->getNodeWithID(nodesOrder[selected.size()]);
				//NodeX* tempN1 = nodesList[nodesOrder[selected.size()]];
				vector<Set_Nodes_Iterator* >::iterator tempIT = selected.begin();
				for(int i=0;i<selected.size();i++, tempIT++)
				{
					if(tempN1->isItConnectedWithNodeID(nodesOrder[i]))
					{
						temp = (*(*tempIT)->it);
						break;
					}
				}
				if(temp==NULL)
				{
					for(int i=0;i<getNumOfNodes();i++)
						cout<<nodesOrder[i]<<",";
					cout<<"Error90893"<<flush;
					exit(0);
				}
				int counter = 0;
				for(map<int, void*>::iterator iter = temp->getEdgesIterator();iter!=temp->getEdgesEndIterator();++iter)
				{
					counter++;
					if(maxTime!=-1 && counter%10==0)
					{
						struct timeval tp;
						gettimeofday(&tp, NULL);
						long int current = tp.tv_sec * 1000000 + tp.tv_usec;

						elapsed+=(current-start);
						start = current;

						if(maxTime!=-1 && elapsed>=maxTime) {
							for(vector<Set_Nodes_Iterator* >::iterator iter = selected.begin();iter!=selected.end();iter++)
							{
								delete (*iter)->se;
								delete (*iter);
							}
							selected.clear();
							delete[] selectedQueryMap;
							delete[] nodesList;
							delete selectedDataMap;
							if(si!=NULL)
							{
								delete si->se;
								delete si;
							}

							if(takenIterations!=NULL) *takenIterations = numIterations;

							return false;
						}
					}

#if allowThreaded
					if(Statistics::interrupt) {

						for(vector<Set_Nodes_Iterator* >::iterator iter = selected.begin();iter!=selected.end();iter++)
						{
							delete (*iter)->se;
							delete (*iter);
						}
						selected.clear();
						delete[] selectedQueryMap;
						delete[] nodesList;
						delete selectedDataMap;
						if(si!=NULL)
						{
							delete si->se;
							delete si;
						}

//						double elapsed = TimeUtility::GetCounterMicro();
//						Statistics::threadedTime+=elapsed;
//						cout<<"Overhead P2 time = "<<elapsed<<endl;
//						TimeUtility::StartCounterMicro();

						if(takenIterations!=NULL) *takenIterations = numIterations;

						return false;
					}
#endif

					//if I am fiding a node with high degree, let us give optimistic a try!
					/*if(temp->getEdgesSize()>5000 && !tryOpt) {
						tryOpt = true;

						for(vector<Set_Nodes_Iterator* >::iterator iter = selected.begin();iter!=selected.end();iter++)
						{
							delete (*iter)->se;
							delete (*iter);
						}
						selected.clear();
						delete[] selectedQueryMap;
						delete[] nodesList;
						delete selectedDataMap;
						if(si!=NULL)
						{
							delete si->se;
							delete si;
						}

						return false;
					}*/

					NodeX* otherNode = ((EdgeX*)iter->second)->getOtherNode();

//					if(otherNode->getID()==420)
//						cout<<"1*";

//					NodeX* otherNode = graph->getNodeWithID(otherNodeID);
					//check for the AC_3ed domain, to check for node occurrence, if not then no need to check it

					//check for node label
					if(otherNode->getLabel()!=tempN1->getLabel() || selectedDataMap->exists(otherNode))
						continue;

//					if(otherNode->getID()==420)
//						cout<<"2*";

					//aggressive pessimistic check
					Features* graphNodeFS = (Features*)otherNode->getFeatures();
					Features* queryNodeFS = (Features*)tempN1->getFeatures();
					if(graphNodeFS!=NULL && queryNodeFS!=NULL && queryNodeFS->isSatisfiedBy(graphNodeFS)==-1)
						continue;

//					if(otherNode->getID()==420)
//						cout<<"3*";

					bool b = true;
					//check for other edges
					for(map<int, void*>::iterator iter1 = tempN1->getEdgesIterator();iter1!=tempN1->getEdgesEndIterator();++iter1)
					{
						EdgeX* edge = (EdgeX*)iter1->second;
						int tempOrder = selectedQueryMap[edge->getOtherNode()->getID()];
						if(tempOrder == -1)
							continue;
						double edgeLabel = edge->getLabel();
						if(!otherNode->isItConnectedWithNodeID((*(selected[tempOrder]->it))->getID(), edgeLabel))
						{
							b = false;
							break;
						}
					}

					if(b)
					{
						if(si==NULL) {
							si = new Set_Nodes_Iterator();
							si->se = new set<NodeX*>();
						}
						si->se->insert(otherNode);
//						cout<<"N#"<<otherNode->getID()<<endl;
					}
				}

				//I discovered a bug when testing the efficient graph, this fix should work now, otherwise the old code is below
				if(si!=NULL)//si->se->size()>0)
				{
					si->it = si->se->begin();
					selected.push_back(si);
					selectedDataMap->add(*(si->it));
					selectedQueryMap[nodesOrder[selected.size()-1]] = (selected.size()-1);
				}
				else
				{
					/*si->it = si->se->end();
					//valgrind effect
					delete si->se;
					delete si;*/
					//
					selectedDataMap->remove(*(selected.back()->it));
					selected.back()->it++;
					if(!selected.back()->isIterEnd())//only the if line is added on 27/10/2015
						selectedDataMap->add(*(selected.back()->it));//added on 25_10_2015
				}
			}
		}
		else
		{
			//cout<<"Check result is false"<<endl;
			selectedDataMap->remove(*(selected.back()->it));
			selected.back()->it++;
			if(!selected.back()->isIterEnd())//only the if line is added on 27/10/2015
				selectedDataMap->add(*(selected.back()->it));
		}
	}

	//delete elements in selected
	for(vector<Set_Nodes_Iterator* >::iterator iter = selected.begin();iter!=selected.end();iter++)
	{
		(*iter)->se->clear();
		delete (*iter);
	}
	selected.clear();
	delete[] selectedQueryMap;
	delete[] nodesList;

	delete selectedDataMap;

	if(takenIterations!=NULL) *takenIterations = numIterations;

	return true;
}

/**
 * check whether the restricted node ID (or the list of nodes for the restricted domain) is part of this graph inside the data graph
 * if yes, then 'results' will have the list of valid graph nodes
 * 'this' is the query graph, while graph i the data graph, this means I can query this (smaller) in the data (Bigger)
 *  [*] this function does not consider edge label! FIX IT!!!!
 *  This is a PESSIMISTIC function, which means that it tries to prune the nodes around the restricted nodeID
 *  return false if it did not complete the process due to limitedIteration, otherwise return true
 */
bool GraphX::isIsomorphic_OneMatch_Fast_Pessimistic_2(GraphX* graph, vector<int>& results, int* plan , int restrictedDomainID, int restrictedNodeID, long limitedIterations, vector<int>* stuckQueryNodes, tr1::unordered_map<int, int>* foundEmbedding, int* weights)
{
	//pruning from the first node
	if(restrictedNodeID!=-1)
	{
		Features* graphNodeFS = (Features*)graph->getNodeWithID(restrictedNodeID)->getFeatures();
		Features* queryNodeFS = (Features*)this->getNodeWithID(restrictedDomainID)->getFeatures();
		if(graphNodeFS!=NULL && queryNodeFS!=NULL && queryNodeFS->isSatisfiedBy(graphNodeFS)==-1)
			return true;
	}

	//populate the order in which query graph will be traversed
	int nodesOrder[getNumOfNodes()];//the result of this part

	//get the nodes order
	if(plan==0)
	{
		tr1::unordered_set<int> checked;
		tr1::unordered_set<int> available;
		//check for the restricted node, if it exists let it be the first to check
		if(restrictedDomainID==-1)
			available.insert(nodes.begin()->second->getID());
		else
			available.insert(restrictedDomainID);

		int count = 0;
		while(available.size()>0)
		{
			//select the best node from available
			tr1::unordered_set<int>::iterator iter1 = available.begin();
			set<int>* nodesWithLabel = graph->getNodeIDsByLabel(nodes[(*iter1)]->getLabel());
			double bestScore = 0;
			if(nodesWithLabel!=NULL)
				bestScore = nodesWithLabel->size()/((double)nodes[(*iter1)]->getEdgesSize());
			int bestNode = *iter1;
			iter1++;

			for(;iter1!=available.end();++iter1)
			{
				double currScore = 0;
				nodesWithLabel = graph->getNodeIDsByLabel(nodes[(*iter1)]->getLabel());
				if(nodesWithLabel!=NULL)
					currScore = nodesWithLabel->size()/((double)nodes[(*iter1)]->getEdgesSize());
				int currID = *iter1;

				if(currScore<bestScore) {
					bestScore = currScore;
					bestNode = currID;
				}
			}

			int current = bestNode;

			available.erase(bestNode);
			if(checked.find(current)!=checked.end())
				continue;
			nodesOrder[count] = current;
			checked.insert(current);
			count++;
			NodeX* currNode = nodes[current];

			for(map<int, void*>::iterator iter = currNode->getEdgesIterator();iter!=currNode->getEdgesEndIterator();++iter)
			{
				int otherID = iter->first;
				if(checked.find(otherID)==checked.end())
				{
					available.insert(otherID);
				}
			}
		}
	}
	else
	{
		for(int i=0;i<nodes.size();i++)
		{
			nodesOrder[i] = plan[i];
			//cout<<"i = "<<i<<",plan[i] = "<<plan[i]<<endl<<flush;
		}
	}

	//print nodes order
//	cout<<"Query nodes order: ";
//	for(int i=0;i<getNumOfNodes();i++)
//		cout<<nodesOrder[i]<<",";
//	cout<<endl;

	vector<Edge_Iterator* > selected;

	//map value is query node id, value is its order *** this is one thing that you can improve
//	tr1::unordered_map<int, int> selectedQueryMap;
	//instead of the above, use an array
	int* selectedQueryMap = new int[this->getNumOfNodes()];
	for(int i=0;i<this->getNumOfNodes();i++)
		selectedQueryMap[i]=-1;

	//add it to the selected list
	map<int, void*> tempM;
	EdgeX* tempEdge = new EdgeX(1, graph->getNodeWithID(restrictedNodeID));
	tempM.insert(std::pair<int, void*>(restrictedNodeID, tempEdge));
	Edge_Iterator* isi = new Edge_Iterator(tempM.begin(), tempM.end());

	selected.push_back(isi);
	FastExistenceList* selectedDataMap = new FastExistenceList(this->getNumOfNodes());//only for fast check for existence
	//selectedDataMap->add(isi->getCurrentNode());
	selectedQueryMap[nodesOrder[selected.size()-1]] = (selected.size()-1);

	//list of nodes
//	NodeX** nodesList = new NodeX*[this->getNumOfNodes()];
//	for(int i=0;i<this->getNumOfNodes();i++)
//		nodesList[i] = this->getNodeWithID(i);

	//prepare nodesList for this graph
	NodeX** nodesList = new NodeX*[this->getNumOfNodes()];
	for(int i=0;i<this->getNumOfNodes();i++) {
		nodesList[i] = this->getNodeWithID(i);
	}

	long numIterations = 0;
	while(true)
	{
//		cout<<"-->"<<selected.size()<<endl<<flush;
#if allowThreaded
		if(Statistics::interrupt) {
			delete tempEdge;
			for(vector<Edge_Iterator* >::iterator iter = selected.begin();iter!=selected.end();iter++)
			{
				delete (*iter);
			}
			selected.clear();
			delete[] selectedQueryMap;
			delete[] nodesList;
			delete selectedDataMap;

//			double elapsed = TimeUtility::GetCounterMicro();
//			Statistics::threadedTime+=elapsed;
//			cout<<"Overhead P1 time = "<<elapsed<<endl;
//			TimeUtility::StartCounterMicro();

			return false;
		}
#endif
		bool b = true;
		//aggressive pessimistic check
		if(!selected.back()->isIterEnd())
		{
			NodeX* graphNode = selected[selected.size()-1]->getCurrentNode();
			NodeX* queryNode = this->getNodeWithID(nodesOrder[selected.size()-1]);

			if(graphNode->getLabel()!=queryNode->getLabel() || selectedDataMap->exists(graphNode))  {
//				selectedDataMap->remove(selected.back()->getCurrentNode());
				selected.back()->advance();
//				if(!selected.back()->isIterEnd())//only the if line is added on 27/10/2015
//					selectedDataMap->add(selected.back()->getCurrentNode());
				continue;
			}

//			cout<<"selected.size() = "<<selected.size()<<endl<<flush;
			Features* graphNodeFS = ((Features*)graphNode->getFeatures());
			Features* queryNodeFS = ((Features*)queryNode->getFeatures());

			if(graphNodeFS!=NULL && queryNodeFS!=NULL && queryNodeFS->isSatisfiedBy(graphNodeFS)==-1) {
//				selectedDataMap->remove(selected.back()->getCurrentNode());
				selected.back()->advance();
//				if(!selected.back()->isIterEnd())//only the if line is added on 27/10/2015
//					selectedDataMap->add(selected.back()->getCurrentNode());
				continue;
			}
			//check current status
			if(selected.size()>2)
				b = checkCurrentStatus_Fast_2(this, graph, selected, nodesOrder, selectedQueryMap);
			if(!b) {
//				selectedDataMap->remove(selected.back()->getCurrentNode());
				selected.back()->advance();
//				if(!selected.back()->isIterEnd())//only the if line is added on 27/10/2015
//				{
//					cout<<"2.4.3"<<endl<<flush;
//					selectedDataMap->add(selected.back()->getCurrentNode());
//					cout<<"2.4.4"<<endl<<flush;
//				}
				continue;
			}

			selectedDataMap->add(selected.back()->getCurrentNode());
		}

		numIterations++;
		if(selected.size()<this->getNumOfNodes()) {
			weights[plan[selected.size()]]++;
		}

		if(limitedIterations!=-1 && numIterations%(limitedIterations/10)==0)
		{
			if(numIterations%1000000==0) cout<<"numIterations = "<<numIterations<<", selected.size = "<<selected.size()<<endl;
			if(stuckQueryNodes!=NULL) {
				stuckQueryNodes->push_back(plan[selected.size()]);
//				cout<<"Adding Query node ID "<<plan[selected.size()]<<" to the stuck query nodes."<<endl;
			}
		}
		if(limitedIterations>-1 && numIterations>limitedIterations) {
			//remember to clear data here
			delete tempEdge;
			return false;
		}
		//take care of the counting part
		Edge_Iterator* currentISI = selected.back();//.at(selected.size()-1);
		//cout<<"current set length = "<<currentISI->se->size()<<endl<<flush;
		if(currentISI->isIterEnd())
		{
			while(currentISI->isIterEnd())
			{
				//if we finished the domain of the first node
				if(selected.size()==1)
				{
					delete tempEdge;
					Edge_Iterator* temp = (*(selected.begin()));
					delete temp;
					selected.clear();
	//				cout<<"numIterations = "<<numIterations<<endl;
					delete[] selectedQueryMap;
					delete[] nodesList;
					delete selectedDataMap;
					return true;
				}

				//clear the data node associated with the last selected
				//selectedDataMap.erase(*(selected.back()->it));//commented on 27/10/2015
				//remove the last selected
				Edge_Iterator* tempToDel = selected.back();
				selected.pop_back();
				delete tempToDel;
				//delete the query node associated with the last selected
				selectedQueryMap[nodesOrder[selected.size()]] = -1;

				currentISI = selected.back();

				selectedDataMap->remove(currentISI->getCurrentNode());
				currentISI->advance();
	//			if(!currentISI->isIterEnd())//only the if line is added on 27/10/2015
	//				selectedDataMap->add(currentISI->getCurrentNode());
			}
			continue;
		}
//		selectedDataMap->print();cout<<endl;
		//if valid
		if(b)
		{
			//cout<<"Check result is true"<<endl;
			//I found a solution
			if(selected.size()==this->getNumOfNodes())
			{
//				cout<<"Result found ..."<<endl;
//				selectedDataMap->print();
				//adding result
				results.push_back((*(selected.begin()))->getCurrentNode()->getID());

				if(foundEmbedding!=NULL)
				{
					int c = 0;
					for(vector<Edge_Iterator* >::iterator i = selected.begin();i!=selected.end();++i,c++)
					{
						foundEmbedding->insert(std::pair<int, int>(nodesOrder[c], ((*i)->getCurrentNode())->getID()));
					}
				}

				//resetting to one selected query node
				//1- clear selected data graph nodes
				selectedDataMap->clear();
				//2- clear data graph iterators
				for(vector<Edge_Iterator* >::iterator iter = selected.begin()+1;iter!=selected.end();iter++) {
					delete *iter;
				}
				selected.erase(selected.begin()+1, selected.end());
				//3- advance the data graph nodes iterators
				selected.back()->advance();
//				if(!selected.back()->isIterEnd())//only the if line is added on 27/10/2015
//					selectedDataMap->add(selected.back()->getCurrentNode());
				//4- clear selected query nodes
				for(int j=1;j<this->getNumOfNodes();j++) {
					selectedQueryMap[nodesOrder[j]] = -1;
				}
			}
			else//no solution found yet!
			{
				Edge_Iterator* si = NULL;
				//get extension from current selected (last si)
				//get the index of a query node connected to the query node to be selected for the check
				NodeX* temp = NULL;

				NodeX* tempN1 = nodesList[nodesOrder[selected.size()]];//this->getNodeWithID(nodesOrder[selected.size()]);
				//NodeX* tempN1 = nodesList[nodesOrder[selected.size()]];
				vector<Edge_Iterator* >::iterator tempIT = selected.begin();
				for(int i=0;i<selected.size();i++, tempIT++)
				{
					if(tempN1->isItConnectedWithNodeID(nodesOrder[i]))
					{
						temp = (*tempIT)->getCurrentNode();
						break;
					}
				}
				if(temp==NULL)
				{
					for(int i=0;i<getNumOfNodes();i++)
						cout<<nodesOrder[i]<<",";
					cout<<"Error90893"<<flush;
					exit(0);
				}

				si = new Edge_Iterator(temp->getEdgesIterator(), temp->getEdgesEndIterator());

				selected.push_back(si);
//				selectedDataMap->add(si->getCurrentNode());
				selectedQueryMap[nodesOrder[selected.size()-1]] = (selected.size()-1);
			}
		}
		else
		{
			//cout<<"Check result is false"<<endl;
			selectedDataMap->remove(selected.back()->getCurrentNode());
			selected.back()->advance();
//			if(!selected.back()->isIterEnd())//only the if line is added on 27/10/2015
//				selectedDataMap->add(selected.back()->getCurrentNode());
		}
	}
	delete tempEdge;
	//delete elements in selected
	for(vector<Edge_Iterator* >::iterator iter = selected.begin();iter!=selected.end();iter++)
	{
		delete (*iter);
	}
	selected.clear();
	delete[] selectedQueryMap;
	delete[] nodesList;

	delete selectedDataMap;
	return true;
}

/**
 * do subgraph isomorphism based on a limited number of iterations.
 * If exceeded, plan is modified.
 * type: 0- Pessimistic, 1- Optimistic
 */
bool GraphX::isIsomorphic_IterativePlanModification(GraphX* graph,
		vector<int>& results,
		int* plan,
		int type,
		int restrictedDomainID,
		int restrictedNodeID,
		long limitedIterations,
		vector<tr1::unordered_map<int, int>*>* embeddings,
		bool doNotModifyPlansForIncorrectPrediction,
		int temp) {
//cout<<"restrictedNodeID = "<<restrictedNodeID<<endl;
//	int *modifiedPlan = new int[this->getNumOfNodes()];
//	for(int i=0;i<this->getNumOfNodes();i++)
//		modifiedPlan[i] = plan[i];

//	int* modifiedPlan = plan;
	int* modifiedPlan = new int[this->getNumOfNodes()];//added 22-4-2017 DDD
	for(int i=0;i<this->getNumOfNodes();i++)
		modifiedPlan[i] = plan[i];

	tr1::unordered_set<int> visitedNodes;

	vector<int>* stuckQueryNodes = new vector<int>();
	bool oneIterPassed = false;
	//keep running isomorphism with a specific number of iterations,
	int* oldPlan=NULL;
	bool tryOpt = false;
	bool tryOptUsed = false;
	while(true) {

//		cout<<"Plan: ";
//		for(int i=0;i<this->getNumOfNodes();i++)
//			cout<<modifiedPlan[i]<<",";
//		cout<<endl;

		bool b;
		if(type==0) {
			tr1::unordered_map<int, int>* embedding = NULL;

			if(embeddings!=NULL)
				embedding = new tr1::unordered_map<int, int>();

			if(temp==1) {
				b = isIsomorphic_OneMatch_Fast_Pessimistic(graph,
					results,
					modifiedPlan,
					tryOpt,
					restrictedDomainID,
					restrictedNodeID,
					limitedIterations,
					stuckQueryNodes,
					embedding);
			} else if(temp==2) {
				b = isIsomorphic_OneMatch_Fast_Pessimistic(graph,
					results,
					modifiedPlan,
					tryOpt,
					restrictedDomainID,
					restrictedNodeID,
					limitedIterations,
					stuckQueryNodes,
					embedding);
			}

			if(embeddings!=NULL && embedding->size()>0) {

				bool add = true;
				for(vector<tr1::unordered_map<int, int>*>::iterator it1 = embeddings->begin();it1!=embeddings->end();it1++) {

					tr1::unordered_map<int, int>* oneEmbed = (*it1);
					bool similar = true;
					for(tr1::unordered_map<int, int>::iterator it2 = oneEmbed->begin();it2!=oneEmbed->end();it2++) {
						int qnid = it2->first;
						if(qnid==0) continue;
						int gnid = it2->second;

						int value = embedding->find(qnid)->second;
						if(value!=gnid) {
							similar = false;
							break;
						}
					}

					if(similar) {
						add = false;
						break;
					}

				}

				if(add)
					embeddings->push_back(embedding);
			}
			else
				delete embedding;
		}
		else if(type==1) {
			b = isIsomorphic_OneMatch_Fast_Optimistic(graph,
				results,
				modifiedPlan,
				restrictedDomainID,
				restrictedNodeID,
				limitedIterations,
				stuckQueryNodes);
		}

		if(b==true) {
//			if(oneIterPassed) cout<<"Happily done!"<<endl;
			if(doNotModifyPlansForIncorrectPrediction)
			{
				bool correct = false;
				if((type==0 && results.size()==0) ||
						(type==1 && results.size()!=0))
					correct = true;

//				cout<<"correct = "<<correct<<", oldPlan = "<<oldPlan<<endl;

				if(oldPlan!=NULL && !correct)
				{
					//copy the old plan to the used plan
					for(int i=0;i<this->getNumOfNodes();i++) {
						modifiedPlan[i] = oldPlan[i];
//						cout<<"Plan not modified!"<<endl;
					}
				}
			}
			break;
		}

		if(tryOpt && !tryOptUsed) {
			tryOptUsed = true;
			isIsomorphic_OneMatch_Fast_Super_Optimistic(graph, results, modifiedPlan, restrictedDomainID, restrictedNodeID, 10);

			if(results.size()==0)
				isIsomorphic_OneMatch_Fast_Super_Optimistic(graph, results, modifiedPlan, restrictedDomainID, restrictedNodeID, 10, NULL, true);

			if(results.size()!=0) {
//				cout<<"Good";
				break;
			}
			else {
//				cout<<endl;
				continue;
			}
		}

#if allowThreaded
	if(Statistics::interrupt) {
		delete stuckQueryNodes;
		if(oldPlan!=NULL) delete[] oldPlan;
		delete[] modifiedPlan;//DDD
		return false;
	}
#endif

		if(doNotModifyPlansForIncorrectPrediction)
		{
			if(oldPlan==NULL) oldPlan = new int[this->getNumOfNodes()];
			for(int i=0;i<this->getNumOfNodes();i++) {
				oldPlan[i] = modifiedPlan[i];
			}
		}

		oneIterPassed = true;

		cout<<"Modifiying the plan ...";

		//query is not done using the given query plan
		//get the stuck query node
		int max = 0;
		int selectedQNID = -1;
		for(int i=0;i<this->getNumOfNodes();i++) {

			//ignore this node if it was repositioned before
			if(visitedNodes.find(i)!=visitedNodes.end())
				continue;

			int count = 0;
			for(vector<int>::iterator iter = stuckQueryNodes->begin();iter!=stuckQueryNodes->end();iter++) {
				if(i==(*iter))
					count++;
			}
			if(count>max)
				selectedQNID = i;
		}

		if(selectedQNID==-1) {
			limitedIterations = -1;
			stuckQueryNodes = NULL;
			continue;
		}

		stuckQueryNodes->clear();

		cout<<"Selected query node is: "<<selectedQNID<<endl;
		visitedNodes.insert(selectedQNID);

//		if(!putInLaterPosition(this->getNodeWithID(selectedQNID), modifiedPlan, this->getNumOfNodes(), graph)) {
		if(!putInEarlierPosition(this->getNodeWithID(selectedQNID), modifiedPlan, this->getNumOfNodes())) {
			limitedIterations = -1;
			stuckQueryNodes = NULL;
		}
	}

//	delete[] modifiedPlan;
	delete stuckQueryNodes;
	if(oldPlan!=NULL) delete[] oldPlan;
	delete[] modifiedPlan;//DDD
	return true;
}

/**
 * do subgraph isomorphism based on a limited number of iterations.
 * If exceeded, plan is modified.
 * type: 0- Pessimistic, 1- Optimistic
 */
bool GraphX::isIsomorphic_IterativePlanModification_2(GraphX* graph,
		vector<int>& results,
		int* plan,
		int type,
		int restrictedDomainID,
		int restrictedNodeID,
		long limitedIterations,
		vector<tr1::unordered_map<int, int>*>* embeddings,
		bool doNotModifyPlansForIncorrectPrediction,
		int temp) {
//cout<<"restrictedNodeID = "<<restrictedNodeID<<endl;
//	int *modifiedPlan = new int[this->getNumOfNodes()];
//	for(int i=0;i<this->getNumOfNodes();i++)
//		modifiedPlan[i] = plan[i];

	int* modifiedPlan = plan;

	tr1::unordered_set<int> visitedNodes;

	vector<int>* stuckQueryNodes = new vector<int>();
	bool oneIterPassed = false;
	//keep running isomorphism with a specific number of iterations,
	int* oldPlan=NULL;

	//create weights
	int* weights = new int[this->getNumOfNodes()];

	set<long> check;

	bool tryOpt = false;

	while(true) {
		for(int i=0;i<this->getNumOfNodes();i++)
			weights[i] = 0;

		bool b;
		if(type==0) {
			tr1::unordered_map<int, int>* embedding = NULL;

			if(embeddings!=NULL)
				embedding = new tr1::unordered_map<int, int>();

			if(temp==1) {
				b = isIsomorphic_OneMatch_Fast_Pessimistic(graph,
					results,
					modifiedPlan,
					tryOpt,
					restrictedDomainID,
					restrictedNodeID,
					limitedIterations,
					stuckQueryNodes,
					embedding);
			} else if(temp==2) {
				b = isIsomorphic_OneMatch_Fast_Pessimistic_2(graph,
					results,
					modifiedPlan,
					restrictedDomainID,
					restrictedNodeID,
					limitedIterations,
					stuckQueryNodes,
					embedding,
					weights);
			}
			if(embeddings!=NULL && embedding->size()>0) {

				bool add = true;
				for(vector<tr1::unordered_map<int, int>*>::iterator it1 = embeddings->begin();it1!=embeddings->end();it1++) {

					tr1::unordered_map<int, int>* oneEmbed = (*it1);
					bool similar = true;
					for(tr1::unordered_map<int, int>::iterator it2 = oneEmbed->begin();it2!=oneEmbed->end();it2++) {
						int qnid = it2->first;
						if(qnid==0) continue;
						int gnid = it2->second;

						int value = embedding->find(qnid)->second;
						if(value!=gnid) {
							similar = false;
							break;
						}
					}

					if(similar) {
						add = false;
						break;
					}

				}

				if(add)
					embeddings->push_back(embedding);
			}
			else
				delete embedding;
		}
		else if(type==1) {
			b = isIsomorphic_OneMatch_Fast_Optimistic(graph,
				results,
				modifiedPlan,
				restrictedDomainID,
				restrictedNodeID,
				limitedIterations,
				stuckQueryNodes);
		}

		if(b==true) {
//			if(oneIterPassed) cout<<"Happily done!"<<endl;
			if(doNotModifyPlansForIncorrectPrediction)
			{
				bool correct = false;
				if((type==0 && results.size()==0) ||
						(type==1 && results.size()!=0))
					correct = true;

				if(oldPlan!=NULL && !correct)
				{
					for(int i=0;i<this->getNumOfNodes();i++) {
						modifiedPlan[i] = oldPlan[i];
					}
				}
			}
			break;
		}

#if allowThreaded
	if(Statistics::interrupt) {
		delete stuckQueryNodes;
		if(oldPlan!=NULL) delete[] oldPlan;
		delete weights;
		return false;
	}
#endif

		if(doNotModifyPlansForIncorrectPrediction)
		{
			if(oldPlan==NULL) oldPlan = new int[this->getNumOfNodes()];
			for(int i=0;i<this->getNumOfNodes();i++) {
				oldPlan[i] = modifiedPlan[i];
			}
		}

		oneIterPassed = true;

		cout<<"Modifiying the plan. [OLD]:";
		for(int i=0;i<this->getNumOfNodes();i++)
			cout<<modifiedPlan[i]<<",";
		int* tempPlan = this->generateWeightsBasedPlan(restrictedDomainID, weights, graph);
		cout<<". [NEW]: ";
		int v = 0;
		for(int i=0;i<this->getNumOfNodes();i++) {
			modifiedPlan[i] = tempPlan[i];
			cout<<modifiedPlan[i]<<",";
			v = v + (i*modifiedPlan[i]);
		}
		cout<<endl;
		if(check.find(v)!=check.end())
			limitedIterations = -1;
		else
			check.insert(v);
	}

//	delete[] modifiedPlan;
	delete stuckQueryNodes;
	if(oldPlan!=NULL) delete[] oldPlan;
	delete[] weights;
	return true;
}


/**
 * do subgraph isomorphism based on a limited number of iterations.
 * If exceeded, plan is modified.
 * type: 0- Pessimistic, 1- Optimistic
 */
bool GraphX::isIsomorphic_IterativePlanModification(GraphX* graph,
		vector<int>& results,
		int* plan,
		tr1::unordered_map<string, int*>* sigToPlan,
		int type,
		int restrictedDomainID,
		int restrictedNodeID,
		long limitedIterations) {

	int* modifiedPlan;

	//assign a plan for this node
	tr1::unordered_map<string, int*>::iterator planIter;
	NodeX* node = graph->getNodeWithID(restrictedNodeID);
	string featuresKey = node->getFeaturesKey();
	modifiedPlan = new int[this->getNumOfNodes()];
	if(sigToPlan!=NULL) {
		planIter = sigToPlan->find(featuresKey);
		for(int i=0;i<this->getNumOfNodes();i++) {
			if(planIter==sigToPlan->end()) {
				modifiedPlan[i] = plan[i];
			} else {
				modifiedPlan[i] = planIter->second[i];
			}
		}
	}
	else {
		for(int i=0;i<this->getNumOfNodes();i++) {
			modifiedPlan[i] = plan[i];
		}
	}


	tr1::unordered_set<int> visitedNodes;

	vector<int>* stuckQueryNodes = new vector<int>();
	bool oneIterPassed = false;
	//keep running isomorphism with a specific number of iterations,
	bool tryOpt = false;
	bool tryOptUsed = false;
	while(true) {

//		cout<<"Plan: ";
//		for(int i=0;i<this->getNumOfNodes();i++)
//			cout<<modifiedPlan[i]<<",";
//		cout<<endl;

		bool b;
		if(type==0) {

			b = isIsomorphic_OneMatch_Fast_Pessimistic(graph,
				results,
				modifiedPlan,
				tryOpt,
				restrictedDomainID,
				restrictedNodeID,
				limitedIterations,
				stuckQueryNodes,
				NULL);
		}
		else if(type==1) {
			b = isIsomorphic_OneMatch_Fast_Optimistic(graph,
				results,
				modifiedPlan,
				restrictedDomainID,
				restrictedNodeID,
				limitedIterations,
				stuckQueryNodes);
		}

//		cout<<b<<endl;

		if(b==true) {

			//store a non-existing plan
			if(sigToPlan!=NULL && planIter==sigToPlan->end()) {
				int* tempPlan = new int[this->getNumOfNodes()];
				for(int i=0;i<this->getNumOfNodes();i++) {
					tempPlan[i] = modifiedPlan[i];
				}
				sigToPlan->insert(std::pair<string, int* >(featuresKey, tempPlan));
			}

			break;
		}

		if(tryOpt && !tryOptUsed) {
			tryOptUsed = true;
			isIsomorphic_OneMatch_Fast_Super_Optimistic(graph, results, modifiedPlan, restrictedDomainID, restrictedNodeID, 10);

			if(results.size()==0)
				isIsomorphic_OneMatch_Fast_Super_Optimistic(graph, results, modifiedPlan, restrictedDomainID, restrictedNodeID, 10, NULL, true);

			if(results.size()!=0) {
//				cout<<"Good";
				break;
			}
			else {
//				cout<<endl;
				continue;
			}
		}

#if allowThreaded
	if(Statistics::interrupt) {
		delete stuckQueryNodes;
		delete[] modifiedPlan;//DDD
		return false;
	}
#endif

		oneIterPassed = true;

		cout<<"Modifiying the plan ...";

		//query is not done using the given query plan
		//get the stuck query node
		int max = 0;
		int selectedQNID = -1;
		for(int i=0;i<this->getNumOfNodes();i++) {

			//ignore this node if it was repositioned before
			if(visitedNodes.find(i)!=visitedNodes.end())
				continue;

			int count = 0;
			for(vector<int>::iterator iter = stuckQueryNodes->begin();iter!=stuckQueryNodes->end();iter++) {
				if(i==(*iter))
					count++;
			}
			if(count>max)
				selectedQNID = i;
		}

		if(selectedQNID==-1) {
			limitedIterations = -1;
			stuckQueryNodes = NULL;
			continue;
		}

		stuckQueryNodes->clear();

		cout<<"Selected query node is: "<<selectedQNID<<endl;
		visitedNodes.insert(selectedQNID);

		if(!putInEarlierPosition(this->getNodeWithID(selectedQNID), modifiedPlan, this->getNumOfNodes())) {
			limitedIterations = -1;
			stuckQueryNodes = NULL;
		}
	}

	delete stuckQueryNodes;
	delete[] modifiedPlan;//DDD
	return true;
}


/**
 * check whether the restricted node ID (or the list of nodes for the restricted domain) is part of this graph inside the data graph
 * if yes, then 'results' will have the list of valid graph nodes
 * 'this' is the query graph, while graph i the data graph, this means I can query this (smaller) in the data (Bigger)
 *  [*] this function does not consider edge label! FIX IT!!!!
 *  This is an OPTIMISTIC approach where the goal is to find a solution ASAP!
 *  This is done by??
 */
bool GraphX::isIsomorphic_OneMatch_Fast_Optimistic(GraphX* graph, vector<int>& results, int* plan , int restrictedDomainID, int restrictedNodeID, long limitedIterations, vector<int>* stuckQueryNodes, long* takenIterations, long int maxTime)
{
	struct timeval tp;
	gettimeofday(&tp, NULL);
	long int start = tp.tv_sec * 1000000 + tp.tv_usec;
	long int elapsed = 0;

	//populate the order in which query graph will be traversed
	int nodesOrder[getNumOfNodes()];//the result of this part

	//get the nodes order
	if(plan==0)
	{
		tr1::unordered_set<int> checked;
		tr1::unordered_set<int> available;
		//check for the restricted node, if it exists let it be the first to check
		if(restrictedDomainID==-1)
			available.insert(nodes.begin()->second->getID());
		else
			available.insert(restrictedDomainID);

		int count = 0;
		while(available.size()>0)
		{
			//select the best node from available
			tr1::unordered_set<int>::iterator iter1 = available.begin();
			set<int>* nodesWithLabel = graph->getNodeIDsByLabel(nodes[(*iter1)]->getLabel());
			double bestScore = 0;
			if(nodesWithLabel!=NULL)
				//bestScore = /*nodesWithLabel->size()**/((double)nodes[(*iter1)]->getEdgesSize());///((double)nodes[(*iter1)]->getEdgesSize());
				bestScore = nodesWithLabel->size()/((double)nodes[(*iter1)]->getEdgesSize());//original scoring
			int bestNode = *iter1;
			iter1++;

			for(;iter1!=available.end();++iter1)
			{
				double currScore = 0;
				nodesWithLabel = graph->getNodeIDsByLabel(nodes[(*iter1)]->getLabel());
				if(nodesWithLabel!=NULL)
					//currScore = /*nodesWithLabel->size()**/((double)nodes[(*iter1)]->getEdgesSize());///((double)nodes[(*iter1)]->getEdgesSize());
					currScore = nodesWithLabel->size()/((double)nodes[(*iter1)]->getEdgesSize());//original scoring
				int currID = *iter1;

				if(currScore<bestScore) {
					bestScore = currScore;
					bestNode = currID;
				}
			}

			int current = bestNode;

			available.erase(bestNode);
			if(checked.find(current)!=checked.end())
				continue;
			nodesOrder[count] = current;
			checked.insert(current);
			count++;
			NodeX* currNode = nodes[current];

			for(map<int, void*>::iterator iter = currNode->getEdgesIterator();iter!=currNode->getEdgesEndIterator();++iter)
			{
				int otherID = iter->first;
				if(checked.find(otherID)==checked.end())
				{
					available.insert(otherID);
				}
			}
		}
	}
	else
	{
		for(int i=0;i<nodes.size();i++)
		{
			nodesOrder[i] = plan[i];
		}
	}

	//print nodes order
//	cout<<"Query nodes order: ";
//	for(int i=0;i<getNumOfNodes();i++)
//		cout<<nodesOrder[i]<<",";
//	cout<<endl;

	vector<Set_Nodes_Prioritized_Iterator* > selected;

	//map value is query node id, value is its order *** this is one thing that you can improve
//	tr1::unordered_map<int, int> selectedQueryMap;
	//instead of the above, use an array
	int* selectedQueryMap = new int[this->getNumOfNodes()];
	for(int i=0;i<this->getNumOfNodes();i++)
		selectedQueryMap[i]=-1;

	//add it to the selected list
	Set_Nodes_Prioritized_Iterator* isi = new Set_Nodes_Prioritized_Iterator();

	//if the restricted node ID exists, then limit its domain to the restricted node
	if(restrictedNodeID==-1)//if(restrictedDomainID==-1)
	{
		/*isi->se = graph->getNodesByLabel(this->getNodeWithID(nodesOrder[0])->getLabel());
		if(isi->se==NULL)
		{
			delete isi;
			delete[] selectedQueryMap;
			return;
		}*/
		cout<<"Restricted node ID is not used! please use it.";

		if(takenIterations!=NULL) takenIterations = 0;

		return false;
	}
	else
	{
		isi->se = new vector<Node_Score*>();
		Node_Score* ns = new Node_Score();
		ns->node = graph->getNodeWithID(restrictedNodeID);
		ns->score = 0;
		isi->insertOrdered(ns);
	}
	isi->it = isi->se->begin();
	selected.push_back(isi);
	FastExistenceList* selectedDataMap = new FastExistenceList(this->getNumOfNodes());//only for fast check for existence
	selectedDataMap->add((*(isi->it))->node);
	selectedQueryMap[nodesOrder[selected.size()-1]] = (selected.size()-1);

	//list of nodes
//	NodeX** nodesList = new NodeX*[this->getNumOfNodes()];
//	for(int i=0;i<this->getNumOfNodes();i++)
//		nodesList[i] = this->getNodeWithID(i);

	//prepare nodesList for this graph
	NodeX** nodesList = new NodeX*[this->getNumOfNodes()];
	for(int i=0;i<this->getNumOfNodes();i++) {
		nodesList[i] = this->getNodeWithID(i);
	}

	long numIterations = 0;
	while(true)
	{
		//if(numIterations%100==0)
		{
			struct timeval tp;
			gettimeofday(&tp, NULL);
			long int current = tp.tv_sec * 1000000 + tp.tv_usec;

			elapsed+=(current-start);
			start = current;

			if(maxTime!=-1 && elapsed>=maxTime) {
				for(vector<Set_Nodes_Prioritized_Iterator* >::iterator iter = selected.begin();iter!=selected.end();iter++)
				{
					delete (*iter);
				}
				selected.clear();
				delete[] selectedQueryMap;
				delete[] nodesList;
				delete selectedDataMap;

				if(takenIterations!=NULL) *takenIterations = numIterations;

				return false;
			}
		}

#if allowThreaded
		if(Statistics::interrupt) {

			for(vector<Set_Nodes_Prioritized_Iterator* >::iterator iter = selected.begin();iter!=selected.end();iter++)
			{
				delete (*iter);
			}
			selected.clear();
			delete[] selectedQueryMap;
			delete[] nodesList;
			delete selectedDataMap;

//			double elapsed = TimeUtility::GetCounterMicro();
//			Statistics::threadedTime+=elapsed;
//			cout<<"Overhead O1 time = "<<elapsed<<endl;
//			TimeUtility::StartCounterMicro();

			if(takenIterations!=NULL) *takenIterations = numIterations;

			return false;
		}
#endif

//		GraphX::numIterations++;
		numIterations++;
//		if(numIterations%1000==0)
//			cout<<numIterations<<"/"<<limitedIterations<<endl;
		if(limitedIterations!=-1 && numIterations%(limitedIterations/10)==0)
		{
			if(numIterations%1000000==0) cout<<"numIterations = "<<numIterations<<", selected.size = "<<selected.size()<<endl;
			if(stuckQueryNodes!=NULL) {
				stuckQueryNodes->push_back(plan[selected.size()]);
//				cout<<"Adding Query node ID "<<plan[selected.size()]<<" to the stuck query nodes."<<endl;
			}
		}
		if(limitedIterations>-1 && numIterations>limitedIterations) {

			for(vector<Set_Nodes_Prioritized_Iterator* >::iterator iter = selected.begin();iter!=selected.end();iter++)
			{
				delete (*iter);
			}
			selected.clear();
			delete[] selectedQueryMap;
			delete[] nodesList;
			delete selectedDataMap;

			if(takenIterations!=NULL) *takenIterations = numIterations;

			return false;
		}

		//take care of the counting part
		Set_Nodes_Prioritized_Iterator* currentISI = selected.back();//.at(selected.size()-1);

		//cout<<"current set length = "<<currentISI->se->size()<<endl<<flush;
		while(currentISI->isIterEnd())
		{
			//if we finished the domain of the first node
			if(selected.size()==1)
			{
				delete (*(selected.begin()));
				selected.clear();
//				cout<<"numIterations = "<<numIterations<<endl;
				delete[] selectedQueryMap;
				delete[] nodesList;
				delete selectedDataMap;

				if(takenIterations!=NULL) *takenIterations = numIterations;

				return true;
			}

			//clear the data node associated with the last selected
			//selectedDataMap.erase(*(selected.back()->it));//commented on 27/10/2015
			//remove the last selected
			Set_Nodes_Prioritized_Iterator* tempToDel = selected.back();
			selected.pop_back();
//			delete tempToDel->se;
			delete tempToDel;
			//delete the query node associated with the last selected
			selectedQueryMap[nodesOrder[selected.size()]] = -1;

			currentISI = selected.back();

			selectedDataMap->remove((*(currentISI->it))->node);
			currentISI->it++;
			if(!currentISI->isIterEnd())//only the if line is added on 27/10/2015
				selectedDataMap->add((*(currentISI->it))->node);
		}

		//check current status
		bool b = true;
		if(selected.size()>2)
			b = checkCurrentStatus_Fast(this, graph, selected, nodesOrder, selectedQueryMap);
//		selectedDataMap->print();cout<<endl;
		//if valid
		if(b)
		{
			//cout<<"Check result is true"<<endl;
			//I found a solution
			if(selected.size()==this->getNumOfNodes())
			{
//				cout<<"Result found ..."<<endl;
				//adding result
				results.push_back((*(*(selected.begin()))->it)->node->getID());

				//resetting to one selected query node
				//1- clear selected data graph nodes
				selectedDataMap->clear();
				//2- clear data graph iterators
				for(vector<Set_Nodes_Prioritized_Iterator* >::iterator iter = selected.begin()+1;iter!=selected.end();iter++)
					delete *iter;
				selected.erase(selected.begin()+1, selected.end());
				//3- advance the data graph nodes iterators
				selected.back()->it++;
				if(!selected.back()->isIterEnd())//only the if line is added on 27/10/2015
					selectedDataMap->add((*(selected.back()->it))->node);
				//4- clear selected query nodes
				for(int j=1;j<this->getNumOfNodes();j++) {
					selectedQueryMap[nodesOrder[j]] = -1;
				}
			}
			else//no solution found yet!
			{
				Set_Nodes_Prioritized_Iterator* si = NULL;
				//get extension from current selected (last si)
				//get the index of a query node connected to the query node to be selected for the check
				NodeX* temp = NULL;

				NodeX* tempN1 = nodesList[nodesOrder[selected.size()]];//this->getNodeWithID(nodesOrder[selected.size()]);
				//NodeX* tempN1 = nodesList[nodesOrder[selected.size()]];
				vector<Set_Nodes_Prioritized_Iterator* >::iterator tempIT = selected.begin();
				for(int i=0;i<selected.size();i++, tempIT++)
				{
					if(tempN1->isItConnectedWithNodeID(nodesOrder[i]))
					{
						temp = (*(*tempIT)->it)->node;
						break;
					}
				}
				if(temp==NULL)
				{
					for(int i=0;i<getNumOfNodes();i++)
						cout<<nodesOrder[i]<<",";
					cout<<"Error90894"<<flush;
					exit(0);
				}

				bool needToCalcDifference = true;
				int counter = 0;
				for(map<int, void*>::iterator iter = temp->getEdgesIterator();iter!=temp->getEdgesEndIterator();++iter)
				{
					counter++;
					if(maxTime!=-1 && counter%10==0)
					{
						struct timeval tp;
						gettimeofday(&tp, NULL);
						long int current = tp.tv_sec * 1000000 + tp.tv_usec;

						elapsed+=(current-start);
						start = current;

						if(maxTime!=-1 && elapsed>=maxTime) {
							for(vector<Set_Nodes_Prioritized_Iterator* >::iterator iter = selected.begin();iter!=selected.end();iter++)
							{
								delete (*iter);
							}
							selected.clear();
							delete[] selectedQueryMap;
							delete[] nodesList;
							delete selectedDataMap;
							if(si!=NULL) delete si;

							if(takenIterations!=NULL) *takenIterations = numIterations;

							return false;
						}
					}
#if allowThreaded
					if(Statistics::interrupt) {

						for(vector<Set_Nodes_Prioritized_Iterator* >::iterator iter = selected.begin();iter!=selected.end();iter++)
						{
							delete (*iter);
						}
						selected.clear();
						delete[] selectedQueryMap;
						delete[] nodesList;
						delete selectedDataMap;
						if(si!=NULL) delete si;

//						double elapsed = TimeUtility::GetCounterMicro();
//						Statistics::threadedTime+=elapsed;
//						cout<<"Overhead O2 time = "<<elapsed<<endl;
//						TimeUtility::StartCounterMicro();

						if(takenIterations!=NULL) *takenIterations = numIterations;

						return false;
					}
#endif

					NodeX* otherNode = ((EdgeX*)iter->second)->getOtherNode();

//					NodeX* otherNode = graph->getNodeWithID(otherNodeID);
					//check for the AC_3ed domain, to check for node occurrence, if not then no need to check it

					//check for node label
					if(otherNode->getLabel()!=tempN1->getLabel() || selectedDataMap->exists(otherNode))
						continue;

					//apply pruning based on the neighborhood
					double score;
					if(temp->getEdgesSize()>2) {
						/*if(si!=NULL && si->se->size()>5) {
							score = 0;
						} else {
//							TimeUtility::StartCounterMicro();
							score = ((Features*)tempN1->getFeatures())->isSatisfiedBy((Features*)otherNode->getFeatures());//otherNode->getEdgesSize();
							GraphX::numIsSatisfied++;
//							GraphX::time4IstSatisfied+=TimeUtility::GetCounterMicro();
						}*/

						if(needToCalcDifference) {
//							TimeUtility::StartCounterMicro();
							score = ((Features*)tempN1->getFeatures())->avgDifference((Features*)otherNode->getFeatures());
							GraphX::numIsSatisfied++;
//							GraphX::time4IstSatisfied+=TimeUtility::GetCounterMicro();

//							if(score>10) needToCalcDifference = false;//HERE!
						}
						else
							//score = 0;
							score = ((Features*)tempN1->getFeatures())->isSatisfiedBy((Features*)otherNode->getFeatures());

						if(score==-1)
							continue;
						else
							score = score * 1;//added on 19 Jan 2017 to reflect the fact that, nodes with smaller values can be processed quickly
					}
					else {//HERE!
//						score = 0;
						score = ((Features*)tempN1->getFeatures())->isSatisfiedBy((Features*)otherNode->getFeatures());
						if(score==-1)
							continue;
					}

					bool b = true;
					//check for other edges
					for(map<int, void*>::iterator iter1 = tempN1->getEdgesIterator();iter1!=tempN1->getEdgesEndIterator();++iter1)
					{
						EdgeX* edge = (EdgeX*)iter1->second;
						int tempOrder = selectedQueryMap[edge->getOtherNode()->getID()];
						if(tempOrder == -1)
							continue;
						double edgeLabel = edge->getLabel();
						if(!otherNode->isItConnectedWithNodeID((*(selected[tempOrder]->it))->node->getID(), edgeLabel))
						{
							b = false;
							break;
						}
					}

					if(b)
					{
						if(si==NULL) {
							si = new Set_Nodes_Prioritized_Iterator();
							si->se = new vector<Node_Score*>();
						}
						Node_Score* sc = new Node_Score();
						sc->node = otherNode;
						sc->score = score;

						if(si->getSize()>10 && false) {//HERE
							si->insertAtBack(sc);//insert at back if it is not greater than the first value
						}
						else
							si->insertOrdered(sc);
//						cout<<"N#"<<otherNode->getID()<<endl;
					}
				}

				//I discovered a bug when testing the efficient graph, this fix should work now, otherwise the old code is below
				if(si!=NULL)//si->se->size()>0)
				{
					si->it = si->se->begin();
					selected.push_back(si);
					selectedDataMap->add((*(si->it))->node);
					selectedQueryMap[nodesOrder[selected.size()-1]] = (selected.size()-1);
				}
				else
				{
					/*si->it = si->se->end();
					//valgrind effect
					delete si->se;
					delete si;*/
					//
					selectedDataMap->remove((*(selected.back()->it))->node);
					selected.back()->it++;
					if(!selected.back()->isIterEnd())//only the if line is added on 27/10/2015
						selectedDataMap->add((*(selected.back()->it))->node);//added on 25_10_2015
				}
			}
		}
		else
		{
			//cout<<"Check result is false"<<endl;
			selectedDataMap->remove((*(selected.back()->it))->node);
			selected.back()->it++;
			if(!selected.back()->isIterEnd())//only the if line is added on 27/10/2015
				selectedDataMap->add((*(selected.back()->it))->node);
		}
	}

	//delete elements in selected
	for(vector<Set_Nodes_Prioritized_Iterator* >::iterator iter = selected.begin();iter!=selected.end();iter++)
	{
		delete (*iter);
	}
	selected.clear();
	delete[] selectedQueryMap;
	delete[] nodesList;
	delete selectedDataMap;

	if(takenIterations!=NULL) *takenIterations = numIterations;

	return true;
}

/**
 * check whether the restricted node ID (or the list of nodes for the restricted domain) is part of this graph inside the data graph
 * if yes, then 'results' will have the list of valid graph nodes
 * 'this' is the query graph, while graph i the data graph, this means I can query this (smaller) in the data (Bigger)
 *  [*] this function does not consider edge label! FIX IT!!!!
 *  This is a super OPTIMISTIC approach where the goal is to find a solution ASAP!
 *  This is done by trying to follow a guided path, and once the path is reached, it validates it ...
 *  PLEASE NOTE: this function by itself do not guarantee correct result
 */
void GraphX::isIsomorphic_OneMatch_Fast_Super_Optimistic(GraphX* graph,
		vector<int>& results,
		int* plan,
		int restrictedDomainID,
		int restrictedNodeID,
		int maxToVisit,
		tr1::unordered_map<int, tr1::unordered_map<string, void* >* >* embeddingsFeatures,
		bool useLessMatchingNodes)
{
	//populate the order in which query graph will be traversed
	int nodesOrder[getNumOfNodes()];//the result of this part

	//get the nodes order
	if(plan==0)
	{
		tr1::unordered_set<int> checked;
		tr1::unordered_set<int> available;
		//check for the restricted node, if it exists let it be the first to check
		if(restrictedDomainID==-1)
			available.insert(nodes.begin()->second->getID());
		else
			available.insert(restrictedDomainID);

		int count = 0;
		while(available.size()>0)
		{
			//select the best node from available
			tr1::unordered_set<int>::iterator iter1 = available.begin();
			set<int>* nodesWithLabel = graph->getNodeIDsByLabel(nodes[(*iter1)]->getLabel());
			double bestScore = 0;
			if(nodesWithLabel!=NULL)
				//bestScore = /*nodesWithLabel->size()**/((double)nodes[(*iter1)]->getEdgesSize());///((double)nodes[(*iter1)]->getEdgesSize());
				bestScore = nodesWithLabel->size()/((double)nodes[(*iter1)]->getEdgesSize());//original scoring
			int bestNode = *iter1;
			iter1++;

			for(;iter1!=available.end();++iter1)
			{
				double currScore = 0;
				nodesWithLabel = graph->getNodeIDsByLabel(nodes[(*iter1)]->getLabel());
				if(nodesWithLabel!=NULL)
					//currScore = /*nodesWithLabel->size()**/((double)nodes[(*iter1)]->getEdgesSize());///((double)nodes[(*iter1)]->getEdgesSize());
					currScore = nodesWithLabel->size()/((double)nodes[(*iter1)]->getEdgesSize());//original scoring
				int currID = *iter1;

				if(currScore<bestScore) {
					bestScore = currScore;
					bestNode = currID;
				}
			}

			int current = bestNode;

			available.erase(bestNode);
			if(checked.find(current)!=checked.end())
				continue;
			nodesOrder[count] = current;
			checked.insert(current);
			count++;
			NodeX* currNode = nodes[current];

			for(map<int, void*>::iterator iter = currNode->getEdgesIterator();iter!=currNode->getEdgesEndIterator();++iter)
			{
				int otherID = iter->first;
				if(checked.find(otherID)==checked.end())
				{
					available.insert(otherID);
				}
			}
		}
	}
	else
	{
		for(int i=0;i<nodes.size();i++)
		{
			nodesOrder[i] = plan[i];
		}
	}

	//print nodes order
//	cout<<"Query nodes order: ";
//	for(int i=0;i<getNumOfNodes();i++)
//		cout<<nodesOrder[i]<<",";
//	cout<<endl;

	vector<Set_Nodes_Prioritized_Iterator* > selected;

	//map value is query node id, value is its order *** this is one thing that you can improve
//	tr1::unordered_map<int, int> selectedQueryMap;
	//instead of the above, use an array
	int* selectedQueryMap = new int[this->getNumOfNodes()];
	for(int i=0;i<this->getNumOfNodes();i++)
		selectedQueryMap[i]=-1;

	//add it to the selected list
	Set_Nodes_Prioritized_Iterator* isi = new Set_Nodes_Prioritized_Iterator();

	//if the restricted node ID exists, then limit its domain to the restricted node
	if(restrictedNodeID==-1)//if(restrictedDomainID==-1)
	{
		/*isi->se = graph->getNodesByLabel(this->getNodeWithID(nodesOrder[0])->getLabel());
		if(isi->se==NULL)
		{
			delete isi;
			delete[] selectedQueryMap;
			return;
		}*/
		cout<<"Restricted node ID is not used! please use it.";
		return;
	}
	else
	{
		isi->se = new vector<Node_Score*>();
		Node_Score* ns = new Node_Score();
		ns->node = graph->getNodeWithID(restrictedNodeID);
		ns->score = 0;
		isi->insertOrdered(ns);
	}
	isi->it = isi->se->begin();
	selected.push_back(isi);
	FastExistenceList* selectedDataMap = new FastExistenceList(this->getNumOfNodes());//only for fast check for existence
	selectedDataMap->add((*(isi->it))->node);
	selectedQueryMap[nodesOrder[selected.size()-1]] = (selected.size()-1);

	//list of nodes
//	NodeX** nodesList = new NodeX*[this->getNumOfNodes()];
//	for(int i=0;i<this->getNumOfNodes();i++)
//		nodesList[i] = this->getNodeWithID(i);

	//prepare nodesList for this graph
	NodeX** nodesList = new NodeX*[this->getNumOfNodes()];
	for(int i=0;i<this->getNumOfNodes();i++) {
		nodesList[i] = this->getNodeWithID(i);
	}

	long numIterations = 0;
	while(true)
	{
#if allowThreaded
		if(Statistics::interrupt) {


			for(vector<Set_Nodes_Prioritized_Iterator* >::iterator iter = selected.begin();iter!=selected.end();iter++)
			{
				delete (*iter);
			}
			selected.clear();
			delete[] selectedQueryMap;
			delete[] nodesList;
			delete selectedDataMap;

//			double elapsed = TimeUtility::GetCounterMicro();
//			Statistics::threadedTime+=elapsed;
//			cout<<"Overhead SO1 time = "<<elapsed<<endl;
//			TimeUtility::StartCounterMicro();

			return;
		}
#endif

//		GraphX::numIterations++;
		numIterations++;

		if(numIterations>(this->getNumOfNodes()*1000)) {
			//remember to clear data here
			return;
		}

		//take care of the counting part
		Set_Nodes_Prioritized_Iterator* currentISI = selected.back();//.at(selected.size()-1);

		//cout<<"current set length = "<<currentISI->se->size()<<endl<<flush;
		while(currentISI->isIterEnd())
		{
			//if we finished the domain of the first node
			if(selected.size()==1)
			{
				delete (*(selected.begin()));
				selected.clear();
//				cout<<"numIterations = "<<numIterations<<endl;
				delete[] selectedQueryMap;
				delete[] nodesList;
				delete selectedDataMap;
				return;
			}

			//clear the data node associated with the last selected
			//selectedDataMap.erase(*(selected.back()->it));//commented on 27/10/2015
			//remove the last selected
			Set_Nodes_Prioritized_Iterator* tempToDel = selected.back();
			selected.pop_back();
//			delete tempToDel->se;
			delete tempToDel;
			//delete the query node associated with the last selected
			selectedQueryMap[nodesOrder[selected.size()]] = -1;

			currentISI = selected.back();

			selectedDataMap->remove((*(currentISI->it))->node);
			currentISI->it++;
			if(!currentISI->isIterEnd())//only the if line is added on 27/10/2015
				selectedDataMap->add((*(currentISI->it))->node);
		}

		bool b = true;
		if(selected.size()>2)
			b = checkCurrentStatus_Fast(this, graph, selected, nodesOrder, selectedQueryMap);
		//if valid
		if(b)
		{
			if(selected.size()==this->getNumOfNodes())
			{
				//check the valididty of the assigned values
				//this should be the only part to check validity
				/*bool valid = true;
				for(int i=0;i<selected.size();i++) {
					if(!checkCurrentStatus_Fast(this, graph, selected, nodesOrder, selectedQueryMap, i)) {
						valid = false;
						break;
					}
				}*/
				bool valid = checkCurrentStatus_Fast(this, graph, selected, nodesOrder, selectedQueryMap);
				if(valid) {
		//			cout<<"Result found ..."<<endl;
					//adding result
					results.push_back((*(*(selected.begin()))->it)->node->getID());
				}

				//resetting to one selected query node
				//1- clear selected data graph nodes
				selectedDataMap->clear();
				//2- clear data graph iterators
				for(vector<Set_Nodes_Prioritized_Iterator* >::iterator iter = selected.begin()+1;iter!=selected.end();iter++)
					delete *iter;
				selected.erase(selected.begin()+1, selected.end());
				//3- advance the data graph nodes iterators
				selected.back()->it++;
				if(!selected.back()->isIterEnd())//only the if line is added on 27/10/2015
					selectedDataMap->add((*(selected.back()->it))->node);
				//4- clear selected query nodes
				for(int j=1;j<this->getNumOfNodes();j++) {
					selectedQueryMap[nodesOrder[j]] = -1;
				}

			}
			else//no solution found yet!
			{
				Set_Nodes_Prioritized_Iterator* si = NULL;
				//get extension from current selected (last si)
				//get the index of a query node connected to the query node to be selected for the check
				NodeX* temp = NULL;

				NodeX* tempN1 = nodesList[nodesOrder[selected.size()]];//this->getNodeWithID(nodesOrder[selected.size()]);
				//NodeX* tempN1 = nodesList[nodesOrder[selected.size()]];
				vector<Set_Nodes_Prioritized_Iterator* >::iterator tempIT = selected.begin();
				for(int i=0;i<selected.size();i++, tempIT++)
				{
					if(tempN1->isItConnectedWithNodeID(nodesOrder[i]))
					{
						temp = (*(*tempIT)->it)->node;
						break;
					}
				}
				if(temp==NULL)
				{
					for(int i=0;i<getNumOfNodes();i++)
						cout<<nodesOrder[i]<<",";
					cout<<"Error90895"<<flush;
					exit(0);
				}

				bool needToCalcDifference = true;
				int count = 0;
				int traversedNodes = 0;
				for(map<int, void*>::iterator iter = temp->getEdgesIterator();iter!=temp->getEdgesEndIterator();++iter)
				{
#if allowThreaded
					if(Statistics::interrupt) {


						for(vector<Set_Nodes_Prioritized_Iterator* >::iterator iter = selected.begin();iter!=selected.end();iter++)
						{
							delete (*iter);
						}
						selected.clear();
						delete[] selectedQueryMap;
						delete[] nodesList;
						delete selectedDataMap;
						if(si!=NULL) delete si;

//						double elapsed = TimeUtility::GetCounterMicro();
//						Statistics::threadedTime+=elapsed;
//						cout<<"Overhead SO2 time = "<<elapsed<<endl;
//						TimeUtility::StartCounterMicro();

						return;
					}
#endif

					NodeX* otherNode = ((EdgeX*)iter->second)->getOtherNode();

					//check for node label
					if(otherNode->getLabel()!=tempN1->getLabel() || selectedDataMap->exists(otherNode))
						continue;

					traversedNodes++;
					if(traversedNodes>maxToVisit) break;

					//apply pruning based on the neighborhood
					double score;
					if(temp->getEdgesSize()>2)
					{
	//						TimeUtility::StartCounterMicro();
	//					score = ((Features*)tempN1->getFeatures())->avgDifference((Features*)otherNode->getFeatures());
						if(embeddingsFeatures==NULL)
							score = ((Features*)tempN1->getFeatures())->minSatisfyingDifference((Features*)otherNode->getFeatures());
						else {
							score = ((Features*)tempN1->getFeatures())->isSatisfiedBy((Features*)otherNode->getFeatures());
							if(score!=-1)
								score = ((Features*)otherNode->getFeatures())->getHeighestSimilarity(embeddingsFeatures->find(tempN1->getID())->second);
//							cout<<"score = "<<score<<endl;
						}
						GraphX::numIsSatisfied++;
	//						GraphX::time4IstSatisfied+=TimeUtility::GetCounterMicro();


						if(score==-1)
							continue;
					}
					else
						score = 0;

					if(si==NULL) {
						si = new Set_Nodes_Prioritized_Iterator();
						si->se = new vector<Node_Score*>();
					}
					Node_Score* sc = new Node_Score();
					sc->node = otherNode;
					if(useLessMatchingNodes)
						score = score *-1;
					sc->score = score;

					if(embeddingsFeatures==NULL)
					{
						si->insertOrdered(sc);
//						si->cutIfLarger(selected.size()+2);//(5);
						si->cutIfLarger((this->getNumOfNodes()-selected.size())+2);

//					si->replaceIfBetter(sc);
					}
					else
					{
						if(score>=1 || si->getSize()<(this->getNumOfNodes()-selected.size())+2)
							si->insertOrdered(sc);
					}

					count++;
					if(count>maxToVisit) break;
//					if(count>selected.size()*2) break;

//					if(score>2 || si->getSize()>9) break;//this is one key idea, no need to go through other nodes since the selected one is good enough
				}

				//I discovered a bug when testing the efficient graph, this fix should work now, otherwise the old code is below
				if(si!=NULL)//si->se->size()>0)
				{
					si->it = si->se->begin();
					selected.push_back(si);
					selectedDataMap->add((*(si->it))->node);
					selectedQueryMap[nodesOrder[selected.size()-1]] = (selected.size()-1);
				}
				else
				{
					selectedDataMap->remove((*(selected.back()->it))->node);
					selected.back()->it++;
					if(!selected.back()->isIterEnd())//only the if line is added on 27/10/2015
						selectedDataMap->add((*(selected.back()->it))->node);//added on 25_10_2015
				}
			}
		}
		else
		{
			//cout<<"Check result is false"<<endl;
			selectedDataMap->remove((*(selected.back()->it))->node);
			selected.back()->it++;
			if(!selected.back()->isIterEnd())//only the if line is added on 27/10/2015
				selectedDataMap->add((*(selected.back()->it))->node);
		}
	}

	//delete elements in selected
	for(vector<Set_Nodes_Prioritized_Iterator* >::iterator iter = selected.begin();iter!=selected.end();iter++)
	{
		(*iter)->se->clear();
		delete (*iter);
	}
	selected.clear();
	delete[] selectedQueryMap;
	delete[] nodesList;
	delete selectedDataMap;
}

/**
 * get the canonical label of this graph
 */
//string GraphX::getCanonicalLabel()
//{
//	if(CL.length()>0)
//		return CL;
//	CL = CanonicalLabel::generate(this);
//	return CL;
//}

//output graph
//ostream& operator<<(ostream& os, const GraphX& g)
//{
//	for( map<int,NodeX*>::const_iterator ii=g.nodes.begin(); ii!=g.nodes.end(); ++ii)
//	{
//		os<<*((*ii).second)<<endl;
//	}
//    return os;
//}

ostream& operator<<(ostream& os, const GraphX& g)
{
	os<<"t # 1\n";
	//output the nodes
	for( map<int,NodeX*>::const_iterator ii=g.nodes.begin(); ii!=g.nodes.end(); ++ii)
	{
		NodeX* node = ii->second;
		os<<"v "<<node->getID()<<" "<<node->getLabel()<<"\n";
	}

	//output the edges
	tr1::unordered_set<string> savedEdges;//list to keep track of already saved edges
	for( map<int,NodeX*>::const_iterator ii=g.nodes.begin(); ii!=g.nodes.end(); ++ii)
	{
		NodeX* node = ii->second;
		for(map<int, void*>::iterator iter1 = node->getEdgesIterator();iter1!=node->getEdgesEndIterator();iter1++)
		{
			EdgeX* edge = (EdgeX*)iter1->second;

			//check whether it has been added before or not
			string sig = intToString(node->getID())+"_"+doubleToString(edge->getLabel())+"_"+intToString(edge->getOtherNode()->getID());
			if(node->getID()<edge->getOtherNode()->getID())
				sig = intToString(edge->getOtherNode()->getID())+"_"+doubleToString(edge->getLabel())+"_"+intToString(node->getID());
			if(savedEdges.find(sig)==savedEdges.end())
			{
				savedEdges.insert(sig);
				os<<"e "<<node->getID()<<" "<<edge->getOtherNode()->getID()<<" "<<edge->getLabel()<<"\n";
			}
		}
	}

    return os;
}

bool GraphX::canSatisfy(GraphX* subgraph) {
	//get all labels in subgraph
	tr1::unordered_set<double> labels;
	for(map<int,NodeX*>::const_iterator iter = subgraph->getNodesIterator();iter!=subgraph->getNodesEndIterator();iter++) {
		NodeX* node = iter->second;
		double label = node->getLabel();
		if(labels.find(label)!=labels.end())
			continue;

		labels.insert(label);
		if(this->getNodeIDsByLabel(label)<subgraph->getNodeIDsByLabel(label))
			return false;
	}

	return true;
}

void GraphX::loadNodesStats(string fileName) {
	ifstream file (fileName.c_str(), ios::in);
	if(!file) {
		cout << "While opening stats file an error is encountered" << endl;
		return;
	}

	//first line is dummy
	string line;
	std::getline(file, line);

	while (!file.eof()) {
		char c;//for digesting commas
		double nodeID;file>>nodeID;file>>c;
		int label;file>>label;file>>c;
		int degree;file>>degree;file>>c;
		double weightedDegree;file>>weightedDegree;file>>c;
		double eccentricity;file>>eccentricity;file>>c;
		double closenessCentrality;file>>closenessCentrality;file>>c;
		double betweennessCentrality;file>>betweennessCentrality;file>>c;
		double authority;file>>authority;file>>c;
		double hub;file>>hub;file>>c;
		int modularityClass;file>>modularityClass;file>>c;
		double pageRank;file>>pageRank;file>>c;
		int componentID;file>>componentID;file>>c;
		double clusteringCoefficient;file>>clusteringCoefficient;file>>c;
		int numTriangles;file>>numTriangles;file>>c;
		double eigenvectorCentrality;file>>eigenvectorCentrality;

		NodeStats* nodeStats = new NodeStats();
		nodeStats->degree = degree;
		nodeStats->weightedDegree = weightedDegree;
		nodeStats->eccentricity = eccentricity;
		nodeStats->closenessCentrality = closenessCentrality;
		nodeStats->betweennessCentrality = betweennessCentrality;
		nodeStats->authority = authority;
		nodeStats->hub = hub;
		nodeStats->modularityClass = modularityClass;
		nodeStats->pageRank = pageRank;
		nodeStats->componentID = componentID;
		nodeStats->clusteringCoefficient = clusteringCoefficient;
		nodeStats->numTriangles = numTriangles;
		nodeStats->eigenvectorCentrality = eigenvectorCentrality;

		NodeX* node = this->getNodeWithID(nodeID);
		if(node==NULL || ((int)node->getLabel())!=label) {
			cout<<"Error in loading stats. Node ID = "<<nodeID<<". Labels: "<<node->getLabel()<<"/"<<label;
			return;
		}
		node->setStats(nodeStats);

		if(file.eof()) break;
	}

	for(map<int, NodeX*>::iterator iter = nodes.begin();iter!=nodes.end();iter++) {
		NodeX* node = iter->second;
		double label = node->getLabel();
		//if it does not exist compute it
		if(avgDegreeMap.find(label)==avgDegreeMap.end())
		{
			getAvgNodeStats(label);
		}
	}
}

NodeStats* GraphX::getAvgNodeStats(double label) {
	if(avgDegreeMap.find(label)==avgDegreeMap.end())
	{
		double avgDegree = 0;
		double avgWeightedDegree = 0;
		double avgEccentricity = 0;
		double avgClosenessCentrality = 0;
		double avgBetweennessCentrality = 0;
		double avgAuthority = 0;
		double avgHub = 0;
		double avgPageRank = 0;
		double avgClusteringCoefficient = 0;
		double avgNumTriangles = 0;
		double avgEigenvectorCentrality = 0;

		set<int>* nodes = getNodeIDsByLabel(label);
		if(nodes!=NULL) {
			set<int>::iterator iter = nodes->begin();
			for(;iter!=nodes->end();iter++) {
				int tempNodeID = (*iter);
				NodeX* tempNode = getNodeWithID(tempNodeID);
				NodeStats* nodeStats = tempNode->getNodeStats();

				avgDegree += nodeStats->degree;
				avgWeightedDegree += nodeStats->weightedDegree;
				avgEccentricity += nodeStats->eccentricity;
				avgClosenessCentrality += nodeStats->closenessCentrality;
				avgBetweennessCentrality += nodeStats->betweennessCentrality;
				avgAuthority += nodeStats->authority;
				avgHub += nodeStats->hub;
				avgPageRank += nodeStats->pageRank;
				avgClusteringCoefficient += nodeStats->clusteringCoefficient;
				avgNumTriangles += nodeStats->numTriangles;
				avgEigenvectorCentrality += nodeStats->eigenvectorCentrality;
			}

			avgDegree = avgDegree/nodes->size();
			avgWeightedDegree = avgWeightedDegree/nodes->size();
			avgEccentricity = avgEccentricity/nodes->size();
			avgClosenessCentrality = avgClosenessCentrality/nodes->size();
			avgBetweennessCentrality = avgBetweennessCentrality/nodes->size();
			avgAuthority = avgAuthority/nodes->size();
			avgHub = avgHub/nodes->size();
			avgPageRank = avgPageRank/nodes->size();
			avgClusteringCoefficient = avgClusteringCoefficient/nodes->size();
			avgNumTriangles = avgNumTriangles/nodes->size();
			avgEigenvectorCentrality = avgEigenvectorCentrality/nodes->size();
		}
		avgDegreeMap.insert(std::pair<double, double>(label, avgDegree));
		avgWeightedDegreeMap.insert(std::pair<double, double>(label, avgWeightedDegree));
		avgEccentricityMap.insert(std::pair<double, double>(label, avgEccentricity));
		avgClosenessCentralityMap.insert(std::pair<double, double>(label, avgClosenessCentrality));
		avgBetweennessCentralityMap.insert(std::pair<double, double>(label, avgBetweennessCentrality));
		avgAuthorityMap.insert(std::pair<double, double>(label, avgAuthority));
		avgHubMap.insert(std::pair<double, double>(label, avgHub));
		avgPageRankMap.insert(std::pair<double, double>(label, avgPageRank));
		avgClusteringCoefficientMap.insert(std::pair<double, double>(label, avgClusteringCoefficient));
		avgNumTrianglesMap.insert(std::pair<double, double>(label, avgNumTriangles));
		avgEigenvectorCentralityMap.insert(std::pair<double, double>(label, avgEigenvectorCentrality));
	}

	NodeStats* nodeStats = new NodeStats();

	nodeStats->authority = avgAuthorityMap.find(label)->second;
	nodeStats->betweennessCentrality = avgBetweennessCentralityMap.find(label)->second;
	nodeStats->closenessCentrality = avgClosenessCentralityMap.find(label)->second;
	nodeStats->clusteringCoefficient = avgClusteringCoefficientMap.find(label)->second;
	nodeStats->degree = avgDegreeMap.find(label)->second;
	nodeStats->eccentricity = avgEccentricityMap.find(label)->second;
	nodeStats->eigenvectorCentrality = avgEigenvectorCentralityMap.find(label)->second;
	nodeStats->hub = avgHubMap.find(label)->second;
	nodeStats->numTriangles = avgNumTrianglesMap.find(label)->second;
	nodeStats->pageRank = avgPageRankMap.find(label)->second;
	nodeStats->weightedDegree = avgWeightedDegreeMap.find(label)->second;

	return nodeStats;
}

/**
 * this is designed only fo undirected graphs
 */
void GraphX::populateEdgesCount() {
	for( map<int,NodeX*>::iterator ii=nodes.begin(); ii!=nodes.end(); ++ii)
	{
		NodeX* node = ii->second;
		double label = node->getLabel();

		//iterate over its edges
		for(map<int, void*>::iterator iter = node->getEdgesIterator();iter!=node->getEdgesEndIterator();++iter)
		{
			int otherNodeID = iter->first;
			double otherNodeLabel = this->getNodeWithID(otherNodeID)->getLabel();

			//only consider the case where label is less than the other nodes's label
			if(otherNodeLabel<label) continue;

			std::ostringstream key;
			key<<label<<"_"<<otherNodeLabel;

			int count = 0;
			tr1::unordered_map<string, int >::iterator searchIter = edgesCount.find(key.str());
			if(searchIter!=edgesCount.end()) {
				count = searchIter->second;
				edgesCount.erase(key.str());
			}
			edgesCount.insert(std::pair<string, int>(key.str(), count+1));
		}
	}

	//print counts
}

void GraphX::printEdgesCount() {
	for(tr1::unordered_map<string, int >::iterator iter = edgesCount.begin();iter!=edgesCount.end();iter++) {
		cout<<iter->first<<":"<<iter->second<<endl;
	}
}

void GraphX::printNodesFeatures() {

	for( map<int,NodeX*>::iterator ii=nodes.begin(); ii!=nodes.end(); ++ii) {
		NodeX* node = ii->second;
		Features* fs = (Features*)node->getFeatures();
		if(fs==NULL) continue;
		cout<<node->getID()<<",";
		fs->print(cout);
		cout<<endl;
	}
}

void GraphX::populateNodesFeatures() {

	for( map<int,NodeX*>::iterator ii=nodes.begin(); ii!=nodes.end(); ++ii) {
		NodeX* node = ii->second;
		Features* fs = Features::generateFSForNode(this, node->getID(), 3);
		node->setFeatures(fs);
	}
}

/**
 * generates features for the nodes based on the neighborhood. It is similar to the populateNodesFeatures, but it is faster and less accurate
 * Less acurate means: it will have weight labels larger than the really existing ones
 */
void GraphX::populateNodesFeatures_FAST(int numIterations) {

	double decay = 0.5;
//cout<<"1"<<flush;
	//Initialize
	Features** currentFeatures = new Features*[maxNodeID+1];
	Features** nextFeatures = new Features*[maxNodeID+1];
	long* currentNeighbors = new long[maxNodeID+1];
	long* nextNeighbors = new long[maxNodeID+1];
	for(int i=0;i<maxNodeID+1;i++) {
		currentFeatures[i] = new Features();
		nextFeatures[i] = new Features();
		map<int, NodeX*>::iterator iter = nodes.find(i);
		NodeX* node = NULL;
		if(iter==nodes.end()) {

		} else {
			node = iter->second;
			node->setFeatures(new Features());
			currentFeatures[i]->addFeature(node->getLabel(), 1);
			currentNeighbors[i] = 1;
			((Features*)node->getFeatures())->addFeaturesValue(currentFeatures[i]);
		}
	}
	//go over the iterations, propagate labels at each iteration
	for(int j=0;j<numIterations;j++) {
//		cout<<"00-"<<flush;
		int i = 0;
		//go over all nodes
//		cout<<"Loop1 starts ..."<<flush;
		for(map<int,NodeX*>::iterator ii=nodes.begin(); ii!=nodes.end(); ++ii) {
			NodeX* node = ii->second;
			Features* currentNodeFeature = currentFeatures[node->getID()];

			//go over all edges
			for(map<int, void*>::iterator iter = node->getEdgesIterator();iter!=node->getEdgesEndIterator();++iter)
			{
				int otherNodeID = iter->first;
				if(otherNodeID<node->getID()) continue;
				EdgeX* edge = (EdgeX*)(iter->second);

				NodeX* otherNode = edge->getOtherNode();
				nextFeatures[otherNode->getID()]->addFeaturesValue(currentNodeFeature, decay);
				nextFeatures[node->getID()]->addFeaturesValue(currentFeatures[otherNodeID], decay);

				nextNeighbors[node->getID()]+=currentNeighbors[otherNode->getID()];
				nextNeighbors[otherNode->getID()]+=currentNeighbors[node->getID()];
			}
		}
//		cout<<"11"<<flush;
//		cout<<"DONE. "<<flush;

		//populate nodes with next features and replace current with next
		if(j==numIterations-1) {
			for(map<int,NodeX*>::iterator ii=nodes.begin(); ii!=nodes.end(); ++ii) {
				NodeX* node = ii->second;
				//currentFeatures[node->getID()]->clear();
				currentFeatures[node->getID()]->addFeaturesValue(nextFeatures[node->getID()]);
				nextFeatures[node->getID()]->clear();
				//((Features*)node->getFeatures())->addFeaturesValue(currentFeatures[node->getID()]);

				//populate nodes with the resulted features at he final iteration
				((Features*)node->getFeatures())->setFeatures(currentFeatures[node->getID()]);
	//				((Features*)node->getFeatures())->clear();
	//				((Features*)node->getFeatures())->addFeaturesValue(currentFeatures[node->getID()]);

				currentNeighbors[node->getID()] = nextNeighbors[node->getID()];
				node->neighborsCount = currentNeighbors[node->getID()];
			}
		} else {
			for(int i = 0;i<maxNodeID+1;i++) {
				currentFeatures[i]->addFeaturesValue(nextFeatures[i]);
				nextFeatures[i]->clear();

				currentNeighbors[i] = nextNeighbors[i];
			}

		}

		if(nodes.size()>1000)
			cout<<"Iteration#"<<j<<flush;
	}
	if(nodes.size()>1000)
		cout<<endl;

	//generate features keys
	/*if(nodes.size()>1000)
		cout<<"Generating node neighbors keys."<<endl;
	int counter = 0;
	for(map<int,NodeX*>::iterator ii=nodes.begin(); ii!=nodes.end(); ++ii) {
		NodeX* node = ii->second;
		node->generateFeaturesKey();
		counter++;
		if(counter%1000000==0) cout<<counter<<endl;
	}*/

	//delete memory
	for(int i=0;i<maxNodeID+1;i++) {
		delete currentFeatures[i];
		delete nextFeatures[i];
	}
	delete[] currentFeatures;
	delete[] nextFeatures;
	delete[] nextNeighbors;
	delete[] currentNeighbors;
}

/**
 * generate the plan so that each subtree shape of the graph is put as a whole in the plan before any other subtree
 */
int* GraphX::generateTreeFirstPlan(int startingNodeID, GraphX* inputGraph) {
	int* plan = new int[this->getNumOfNodes()];
	plan[0] = startingNodeID;
	set<int> visited;
	visited.insert(startingNodeID);
	NodeX* startingNode = this->getNodeWithID(startingNodeID);
	int position = 1;

	vector<NodeX*> orderedSubTreeNodes;
	for(map<int, void*>::iterator iter = startingNode->getEdgesIterator();iter!=startingNode->getEdgesEndIterator();++iter) {
		NodeX* tempNode = ((EdgeX*)iter->second)->getOtherNode();

		//compute selectivity score
		tempNode->tempScore = 0;
		//based on how many node in the graph can satisfy this node
		set<int>* nodes = inputGraph->getNodeIDsByLabel(tempNode->getLabel());
		if(nodes==NULL) {

		}
		else
		{
			for(set<int>::iterator nodesIter = nodes->begin();nodesIter!=nodes->end();nodesIter++) {
				int aNodeID = (*nodesIter);
				NodeX* aNode = inputGraph->getNodeWithID(aNodeID);
	//				double sc = ((Features*)tempNode->getFeatures())->isSatisfiedBy((Features*)aNode->getFeatures());
				double sc = ((Features*)tempNode->getFeatures())->minSatisfyingDifference((Features*)aNode->getFeatures());
				if(sc!=-1)
					tempNode->tempScore+=sc;//it was ++
			}
		}

		vector<NodeX*>::iterator iter1 = orderedSubTreeNodes.begin();
		for(;iter1!=orderedSubTreeNodes.end();iter1++) {
			NodeX* n = *iter1;
			if(tempNode->tempScore<n->tempScore)
				break;
		}
		orderedSubTreeNodes.push_back(tempNode);
	}

	//go over subtree root nodes
	//for(map<int, void*>::iterator iter = startingNode->getEdgesIterator();iter!=startingNode->getEdgesEndIterator();++iter) {
	for(vector<NodeX*>::iterator iter = orderedSubTreeNodes.begin();iter!=orderedSubTreeNodes.end();iter++) {
//		NodeX* otherNode = ((EdgeX*)iter->second)->getOtherNode();
		NodeX* otherNode = *iter;

		//for each node, generate the nodes in its subtree
		set<int> available;
		available.insert(otherNode->getID());
		while(available.size()>0) {
			//int currentNodeID = *(available.begin());
			//select the best node
			double score = 10000000;
			int currentNodeID = -1;
			set<int>::iterator iter1 = available.begin();
			for(;iter1!=available.end();iter1++) {
				int tempID = (*iter1);
				NodeX* tempNode = this->getNodeWithID(tempID);
				double tempLabel = tempNode->getLabel();
				//int tempScore = inputGraph->getNodesByLabel(tempLabel)->size()/tempNode->getEdgesSize();

				//based on how many node in the graph can satisfy this node
				int tempScore = 0;
				set<int>* nodes = inputGraph->getNodeIDsByLabel(tempNode->getLabel());
				if(nodes==NULL) {
					tempScore = 0;
				}
				else
				{
					for(set<int>::iterator nodesIter = nodes->begin();nodesIter!=nodes->end();nodesIter++) {
						int aNodeID = (*nodesIter);
						NodeX* aNode = inputGraph->getNodeWithID(aNodeID);
						double sc = ((Features*)tempNode->getFeatures())->minSatisfyingDifference((Features*)aNode->getFeatures());
						if(sc!=-1)
							tempNode->tempScore+=sc;//it was ++
					}
				}

				if(tempScore<score) {
					score = tempScore;
					currentNodeID = tempID;
				}
			}

			available.erase(currentNodeID);
			if(visited.find(currentNodeID)!=visited.end())
				continue;
			else
				visited.insert(currentNodeID);

			plan[position] = currentNodeID;
			position++;

			NodeX* currentNode = this->getNodeWithID(currentNodeID);
			//check neighbors of the current node
			for(map<int, void*>::iterator iter = currentNode->getEdgesIterator();iter!=currentNode->getEdgesEndIterator();++iter) {
				NodeX* tempNode = ((EdgeX*)iter->second)->getOtherNode();
				if(visited.find(tempNode->getID())!=visited.end() ||
						available.find(tempNode->getID())!=available.end())
					continue;
				available.insert(tempNode->getID());
			}
		}

	}

	return plan;
}

/**
 * priority is given to nodes with high degree compared to plans with lower degrees
 */
int* GraphX::generateCoresFirstPlan(int startingNodeID) {
	int* plan = new int[this->getNumOfNodes()];
	plan[0] = startingNodeID;
	set<int> visited;
	//visited.insert(startingNodeID);
	vector<NodeX* > available;
	available.push_back(this->getNodeWithID(startingNodeID));
//	NodeX* startingNode = this->getNodeWithID(startingNodeID);
	int position = 0;

	while(available.size()>0) {
		NodeX* currentNode = *(available.begin());
		available.erase(available.begin());
		if(visited.find(currentNode->getID())!=visited.end())
			continue;
		else
			visited.insert(currentNode->getID());

		plan[position] = currentNode->getID();
		position++;

		//check neighbors of the current node
		for(map<int, void*>::iterator iter = currentNode->getEdgesIterator();iter!=currentNode->getEdgesEndIterator();++iter) {
			NodeX* tempNode = ((EdgeX*)iter->second)->getOtherNode();
			if(visited.find(tempNode->getID())!=visited.end())
				continue;

			bool b = true;
			vector<NodeX*>::iterator iter1 = available.begin();
			for(;iter1!=available.end();iter1++) {
				if(tempNode->getID()==(*iter1)->getID()) {
					b = false;
					break;
				}
				if(tempNode->getEdgesSize()>(*iter1)->getEdgesSize())
					break;
			}
			if(b)
				available.insert(iter1, tempNode);
		}
	}

	return plan;
}

/**
 * returning NULL means that there is no need to create a plan as there are no graph nodes with one of the nodes labels
 */
int* GraphX::generateSelectBasedPlan(int startingNodeID, GraphX* inputGraph) {
	int* plan = new int[this->getNumOfNodes()];
	plan[0] = startingNodeID;
	set<int> visited;
	//visited.insert(startingNodeID);
	vector<NodeX* > available;
	NodeX* startingNode = this->getNodeWithID(startingNodeID);

	for(map<int, NodeX*>::iterator iter = nodes.begin();iter!=nodes.end();iter++) {
		iter->second->tempScore = 0;
	}

	available.push_back(startingNode);
//	NodeX* startingNode = this->getNodeWithID(startingNodeID);
	int position = 0;
	while(available.size()>0) {

		/*cout<<"Scores:"<<endl;
		for(vector<NodeX*>::iterator iter1 = available.begin();iter1!=available.end();iter1++) {
			cout<<(*iter1)->getID()<<", "<<(*iter1)->tempScore<<endl;
		}
		cout<<"-----------"<<endl;*/

		NodeX* currentNode = *(available.begin());
		available.erase(available.begin());
		if(visited.find(currentNode->getID())!=visited.end())
			continue;
		else
			visited.insert(currentNode->getID());

		plan[position] = currentNode->getID();
		position++;
		//check neighbors of the current node
		for(map<int, void*>::iterator iter = currentNode->getEdgesIterator();iter!=currentNode->getEdgesEndIterator();++iter) {
			NodeX* tempNode = ((EdgeX*)iter->second)->getOtherNode();

			if(tempNode->tempScore!=0 || visited.find(tempNode->getID())!=visited.end())//this moved from below
				continue;

			//compute selectivity score
			//based on how many node in the graph can satisfy this node
			set<int>* nodes = inputGraph->getNodeIDsByLabel(tempNode->getLabel());
			if(nodes==NULL) {
				delete[] plan;
				return NULL;
			}

			int maxNumTraversedNodes = 1000;
			int count1 = 0;
			for(set<int>::iterator nodesIter = nodes->begin();nodesIter!=nodes->end();nodesIter++) {
				count1++;
				if(count1>maxNumTraversedNodes)//added on 24 Jan
					break;

				int aNodeID = (*nodesIter);
				NodeX* aNode = inputGraph->getNodeWithID(aNodeID);
//				double sc = ((Features*)tempNode->getFeatures())->isSatisfiedBy((Features*)aNode->getFeatures());
				double sc = ((Features*)tempNode->getFeatures())->minSatisfyingDifference((Features*)aNode->getFeatures());
				if(sc!=-1)
					tempNode->tempScore+=sc;//it was ++
			}

			tempNode->tempScore = tempNode->tempScore/tempNode->getEdgesSize();

			bool b = true;
			vector<NodeX*>::iterator iter1 = available.begin();
			for(;iter1!=available.end();iter1++) {
				if(tempNode->getID()==(*iter1)->getID()) {
					b = false;
					break;
				}

				if(tempNode->tempScore<(*iter1)->tempScore)
					break;
			}
			if(b)
				available.insert(iter1, tempNode);
		}
	}

	return plan;
}

/**
 * returning NULL means that there is no need to create a plan as there are no graph nodes with one of the nodes labels
 */
int* GraphX::generateWeightsBasedPlan(int startingNodeID, int* weights, GraphX* inputGraph) {
	int* plan = new int[this->getNumOfNodes()];
	plan[0] = startingNodeID;
	set<int> visited;
	//visited.insert(startingNodeID);
	vector<NodeX* > available;
	NodeX* startingNode = this->getNodeWithID(startingNodeID);

	for(map<int, NodeX*>::iterator iter = nodes.begin();iter!=nodes.end();iter++) {
		iter->second->tempScore = weights[iter->second->getID()]/iter->second->getEdgesSize();

//		if(iter->second->tempScore==0) {
//			set<int>* nodes = inputGraph->getNodeIDsByLabel(iter->second->getLabel());
//			if(nodes==NULL) {
//				delete[] plan;
//				return NULL;
//			}
//
//			int maxNumTraversedNodes = 1000;
//			int count1 = 0;
//			for(set<int>::iterator nodesIter = nodes->begin();nodesIter!=nodes->end();nodesIter++) {
//				count1++;
//				if(count1>maxNumTraversedNodes)//added on 24 Jan
//					break;
//
//				int aNodeID = (*nodesIter);
//				NodeX* aNode = inputGraph->getNodeWithID(aNodeID);
//				double sc = ((Features*)iter->second->getFeatures())->minSatisfyingDifference((Features*)aNode->getFeatures());
//				if(sc!=-1)
//					iter->second->tempScore+=sc;//it was ++
//			}
//
//			iter->second->tempScore = iter->second->tempScore/iter->second->getEdgesSize();
//
//		}

		cout<<iter->second->getID()<<":"<<iter->second->tempScore<<",";
	}
	cout<<endl;

	available.push_back(startingNode);
	int position = 0;
	while(available.size()>0) {
		NodeX* currentNode = *(available.begin());
		available.erase(available.begin());
		if(visited.find(currentNode->getID())!=visited.end())
			continue;
		else
			visited.insert(currentNode->getID());

		plan[position] = currentNode->getID();
		position++;
		//check neighbors of the current node
		for(map<int, void*>::iterator iter = currentNode->getEdgesIterator();iter!=currentNode->getEdgesEndIterator();++iter) {
			NodeX* tempNode = ((EdgeX*)iter->second)->getOtherNode();

			if(visited.find(tempNode->getID())!=visited.end())//this moved from below
				continue;

			bool b = true;
			vector<NodeX*>::iterator iter1 = available.begin();
			for(;iter1!=available.end();iter1++) {
				if(tempNode->getID()==(*iter1)->getID()) {
					b = false;
					break;
				}

//				if(tempNode->tempScore!=0 && (*iter1)->tempScore!=0 && tempNode->tempScore>(*iter1)->tempScore)
				if(tempNode->tempScore>(*iter1)->tempScore)
					break;
			}
			if(b)
				available.insert(iter1, tempNode);
		}
	}

	return plan;
}

vector<int* > GraphX::generateRandomPlans(int maxNumPlans, int firstNode) {
	int counter = 0;
	vector<int *> plans;

	while(counter<20 && plans.size()<maxNumPlans) {

		//geneate a random plan
		int* plan = new int[this->getNumOfNodes()];
		int step = 0;
		plan[0] = firstNode;
		tr1::unordered_set<NodeX*> next;
		tr1::unordered_set<int> visited;
		visited.insert(firstNode);

		while(true) {

			//generate neighbors of the last node
			for(map<int, void*>::iterator iter = getNodeWithID(plan[step])->getEdgesIterator();iter!=getNodeWithID(plan[step])->getEdgesEndIterator();iter++) {
				EdgeX* edge = (EdgeX*)iter->second;
				NodeX* otherNode = edge->getOtherNode();

				if(visited.find(otherNode->getID())==visited.end())
					next.insert(otherNode);
			}

			if(next.size()==0)
				break;

			//select a random node from the next nodes
			int r = rand();
			r = r % next.size();
			tr1::unordered_set<NodeX*>::iterator iter = next.begin();
			for(;r>0;r--) {
				iter++;
			}

			int selectedNodeID = (*iter)->getID();

			step++;
			plan[step] = selectedNodeID;
			visited.insert(selectedNodeID);
			next.erase((*iter));
		}

		//insert the new plan to the list of plans
		bool exists = false;
		for(vector<int *>::iterator iter = plans.begin();iter!=plans.end();iter++) {
			int* currentPlan = (*iter);

			bool similar = true;
			for(int i=0;i<getNumOfNodes();i++) {
				if(currentPlan[i]!=plan[i]) {
					similar = false;
					break;
				}
			}

			if(similar) {
				exists = true;
				break;
			}
		}

		if(exists) {
			delete[] plan;
		}
		else {
			plans.push_back(plan);
		}

		counter++;
	}

	return plans;
}

int GraphX::selectBestPlan(vector<int*>& plans, int type, GraphX* inputGraph, int graphNode, long& bestTimeR) {

	//commented for testing
//	if(plans.size()==1)
//		return 0;

	int bestPlan = -1;
	long bestTime = 100000;//100000000000;
	long limitedIterations = -1;//getNumOfNodes()*10000;;//-1;

	while(bestPlan==-1) {
		bestTime = bestTime*10;
//		cout<<"bestTime = "<<bestTime<<endl;
		for(int i=0;i<plans.size();i++) {

			long takenIterations = -1;
	//		long maxTime = -1;

			struct timeval tp;
			gettimeofday(&tp, NULL);
			long int start = tp.tv_sec * 1000000 + tp.tv_usec;// / 1000;

			bool finished;

			vector<int> result;
			if(type==0) {
				//isIsomorphic_IterativePlanModification(inputGraph, result, plans[i], NULL, 0, plans[i][0], graphNode, -1);
				bool tryOpt = false;
				finished = isIsomorphic_OneMatch_Fast_Pessimistic(inputGraph, result, plans[i], tryOpt, plans[i][0], graphNode, limitedIterations, NULL, NULL, &takenIterations, bestTime);
			}
			else if(type==1) {
				isIsomorphic_OneMatch_Fast_Super_Optimistic(inputGraph, result, plans[i], plans[i][0], graphNode, 10);

				if(result.size()==0)
					isIsomorphic_OneMatch_Fast_Super_Optimistic(inputGraph, result, plans[i], plans[i][0], graphNode, 10, NULL, true);
				else
					finished = true;

				if(result.size()==0) {
					//isIsomorphic_IterativePlanModification(inputGraph, result, plans[i], NULL, 1, plans[i][0], graphNode, -1);
					finished = isIsomorphic_OneMatch_Fast_Optimistic(inputGraph, result, plans[i], plans[i][0], graphNode, limitedIterations, NULL, &takenIterations, bestTime);
				}
				else
				{
					finished = true;
				}
			}

			if(!finished) {
//				cout<<"\t";
//				for(int j=0;j<this->getNumOfNodes();j++)
//					cout<<plans[i][j]<<",";
//				cout<<", NOT FINISHED"<<endl;
				continue;
			}

	//		if(limitedIterations>takenIterations || limitedIterations==-1) {
	//			limitedIterations = takenIterations;
	//			if(limitedIterations<10) limitedIterations = 10;
	//		}

			gettimeofday(&tp, NULL);
			long int end = tp.tv_sec * 1000000 + tp.tv_usec;// / 1000;

			long int elapsed = end-start;

			if(bestTime>elapsed) {
				bestTime = elapsed;
				bestPlan = i;
			}

//			cout<<"\t";
//			for(int j=0;j<this->getNumOfNodes();j++)
//				cout<<plans[i][j]<<",";
//			cout<<", time = "<<elapsed<<endl;
		}
	}

	bestTimeR = bestTime;
	return bestPlan;
}

int GraphX::getDegreeForPercentNodes(double prcnt) {
	int numNodes = this->getNumOfNodes();
	vector<int> degrees;

	//collect degrees
	for(map<int, NodeX*>::iterator iter = nodes.begin();iter!=nodes.end();iter++) {
		degrees.push_back(iter->second->getEdgesSize());
	}

	//sort the degrees vector
	std::sort (degrees.begin(), degrees.end());

	int sum = 0;
	for(vector<int>::iterator iter = degrees.begin();iter!=degrees.end();iter++) {
		sum++;
		if((((double)sum)/numNodes)>prcnt)
		{
			chosenDegree = (*iter);
			break;
		}
	}

	cout<<"[#nodes = "<<sum<<", chosenDegree = "<<chosenDegree<<"]";

	if(chosenDegree==-1){
		cout<<"Error 98294834bc"<<endl;
		exit(0);
	}

	return chosenDegree;
}

//Destructor
GraphX::~GraphX()
{
	for( map<int,NodeX*>::iterator ii=nodes.begin(); ii!=nodes.end(); ++ii)
	{
		delete ii->second;
	}
	nodes.clear();

	for( tr1::unordered_map<double, set<int>* >::iterator ii=nodeIDsByLabel.begin(); ii!=nodeIDsByLabel.end(); ++ii)
	{
		delete ii->second;
	}
	nodeIDsByLabel.clear();

	for( tr1::unordered_map<double, set<NodeX*>* >::iterator ii=nodesByLabel.begin(); ii!=nodesByLabel.end(); ++ii)
	{
		delete ii->second;
	}
	nodesByLabel.clear();
}
