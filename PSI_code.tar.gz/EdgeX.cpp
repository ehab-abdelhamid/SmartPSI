/*
 * EdgeX.cpp
 *
 *  Created on: Mar 16, 2013
 *      Author: ehab
 */

#include "EdgeX.h"

EdgeX::EdgeX(double label, NodeX* otherNode)
{
	this->label = label;
	this->otherNode = otherNode;
}
