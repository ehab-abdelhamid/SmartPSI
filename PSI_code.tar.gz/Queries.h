/*
 * Queries.h
 *
 *  Created on: Oct 22, 2015
 *      Author: abdelhe
 */

#ifndef QUERIES_H_
#define QUERIES_H_

#include<iostream>
#include<vector>
#include "Query.h"

using namespace std;

class Queries
{
private:
	vector<Query* >* queries;
	tr1::unordered_map<int, Query*> queriesByID;
	bool parseData(istream& data);

	long totalTime = 0;//total execution time in microseconds

	tr1::unordered_map<string, double > tempNameToNormalizeValue;

public:
	Queries();
	~Queries();

	bool loadFromFile(string );
	void exexuteQueries(GraphX* dataGraph);
	void discoverStatisticsOfPlans(GraphX* dataGraph);
	void discoverSlowestFastestPlans(GraphX* dataGraph);
	void discoverPlansAsFeatures(GraphX* dataGraph);
	void discoverPlansAsFeatures_2(GraphX* dataGraph);
	long getExecutionTime() { return totalTime; }
	void createBestPlanIndex(char* );
	int size() { return queries->size(); }
	Query* at(int i) { return queries->at(i); }
	void addQuery(Query* q) { queries->push_back(q); }
	void executeQueriesUsingMLResults(GraphX* , string modelFile, string mapFile);
//	void executeQueriesUisngML(GraphX* , string modelFile);
	Query* getQueryAt(int index) { return queries->at(index); }
};



#endif /* QUERIES_H_ */
