/*
 * GraphX.h
 *
 *  Created on: Mar 13, 2013
 *      Author: ehab
 *  This is for graph interface
 */

#ifndef GRAPHX_H_
#define GRAPHX_H_

#include <tr1/unordered_map>
#include <tr1/unordered_set>
#include <set>
#include <limits>
#include "NodeX.h"

#define allowThreaded 1

using namespace std;

class GraphX
{
private:
	int id;
	int type;//0-undirected, 1-directed, default value is 0. IMPORTANT: current algorithms do not support directed graphs
	map<int, NodeX*> nodes;
	//tr1::unordered_map<int, void* > nodesFeatures;
	int numOfEdges;
	tr1::unordered_map<double, set<int>* > nodeIDsByLabel;
	tr1::unordered_map<double, set<NodeX*>* > nodesByLabel;

	string CL;//canonical label
	int maxLabel;//the maximum node label value (note: the labels are currently in double!)
	tr1::unordered_map<string, int > edgesCount;
	int maxNodeID = -1;

	int numNodesBeforeDeletingNodes = -1;
	int chosenDegree = -1;

	//related to stats (node label to avg value)
	tr1::unordered_map<double, double> avgDegreeMap;
	tr1::unordered_map<double, double> avgWeightedDegreeMap;
	tr1::unordered_map<double, double> avgEccentricityMap;
	tr1::unordered_map<double, double> avgClosenessCentralityMap;
	tr1::unordered_map<double, double> avgBetweennessCentralityMap;
	tr1::unordered_map<double, double> avgAuthorityMap;
	tr1::unordered_map<double, double> avgHubMap;
	tr1::unordered_map<double, double> avgPageRankMap;
	tr1::unordered_map<double, double> avgClusteringCoefficientMap;
	tr1::unordered_map<double, double> avgNumTrianglesMap;
	tr1::unordered_map<double, double> avgEigenvectorCentralityMap;

public:
//	int static numIterations;
	int static numIsSatisfied;
	long static time4IstSatisfied;
	GraphX();
	GraphX(int, int );
	void init(int, int );
	GraphX(GraphX* );
	~GraphX();
	bool parseData(istream& data);
	bool loadFromFile(string fileName);
	bool loadFromString(string data);
	void loadNodesStats(string fileName);
	void storeNodeFeatures(string fileName);
	void loadNodeFeatures(string fileName);
	NodeX* AddNode(int id, double label);
	void addEdge(int , int , double);
	void addEdge(int , int , double ,map<string, void* >& );
	void removeEdge(int , int );
	void removeNode_IgnoreEdges(int );
	map<int,NodeX*>::const_iterator getNodesIterator();
	map<int,NodeX*>::const_iterator getNodesEndIterator();
	int getID() {return id;}
	int getType() {return type;}
	double getEdgeLabel(int srcNode, int destNode);
	int getNumOfNodes();
	NodeX* getNodeWithID(int nodeID);
	set<int>* getNodeIDsByLabel(double );
	set<NodeX*>* getNodesByLabel(double );
	friend ostream& operator<<(ostream& os, const GraphX& g);
	int getNumOfEdges() {return numOfEdges;}
	bool isConnected();
	//this subgraph isomorphism code is correct
	void isIsomorphic(GraphX* graph, vector<map<int, int>* >& , tr1::unordered_map<int, tr1::unordered_set<int>*>& , int* ,int restrictedDomainID = -1, int restrictedNodeID = -1, bool pruneByDomainValues = true);
	void isIsomorphic_OneMatch(GraphX* graph, vector<int>& results, tr1::unordered_map<int, tr1::unordered_set<int>*>& domains_values, int* plan , int restrictedDomainID = -1, int restrictedNodeID = -1, bool pruneByDomainValues = true);
	void isIsomorphic_OneMatch_Fast(GraphX* graph, vector<int>& results, int* plan , int restrictedDomainID = -1, int restrictedNodeID = -1);

	bool isIsomorphic_IterativePlanModification(GraphX* graph, vector<int>& results, int* plan , int type, int restrictedDomainID = -1, int restrictedNodeID = -1, long limitedIterations=-1, vector<tr1::unordered_map<int, int>*>* embeddings = NULL, bool doNotModifyPlansForIncorrectPrediction = false, int temp=1);
	bool isIsomorphic_IterativePlanModification_2(GraphX* graph, vector<int>& results, int* plan , int type, int restrictedDomainID = -1, int restrictedNodeID = -1, long limitedIterations=-1, vector<tr1::unordered_map<int, int>*>* embeddings = NULL, bool doNotModifyPlansForIncorrectPrediction = false, int temp=1);
	bool isIsomorphic_IterativePlanModification(GraphX* graph, vector<int>& results, int* plan, tr1::unordered_map<string, int*>* sigToPlan, int type, int restrictedDomainID, int restrictedNodeID, long limitedIterations);


	bool isIsomorphic_OneMatch_Fast_Pessimistic(GraphX* graph, vector<int>& results, int* plan , bool& tryOpt, int restrictedDomainID = -1, int restrictedNodeID = -1, long limitedIterations=-1, vector<int>* stuckQueryNodes=NULL, tr1::unordered_map<int, int>* foundEmbedding=NULL, long* takenIterations = NULL, long int maxTime = -1);
	bool isIsomorphic_OneMatch_Fast_Pessimistic_2(GraphX* graph, vector<int>& results, int* plan , int restrictedDomainID, int restrictedNodeID, long limitedIterations, vector<int>* stuckQueryNodes, tr1::unordered_map<int, int>* foundEmbedding, int* weights);
	//void isIsomorphic_OneMatch_Fast_Super_Pessimistic(GraphX* graph, vector<int>& results, int restrictedDomainID = -1, int restrictedNodeID = -1);

	bool isIsomorphic_OneMatch_Fast_Optimistic(GraphX* graph, vector<int>& results, int* plan , int restrictedDomainID = -1, int restrictedNodeID = -1, long limitedIterations=-1, vector<int>* stuckQueryNodes=NULL, long* takenIterations = NULL, long int maxTime = -1);
	void isIsomorphic_OneMatch_Fast_Super_Optimistic(GraphX* graph, vector<int>& results, int* plan , int restrictedDomainID, int restrictedNodeID, int maxToVisit, tr1::unordered_map<int, tr1::unordered_map<string, void* >* >* embeddingsFeatures = NULL, bool useLessMatchingNodes = false);
	string getCanonicalLabel();
	void createMLIndex();
	string getNodeStignature(int nodeID);
	bool canSatisfy(GraphX* subgraph);
	int getNumDistinctLabels() { return nodeIDsByLabel.size(); }
	void populateEdgesCount();
	void printEdgesCount();
	void printNodesFeatures();

	void populateNodesFeatures();
	void populateNodesFeatures_FAST(int );//this is new here
	void generateFeaturesKeys();

	tr1::unordered_map<string, int >* getEdgesCount() { return &(this->edgesCount); }
	int* generateTreeFirstPlan(int , GraphX* );
	int* generateCoresFirstPlan(int );
	int* generateSelectBasedPlan(int , GraphX* );
	int* generateWeightsBasedPlan(int startingNodeID, int* weights, GraphX* inutGraph);

	vector<int* > generateRandomPlans(int maxNumPlans, int firstNode);
	int selectBestPlan(vector<int*>& plans, int type, GraphX* inputGraph, int graphNode, long& bestTime);

	//grah stats
	NodeStats* getAvgNodeStats(double label);
	int getDegreeForPercentNodes(double prcnt);

	void setNumNodesBeforeDeletingNodes(int n) { numNodesBeforeDeletingNodes = n; }
	int getChosenDegree() { return this->chosenDegree; }
};

ostream& operator<<(ostream& , const GraphX& );

class Set_Iterator
{
public:
	Set_Iterator() {}
	~Set_Iterator() {}
	//int id;//node id in the to be matched graph
	set<int>* se;//list of candidate nodes in the graph to match with
	set<int>::iterator it;//iterator over elements in se
	bool isIterEnd() { return it==se->end(); }
	void print();
};

class Set_Nodes_Iterator
{
public:
	//int static st_SI;
	Set_Nodes_Iterator() {}
	~Set_Nodes_Iterator() {}
	set<NodeX*>* se;//list of candidate nodes in the graph to match with
	set<NodeX*>::iterator it;//iterator over elements in se
	bool isIterEnd() { return it==se->end(); }
	void print();
};

class Edge_Iterator
{
private:
	map<int, void*>::iterator endIterator;
	map<int, void*>::iterator it;//iterator over elements in se

public:
	//int static st_SI;
	Edge_Iterator(map<int, void*>::iterator beginIter, map<int, void*>::iterator endIter) {it = beginIter;endIterator = endIter;}
	~Edge_Iterator() {}
	NodeX* getCurrentNode();
	void advance()
	{
		it++;
	}
	bool isIterEnd() { return it==endIterator; }
};

class Node_Score {
public:
	NodeX* node;
	double score;
};

//the set of nodes ordered ascendingly based on a scoring function
class Set_Nodes_Prioritized_Iterator
{
private:
	double minValue;
	double maxValue;
	int size = 0;
public:
	//int static st_SI;
	Set_Nodes_Prioritized_Iterator() {size = 0;}
	~Set_Nodes_Prioritized_Iterator();
	vector<Node_Score*>* se;//list of candidate nodes in the graph to match with
	vector<Node_Score*>::iterator it;//iterator over elements in se
	bool isIterEnd() { return it==se->end(); }
	void print();
	void insertOrdered(Node_Score* ns);
	void insertAtBack(Node_Score* ns)
	{
		if(ns->score>maxValue)
		{
			se->insert(se->begin(), ns);
			maxValue = ns->score;
		}
		else
		{
			se->push_back(ns);
		}
	}

	void replaceIfBetter(Node_Score* ns);
	void cutIfLarger(int s, bool maintainOnes=false);
	int getSize() { return size; }
};

#endif /* GRAPHX_H_ */
