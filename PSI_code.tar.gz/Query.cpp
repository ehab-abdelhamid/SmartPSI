/*
 * Query.cpp
 *
 *  Created on: Oct 22, 2015
 *      Author: abdelhe
 */

#include <iostream>
#include "Query.h"

Query::Query(GraphX* graph)
{
	this->graph = graph;
	this->id = graph->getID();

	bestPlan = new int[graph->getNumOfNodes()];
	worstPlan = new int[graph->getNumOfNodes()];
}

GraphX* Query::getGraph()
{
	return graph;
}

/**
 * maxPrefix refers to the maximum size of prefix that has all combinations, the rest of the plan is generated based on a hueristic approach
 */
vector<int* > Query::getPossiblePlans(int maxPrefix, GraphX* inputGraph)
{
	vector<int* > plans;
	for(int i=0;i<graph->getNumOfNodes();i++)
	{
		vector<int* > subPlans = getPossiblePlans_restricted(i, maxPrefix, inputGraph);
		plans.insert(plans.begin(), subPlans.begin(), subPlans.end());
	}
	return plans;
}

vector<int* > Query::getPossiblePlans_restricted(int startNodeID, int maxPrefix, GraphX* inputGraph)
{
	vector<int* > plans;

	int* plan = new int[graph->getNumOfNodes()];
	plan[0] = startNodeID;

	addPlan(plan, 1, plans, maxPrefix, inputGraph);

	delete[] plan;

	return plans;
}

void Query::addPlan(int* plan, int size, vector<int*>& plans, int maxPrefix, GraphX* inputGraph)
{
	if(size==graph->getNumOfNodes())
	{
		int* realPlan = new int[size];
		for(int i=0;i<size;i++) {
			realPlan[i] = plan[i];
//			cout<<plan[i]<<",";
		}
//		cout<<endl;
		plans.push_back(realPlan);
		return;
	}

	//in case we have met the maxPrefix limit
	if(size==maxPrefix)
	{
		int* realPlan = new int[graph->getNumOfNodes()];

		tr1::unordered_set<int> checked;
		tr1::unordered_set<int> available;

		//initialize checked and available based on the already selected nodes
		for(int i=0;i<size;i++) {
			realPlan[i] = plan[i];

			checked.insert(plan[i]);

			NodeX* currNode = graph->getNodeWithID(plan[i]);

			for(map<int, void*>::iterator iter = currNode->getEdgesIterator();iter!=currNode->getEdgesEndIterator();++iter)
			{
				int otherID = iter->first;
				if(checked.find(otherID)==checked.end())
				{
					available.insert(otherID);
				}
			}
		}

		//start filling the remaining of the plan according to a heuristic
		int count = size;
		while(available.size()>0)
		{
			//select the best node from available
			tr1::unordered_set<int>::iterator iter1 = available.begin();
			set<int>* nodesWithLabel = inputGraph->getNodeIDsByLabel(this->getGraph()->getNodeWithID((*iter1))->getLabel());
			double bestScore = 0;
			if(nodesWithLabel!=NULL)
				bestScore = nodesWithLabel->size()/((double)this->getGraph()->getNodeWithID((*iter1))->getEdgesSize());
			int bestNode = *iter1;
			iter1++;

			for(;iter1!=available.end();++iter1)
			{
				double currScore = 0;
				nodesWithLabel = inputGraph->getNodeIDsByLabel(this->getGraph()->getNodeWithID((*iter1))->getLabel());
				if(nodesWithLabel!=NULL)
					currScore = nodesWithLabel->size()/((double)this->getGraph()->getNodeWithID((*iter1))->getEdgesSize());
				int currID = *iter1;

				if(currScore<bestScore) {
					bestScore = currScore;
					bestNode = currID;
				}
			}

			int current = bestNode;

			available.erase(bestNode);
			if(checked.find(current)!=checked.end())
				continue;
			realPlan[count] = current;
			checked.insert(current);
			count++;
			NodeX* currNode = this->getGraph()->getNodeWithID(current);

			for(map<int, void*>::iterator iter = currNode->getEdgesIterator();iter!=currNode->getEdgesEndIterator();++iter)
			{
				int otherID = iter->first;
				if(checked.find(otherID)==checked.end())
				{
					available.insert(otherID);
				}
			}
		}

		plans.push_back(realPlan);
		return;
	}

	//get possible next nodes
	tr1::unordered_set<int> checked;
	for(int i=0;i<size;i++)
	{
		NodeX* currNode = graph->getNodeWithID(plan[i]);
		for(map<int, void*>::iterator iter = currNode->getEdgesIterator();iter!=currNode->getEdgesEndIterator();++iter)
		{
			int otherID = iter->first;
			//check existence
			bool exists = false;
			for(int j=0;j<size;j++)
			{
				if(otherID==plan[j])
				{
					exists = true;
					break;
				}
			}
			if(!exists && checked.find(otherID)==checked.end())
			{
				checked.insert(otherID);
				plan[size] = otherID;
				addPlan(plan, size+1, plans, maxPrefix, inputGraph);
			}
		}
	}
}

void Query::printPlans(vector<int* > plans)
{
	for(int i=0;i<plans.size();i++)
	{
		int* plan = plans.at(i);
		for(int j=0;j<graph->getNumOfNodes();j++)
		{
			cout<<plan[j]<<",";
		}
		cout<<endl;
	}
}

void Query::setBestPlan(int* bp)
{
	for(int i=0;i<graph->getNumOfNodes();i++)
	{
		this->bestPlan[i] = bp[i];
	}
}

void Query::setWorstPlan(int* wp)
{
	for(int i=0;i<graph->getNumOfNodes();i++)
	{
		this->worstPlan[i] = wp[i];
	}
}

void Query::print()
{
	cout<<*(this->getGraph())<<endl;

	cout<<"Best plan: ";
	int* plan = this->getBestPlan();
	for(int j=0;j<this->getGraph()->getNumOfNodes();j++)
	{
		cout<<plan[j]<<",";
	}
	cout<<endl;

	cout<<"Worst plan: ";
	plan = this->getWorstPlan();
	for(int j=0;j<this->getGraph()->getNumOfNodes();j++)
	{
		cout<<plan[j]<<",";
	}
	cout<<endl;
}

Query::~Query()
{
	delete graph;

	if(bestPlan!=0)
		delete[] bestPlan;
	if(worstPlan!=0)
		delete[] worstPlan;
}
