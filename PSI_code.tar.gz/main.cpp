/*
 * main.cpp
 *
 *  Created on: Oct 21, 2015
 *      Author: abdelhe
 */
#include <shark/Data/Csv.h>
//#include <shark/Algorithms/Trainers/LDA.h>
#include <shark/Algorithms/Trainers/RFTrainer.h> //the random forest trainer
#include <shark/ObjectiveFunctions/Loss/ZeroOneLoss.h> //zero one loss for evaluation
#include <shark/Models/Normalizer.h>
#include <shark/Algorithms/Trainers/NormalizeComponentsUnitVariance.h>
//#include <shark/ObjectiveFunctions/Loss/SquaredLoss.h>
#include <shark/Algorithms/Trainers/LinearRegression.h>
#include <shark/Algorithms/Trainers/CSvmTrainer.h> // the C-SVM trainer
#include <shark/Models/Kernels/GaussianRbfKernel.h> //the used kernel for the SVM

#include <shark/Models/NearestNeighborClassifier.h>
#include <shark/Algorithms/NearestNeighbors/TreeNearestNeighbors.h>
#include <shark/Models/Trees/KDTree.h>

#include<shark/Models/FFNet.h> //the feed forward neural network
#include<shark/Algorithms/GradientDescent/Rprop.h> //resilient propagation as optimizer
#include<shark/ObjectiveFunctions/Loss/CrossEntropy.h> // loss during training
#include<shark/ObjectiveFunctions/ErrorFunction.h> //error function to connect data model and loss
#include<shark/Models/Softmax.h> //transforms model output into probabilities
#include<shark/Models/ConcatenatedModel.h> //provides operator >> for concatenating models

using namespace shark;

#include <iostream>
#include <string.h>
#include <tr1/unordered_map>
#include <fstream>
#include <cmath>
#include <sys/time.h>
#include "GraphX.h"
#include "TimeUtility.h"
#include "Queries.h"
#include "BasicIndex.h"
#include "Features.h"
#include "FastExistenceList.h"
#include "Statistics.h"
#include "utils.h"

#include <boost/thread.hpp>
#include <boost/asio/io_service.hpp>
#include <boost/bind.hpp>

using namespace std;

int Statistics::predictedValids = 0;
int Statistics::predictedInvalids = 0;
int Statistics::numCorrects = 0;
int Statistics::numIncorrects = 0;
int Statistics::trueValids = 0;
int Statistics::trueInvalids = 0;
int Statistics::foundValids = 0;
int Statistics::foundInvalids = 0;
int Statistics::validFoundInvalid = 0;
int Statistics::validFoundValid = 0;
long Statistics::defaultPessimisticTime = 0;
long Statistics::defaultOptimisticTime = 0;
long Statistics::predictionPreparationTime = 0;
long Statistics::predictionTime = 0;
long Statistics::timeCorrectlySpentOnValid = 0;
long Statistics::timeIncorrectlySpentOnValid = 0;
long Statistics::timeCorrectlySpentOnInvalid = 0;
long Statistics::timeIncorrectlySpentOnInvalid = 0;
long Statistics::bestTime = 0;
long Statistics::trainingTime = 0;
long Statistics::optimizedSubIsoTime = 0;
long Statistics::threadedTime = 0;
long Statistics::best_timeTime = 0;
long Statistics::best_desisionTime = 0;
bool Statistics::interrupt = false;
int Statistics::numValids_threaded = 0;
int Statistics::numInvalids_threaded = 0;
int Statistics::numValids_optimal = 0;
int Statistics::numInvalids_optimal = 0;
//hybrid
long Statistics::h_predictionPreparationTime = 0;
long Statistics::h_trainingTime = 0;
long Statistics::h_predictionTime = 0;
long Statistics::h_optimizedSubIsoTime = 0;
long Statistics::h_numCorrects = 0;
long Statistics::h_numIncorrects = 0;
long Statistics::h_numValids = 0;
long Statistics::h_numInvalids = 0;
long Statistics::hybridTime = 0;
long Statistics::numInconfidentDecisions = 0;
long Statistics::h_nmMLDecided = 0;
long Statistics::h_nmCached = 0;
//optimistic
long Statistics::opt_validFoundInvalid = 0;
long Statistics::opt_numValids = 0;
long Statistics::opt_numInvalids = 0;

bool showForDebug = false;

class predictionPair
{
public:
	double valid;
	double invalid;
	predictionPair(double v, double inv) {valid = v; invalid = inv;}
};

void test()
{

}

class DoDividedThreaded_Advanced
{

private:
	GraphX* graph;
	GraphX* queryGraph;
	int domainID;
	tr1::unordered_map<int, int>::iterator nodesIter;
	tr1::unordered_map<int, int>::iterator iterPlanPess;
	tr1::unordered_map<int, int>::iterator iterPlanOpt;

	boost::mutex iterMutex;
	boost::mutex updateMutex;
	int* plan1;
	int* plan2;

	tr1::unordered_set<int>* trainingNodeIDs;
	set<int>* threadedNodes;
	tr1::unordered_map<int, int>* nodeIDToDecision;
	tr1::unordered_map<int, int> nodeIDToPlanPess;
	tr1::unordered_map<int, int> nodeIDToPlanOpt;
	vector<int>* validNodeIDs;

	PlansStats pStatsPess;
	PlansStats pStatsOpt;

	vector<int*> plans;

	bool done1;
	bool done2;

public:

	DoDividedThreaded_Advanced(GraphX* graph, GraphX* queryGraph, int domainID)
	{
		this->graph = graph;
		this->queryGraph = queryGraph;
		this->domainID = domainID;
	}

	void setValues(tr1::unordered_set<int>* trainingNodeIDs,
				tr1::unordered_map<int, int>* nodeIDToDecision,
				vector<int>* validNodeIDs,
				set<int>* threadedNodes,
				tr1::unordered_map<int, int>& nodeIDToPlanPess,
				tr1::unordered_map<int, int>& nodeIDToPlanOpt,
				PlansStats& pStatsPess,
				PlansStats& pStatsOpt,
				vector<int*>& plans) {
		this->trainingNodeIDs = trainingNodeIDs;
		this->nodeIDToDecision = nodeIDToDecision;
		this->validNodeIDs = validNodeIDs;
		this->threadedNodes = threadedNodes;
		this->nodeIDToPlanPess = nodeIDToPlanPess;
		this->nodeIDToPlanOpt = nodeIDToPlanOpt;
		iterPlanPess = nodeIDToPlanPess.begin();
		iterPlanOpt = nodeIDToPlanOpt.begin();
		this->pStatsPess = pStatsPess;
		this->pStatsOpt = pStatsOpt;
		this->plans = plans;
	}

	void processNodes_1() {
		processNodes(plan1);
		done1 = true;
	}
	void processNodes_2() {
		processNodes(plan2);
		done2 = true;
	}

	void processNodes(int* invalidPlan) {

		int counter = 0;
		int maxToVisit = 10;
		int numValidsFoundInvalid = 0;
		int numValidsFoundValid = 0;
		long numIterationBeforePlanChanges = queryGraph->getNumOfNodes()*10000;

		tr1::unordered_map<string, int*>* sigToPlan = new tr1::unordered_map<string, int*>();

		while(true)
		{
			iterMutex.lock();
			if(nodesIter==nodeIDToDecision->end())
			{
				iterMutex.unlock();
				break;
			}

			double prevValidsFoundInvalid = 1;

			//do subgraph isomorphism for current node
			int predicted = nodesIter->second;

			int selectedPlanPess;
			if(iterPlanPess==nodeIDToPlanPess.end())
			{
				int* tPlan = pStatsPess.getMostPopularPlan();
				if(tPlan!=NULL)
					selectedPlanPess = PlansStats::getPlanNumber(plans, queryGraph->getNumOfNodes(), tPlan);
				else
					selectedPlanPess = 0;
			}
			else
			{
				selectedPlanPess = iterPlanPess->second;
			}

			int selectedPlanOpt;
			if(iterPlanOpt==nodeIDToPlanOpt.end())
			{
				int* tPlan = pStatsOpt.getMostPopularPlan();
				if(tPlan!=NULL)
					selectedPlanOpt = PlansStats::getPlanNumber(plans, queryGraph->getNumOfNodes(), tPlan);
				else
					selectedPlanOpt = 0;
			}
			else
			{
				selectedPlanOpt = iterPlanOpt->second;
			}

			int nodeID = nodesIter->first;
			NodeX* graphNode = graph->getNodeWithID(nodesIter->first);

			nodesIter++;
			iterPlanPess++;
			iterPlanOpt++;

			iterMutex.unlock();

			//assign the source node ID that give the decision
			int sourceOfDecision = nodeID;

			//check if a similar node was visited before
			if(predicted>1) {
				int planPredicted = predicted;
				string featuresKey = graphNode->getFeaturesKey();
				sourceOfDecision = predicted-2;
				tr1::unordered_map<int, int>::iterator ToPrediction = nodeIDToDecision->find(predicted-2);
				if(ToPrediction!=nodeIDToDecision->end()) {
					predicted = ToPrediction->second;
				}
				else
				{
					cout<<"ERRRROR2653623"<<endl;
					exit(0);
				}

				//get the pessimistic plan
				tr1::unordered_map<int, int>::iterator ToPlanPredictionPess = nodeIDToPlanPess.find(planPredicted-2);
				if(ToPlanPredictionPess!=nodeIDToPlanPess.end()) {
					selectedPlanPess = ToPlanPredictionPess->second;
				}
				else
				{
					cout<<"ERRRROR2443623"<<endl;
					exit(0);
				}

				//get the optimistic plan
				tr1::unordered_map<int, int>::iterator ToPlanPredictionOpt = nodeIDToPlanOpt.find(planPredicted-2);
				if(ToPlanPredictionOpt!=nodeIDToPlanOpt.end()) {
					selectedPlanOpt = ToPlanPredictionOpt->second;
				}
				else
				{
					cout<<"ERRRROR2443623"<<endl;
					exit(0);
				}
			}

			if(trainingNodeIDs->find(nodeID)!=trainingNodeIDs->end() ||
					(threadedNodes!=NULL && threadedNodes->find(nodeID)!=threadedNodes->end()))
				continue;

			counter++;

			int foundValid = 0;//decision found by prediction

			//do states-based isomorphism:
			//0: do predicted + selectedPlan(predicted)
			//1: do !predicted + selectedPlan(!predicted)
			//2: do predicted + popularPlan(predicted)
			//3: do !predicted + popularPlan(!predicted)
			//4: get back to 0, but without time limit <- the normal doIterations function

			for(int state = 0;state<5;state++) {

				int selectedPlan;

				int tempPredicted;
				long maxTime = -1;

				switch(state) {
				case 0:
					tempPredicted = predicted;
					if(predicted==0)
						selectedPlan = selectedPlanPess;
					else
						selectedPlan = selectedPlanOpt;
					break;
				case 1:
					tempPredicted = 1-predicted;
					if(tempPredicted==0)
						selectedPlan = selectedPlanPess;
					else
						selectedPlan = selectedPlanOpt;
					break;
				case 2:
					tempPredicted = predicted;
					if(tempPredicted==0) {
						selectedPlan = 0;//PlansStats::getPlanNumber(plans, queryGraph->getNumOfNodes(), pStatsPess.getMostPopularPlan());
						if(selectedPlan==-1) selectedPlan = 0;
					}
					else {
						selectedPlan = 0;//PlansStats::getPlanNumber(plans, queryGraph->getNumOfNodes(), pStatsOpt.getMostPopularPlan());
						if(selectedPlan==-1) selectedPlan = 0;
					}
					break;
				case 3:
					tempPredicted = 1-predicted;
					if(tempPredicted==0) {
						selectedPlan = 0;//PlansStats::getPlanNumber(plans, queryGraph->getNumOfNodes(), pStatsPess.getMostPopularPlan());
						if(selectedPlan==-1) selectedPlan = 0;
					}
					else {
						selectedPlan = 0;//PlansStats::getPlanNumber(plans, queryGraph->getNumOfNodes(), pStatsOpt.getMostPopularPlan());
						if(selectedPlan==-1) selectedPlan = 0;
					}
					break;
				case 4:
					tempPredicted = predicted;
					if(predicted==0)
						selectedPlan = 0;//selectedPlanPess;
					else
						selectedPlan = 0;//selectedPlanOpt;
					maxTime = -1;
					break;
				}

				if(state<4) {
					if(tempPredicted==1)
						maxTime = pStatsOpt.getMaxAcceptableTime(plans[selectedPlan], queryGraph->getNumOfNodes());//3332
					else
						maxTime = pStatsPess.getMaxAcceptableTime(plans[selectedPlan], queryGraph->getNumOfNodes());//52

					if(maxTime<10) maxTime = 10;
				}

				if(tempPredicted==1) {
					//conduct optimistic search
					vector<int> result;
					queryGraph->isIsomorphic_OneMatch_Fast_Super_Optimistic(graph, result, plans[selectedPlan], domainID, nodeID, maxToVisit);
					if(result.size()==0)
						queryGraph->isIsomorphic_OneMatch_Fast_Super_Optimistic(graph, result, plans[selectedPlan], domainID, nodeID, maxToVisit, NULL, true);

					if(result.size()==0)
					{
						if(state<4) {
							bool b = queryGraph->isIsomorphic_OneMatch_Fast_Optimistic(graph,
									result,
									plans[selectedPlan],
									domainID,
									nodeID,
									-1,
									NULL,
									NULL,
									maxTime);

							//if cannot complete within the alloted time, continue for the next for iteration
							if(!b) {
								continue;
							}

						}
						else
						{
							queryGraph->isIsomorphic_IterativePlanModification(graph, result, plans[selectedPlan], sigToPlan, 1, domainID, nodeID, numIterationBeforePlanChanges);
						}

						numValidsFoundInvalid++;
					}
					else {
						numValidsFoundValid++;
					}

					if(result.size()>0) {
						foundValid = 1;
					}
					else {
						numValidsFoundInvalid--;
					}

					//break from the states loop
					break;
				}
				else if(tempPredicted==0)
				{
					//conduct pessimistic search
					vector<int> result;

					/*cout<<"nodeID:"<<nodeID<<",plans.size="<<plans.size()<<",selectedPlan="<<selectedPlan<<endl<<flush;
					cout<<"Plan = ";
					for(int i=0;i<queryGraph->getNumOfNodes();i++) {
						cout<<plans[selectedPlan][i]<<","<<flush;
					}
					cout<<endl<<flush;*/

					if(state<4) {
						bool tryOpt = false;
						bool b = queryGraph->isIsomorphic_OneMatch_Fast_Pessimistic(graph,
								result,
								plans[selectedPlan],
								tryOpt,
								domainID,
								nodeID,
								-1,
								NULL,
								NULL,
								NULL,
								maxTime);

						//if cannot complete within the alloted time, continue for the next for iteration
						if(!b) {
							continue;
						}
					}
					else
					{
						queryGraph->isIsomorphic_IterativePlanModification(graph, result, plans[selectedPlan], sigToPlan, 0, domainID, nodeID, numIterationBeforePlanChanges);
					}

					if(result.size()>0) {
						foundValid = 1;
					}
					else {
					}

					//break from the states loop
					break;
				}
				else {
					cout<<"Error55533: no prediction is found for this node"<<endl;
					exit(0);
				}
			}

			//update the shared and global data
			updateMutex.lock();

			if(counter%100000==0 && counter!=0)
				cout<<"Actual: "<<counter<<"/"<<(nodeIDToDecision->size())<<endl;

			bool isCorrect = false;

			///**********
			if(predicted==1) {
				Statistics::predictedValids++;
				if(foundValid==1)
				{
					Statistics::h_numCorrects++;
					Statistics::h_numValids++;
					validNodeIDs->push_back(nodeID);
					isCorrect = true;
				}
				else if(foundValid==0)
				{
					Statistics::h_numIncorrects++;
					Statistics::h_numInvalids++;
				}
			} else {
				Statistics::predictedInvalids++;
				if(foundValid==0)
				{
					Statistics::h_numCorrects++;
					Statistics::h_numInvalids++;
					isCorrect = true;
				}
				else if(foundValid==1)
				{
					Statistics::h_numIncorrects++;
					Statistics::h_numValids++;
					validNodeIDs->push_back(nodeID);
				}
			}

			updateMutex.unlock();

			if(!isCorrect) {
				iterMutex.lock();
				nodeIDToDecision->find(nodeID)->second = foundValid;
				iterMutex.unlock();
			}
		}
	}

	/**
	 * Do pivoted subgraph isomorphism using two threads; one for optimistic and the other for pessimistic
	 * */
	void doThreaded() {

//		TimeUtility::StartCounterMicro();

		this->nodeIDToDecision = nodeIDToDecision;

		//preparation
		int* invalidPlan = queryGraph->generateSelectBasedPlan(domainID, graph);

		int n = queryGraph->getNumOfNodes();
		plan1  = new int[n];
		plan2  = new int[n];
		for(int i=0;i<n;i++) {
			plan1[i] = invalidPlan[i];
			plan2[i] = invalidPlan[i];
		}

		//Create an asio::io_service and a thread_group (through pool in essence)
		boost::asio::io_service ioService;
		boost::thread_group threadpool;
		//This will start the ioService processing loop. All tasks assigned with ioService.post() will start executing.
		boost::asio::io_service::work work(ioService);

		/*
		 * This will add 2 threads to the thread pool. (You could just put it in a for loop)
		 */
		for(int i=0;i<2;i++) {
			threadpool.create_thread(
					boost::bind(&boost::asio::io_service::run, &ioService)
			);
		}

		nodesIter = nodeIDToDecision->begin();

		done1 = false;
		done2 = false;
		ioService.post(boost::bind(&DoDividedThreaded_Advanced::processNodes_1, this));
		ioService.post(boost::bind(&DoDividedThreaded_Advanced::processNodes_2, this));

		while(true) {
			if(done1 && done2) break;
			boost::this_thread::sleep(boost::posix_time::milliseconds(1));
		}

		//This will stop the ioService processing loop. Any tasks you add behind this point will not execute.
		ioService.stop();
		//wait for all tasks to finish
		threadpool.join_all();

		delete[] plan1;
		delete[] plan2;
		delete[] invalidPlan;
	}
};

class DoDividedThreaded
{
private:
	GraphX* graph;
	GraphX* queryGraph;
	int domainID;
	tr1::unordered_map<int, int>::iterator nodesIter;
	boost::mutex iterMutex;
	boost::mutex updateMutex;
	int* plan1;
	int* plan2;

	set<int>* trainingNodeIDs;
	set<int>* threadedNodes;
	tr1::unordered_map<int, int>* nodeIDToDecision;
	vector<int>* validNodeIDs;

	bool done1;
	bool done2;

public:

	DoDividedThreaded(GraphX* graph, GraphX* queryGraph, int domainID)
	{
		this->graph = graph;
		this->queryGraph = queryGraph;
		this->domainID = domainID;
	}

	void setValues(set<int>* trainingNodeIDs,
				tr1::unordered_map<int, int>* nodeIDToDecision,
				vector<int>* validNodeIDs,
				set<int>* threadedNodes) {
		this->trainingNodeIDs = trainingNodeIDs;
		this->nodeIDToDecision = nodeIDToDecision;
		this->validNodeIDs = validNodeIDs;
		this->threadedNodes = threadedNodes;
	}

	void processNodes_1() {
		processNodes(plan1);
		done1 = true;
	}
	void processNodes_2() {
		processNodes(plan2);
		done2 = true;
	}

	void processNodes(int* invalidPlan) {

		int counter = 0;
		int maxToVisit = 10;
		int numValidsFoundInvalid = 0;
		int numValidsFoundValid = 0;
		long numIterationBeforePlanChanges = queryGraph->getNumOfNodes()*10000;

		double prevValidsFoundInvalid = 1;

		int* validPlan = new int[queryGraph->getNumOfNodes()];
		for(int i=0;i<queryGraph->getNumOfNodes();i++) {
			validPlan[i] = invalidPlan[i];
		}
		tr1::unordered_map<string, int*>* sigToPlan = new tr1::unordered_map<string, int*>();

		int c = 0;
		while(true)
		{
			iterMutex.lock();
			if(nodesIter==nodeIDToDecision->end())
			{
				iterMutex.unlock();
				break;
			}

			int nodeID = nodesIter->first;
			int predicted = nodesIter->second;

			nodesIter++;
//			c++;cout<<"counter = "<<c<<", NodeID="<<nodeID<<", prediction = "<<predicted<<endl;

//			if(nodesIter==nodeIDToDecision->end())
//			{
//				iterMutex.unlock();
//				break;
//			}

			//assign the source node ID that give the decision
			int sourceOfDecision = nodeID;

			//check if a similar node was visited before
			if(predicted>1) {
				sourceOfDecision = predicted-2;
				tr1::unordered_map<int, int>::iterator ToPrediction = nodeIDToDecision->find(predicted-2);
				if(ToPrediction!=nodeIDToDecision->end()) {
					predicted = ToPrediction->second;
				}
				else
				{
					cout<<"ERRRROR2653623"<<endl;
					exit(0);
				}
			}

			iterMutex.unlock();

			if(trainingNodeIDs->find(nodeID)!=trainingNodeIDs->end() ||
					(threadedNodes!=NULL && threadedNodes->find(nodeID)!=threadedNodes->end()))
				continue;

			//do subgraph isomorphism for current node
			NodeX* graphNode = graph->getNodeWithID(nodeID);

			counter++;

			bool foundValid = false;//decision found by prediction
			bool isCorrect = false;

			struct timeval tp;
			gettimeofday(&tp, NULL);
			long int start = tp.tv_sec * 1000 + tp.tv_usec / 1000;
			if(predicted==1) {

				//conduct optimistic search
				vector<int> result;
				queryGraph->isIsomorphic_OneMatch_Fast_Super_Optimistic(graph, result, validPlan, domainID, nodeID, maxToVisit);

				if(result.size()==0)
					queryGraph->isIsomorphic_OneMatch_Fast_Super_Optimistic(graph, result, validPlan, domainID, nodeID, maxToVisit, NULL, true);

				if(result.size()==0)
				{
//					queryGraph->isIsomorphic_IterativePlanModification(graph, result, validPlan, 1, domainID, nodeID, numIterationBeforePlanChanges, NULL, true);
					queryGraph->isIsomorphic_IterativePlanModification(graph, result, validPlan, sigToPlan, 1, domainID, nodeID, numIterationBeforePlanChanges);

//					if(showForDebug)
//						cout<<" validfoundinvalid ";

					if(result.size()==0)
					{
						numValidsFoundInvalid++;
					}
				}
				else
				{
					numValidsFoundValid++;
				}

				if(result.size()>0) {
					foundValid = true;
					isCorrect = true;
				}
				else {
					foundValid = false;
					isCorrect = false;
				}
			}
			else if(predicted==0)
			{
				//conduct pessimistic search
				vector<int> result;
//				queryGraph->isIsomorphic_IterativePlanModification(graph, result, invalidPlan, 0, domainID, nodeID, numIterationBeforePlanChanges, NULL, true);
				queryGraph->isIsomorphic_IterativePlanModification(graph, result, invalidPlan, sigToPlan, 0, domainID, nodeID, numIterationBeforePlanChanges);

				if(result.size()>0) {
					foundValid = true;
					isCorrect = false;
//					validNodeIDs->push_back(nodeID);
//					Statistics::h_numValids++;
				}
				else {
					foundValid = false;
					isCorrect = true;
//					Statistics::h_numInvalids++;
				}

				/*if(foundValid==0)
				{
					if(showForDebug) cout<<" [CORRECT]"<<", ";
					Statistics::h_numCorrects++;
				}
				else if(foundValid==1)
				{
					if(showForDebug) cout<<" [INCORRECT]"<<", ";
					Statistics::h_numIncorrects++;
					int nID = graphNode->getID();
					nodeIDToDecision->find(sourceOfDecision)->second = -2;//foundValid;
				}*/
			}
			else if(predicted==-2)
			{
				cout<<"[H] Error540903: no prediction is found for this node"<<endl;
				exit(0);
			}
			else {
				cout<<"[H] Error54433: no prediction is found for this node"<<endl;
				exit(0);
			}

			gettimeofday(&tp, NULL);
			long int end = tp.tv_sec * 1000 + tp.tv_usec / 1000;

			//update the shared and global data
			updateMutex.lock();

			if(showForDebug)
				cout<<counter<<"/"<<(nodeIDToDecision->size())<<". Node: "<<nodeID<<"predicted = "<<predicted<<", decision source = "<<sourceOfDecision<<", node sig = "<<graphNode->getFeaturesKey()<<", numNeighbors = "<<graphNode->neighborsCount<<", ";
			else if(counter%100000==0 && counter!=0)
				cout<<"Actual: "<<counter<<"/"<<(nodeIDToDecision->size())<<endl;

			if(foundValid)
			{
				validNodeIDs->push_back(nodeID);
				Statistics::h_numValids++;
				if(showForDebug)
					cout<<"VALID"<<",";
			}
			else
			{
				Statistics::h_numInvalids++;
				if(showForDebug)
					cout<<"INVALID"<<",";
			}

			if(isCorrect)
			{
				Statistics::h_numCorrects++;
				if(showForDebug)
					cout<<"CORRECT, ";
			}
			else
			{
				Statistics::h_numIncorrects++;
				if(showForDebug)
					cout<<"INCORRECT, ";
			}

//			cout<<"predicted = "<<predicted<<", valid = "<<foundValid<<", correct = "<<isCorrect<<", ";

			if(showForDebug)
				cout<<graphNode->confidence<<", "<<(end-start)<<endl;

			updateMutex.unlock();

			if(!isCorrect) {
				iterMutex.lock();
				nodeIDToDecision->find(nodeID)->second = foundValid;
				iterMutex.unlock();
			}
		}

		delete[] validPlan;
		delete sigToPlan;
	}

	/**
	 * Do pivoted subgraph isomorphism using two threads; one for optimistic and the other for pessimistic
	 * */
	void doThreaded() {

//		TimeUtility::StartCounterMicro();

		this->nodeIDToDecision = nodeIDToDecision;

		//preparation
		int* invalidPlan = queryGraph->generateSelectBasedPlan(domainID, graph);

		int n = queryGraph->getNumOfNodes();
		plan1  = new int[n];
		plan2  = new int[n];
		for(int i=0;i<n;i++) {
			plan1[i] = invalidPlan[i];
			plan2[i] = invalidPlan[i];
		}

		//Create an asio::io_service and a thread_group (through pool in essence)
		boost::asio::io_service ioService;
		boost::thread_group threadpool;
		//This will start the ioService processing loop. All tasks assigned with ioService.post() will start executing.
		boost::asio::io_service::work work(ioService);

		/*
		 * This will add 2 threads to the thread pool. (You could just put it in a for loop)
		 */
		for(int i=0;i<2;i++) {
			threadpool.create_thread(
					boost::bind(&boost::asio::io_service::run, &ioService)
			);
		}

		nodesIter = nodeIDToDecision->begin();

		done1 = false;
		done2 = false;
		ioService.post(boost::bind(&DoDividedThreaded::processNodes_1, this));
		ioService.post(boost::bind(&DoDividedThreaded::processNodes_2, this));

		while(true) {
			if(done1 && done2) break;
			boost::this_thread::sleep(boost::posix_time::milliseconds(1));
		}

		//This will stop the ioService processing loop. Any tasks you add behind this point will not execute.
		ioService.stop();
		//wait for all tasks to finish
		threadpool.join_all();

		delete[] plan1;
		delete[] plan2;
		delete[] invalidPlan;
	}
};

class DoThreaded
{
private:
	GraphX* graph;
	GraphX* queryGraph;
	int domainID;
	int PnodeID;
	int OnodeID;
	tr1::unordered_set<int>* validNodes;
	tr1::unordered_set<int>* invalidNodes;
	int numIterationBeforePlanChanges;
	boost::thread* t_pessimistic;
	boost::thread* t_optimistic;
	int * pessimisticPlan;
	int * optimisticPlan;
	boost::mutex pessimisticDone;
	boost::mutex optimisticDone;
	boost::mutex addValidsMutex;
	boost::mutex addInvalidsMutex;
	tr1::unordered_map<string, int*>* sigToPlanPess;
	tr1::unordered_map<string, int*>* sigToPlanOpt;
//	int counter_mutex = 0;
//	boost::mutex cm;
	//bool pessimisticDone;
	//bool optimisticDone;

public:

	DoThreaded(GraphX* graph, GraphX* queryGraph, int domainID)
	{
		this->graph = graph;
		this->queryGraph = queryGraph;
		this->domainID = domainID;
		this->validNodes = new tr1::unordered_set<int>();
		this->invalidNodes = new tr1::unordered_set<int>();
		this->numIterationBeforePlanChanges = numIterationBeforePlanChanges;
		PnodeID = -1;
		OnodeID = -1;
		t_pessimistic = NULL;
		t_optimistic = NULL;
		pessimisticPlan = NULL;
		optimisticPlan = NULL;
//		pessimisticDone = false;
//		optimisticDone = false;
	}

	tr1::unordered_set<int>* getValidNodes() { return validNodes; }
	tr1::unordered_set<int>* getInvalidNodes() { return invalidNodes; }

	void doNothingP()
	{
		Statistics::interrupt = true;
		pessimisticDone.unlock();
	}

	void doNothingO()
	{
		Statistics::interrupt = true;
		optimisticDone.unlock();
	}

	void justLoop()
	{
		while(true)
		{
			if(Statistics::interrupt) break;
			boost::this_thread::sleep(boost::posix_time::microseconds(1));
		}
		Statistics::interrupt = true;

		pessimisticDone.unlock();
	}

	void runIsomorphismForThreadPessimistic(){
		vector<int> result;
//		bool b = queryGraph->isIsomorphic_IterativePlanModification(graph, result, pessimisticPlan, 0, domainID, PnodeID, numIterationBeforePlanChanges);
//		bool b = queryGraph->isIsomorphic_IterativePlanModification_2(graph, result, pessimisticPlan, 0, domainID, PnodeID, numIterationBeforePlanChanges, NULL, false, 2);
		bool b = queryGraph->isIsomorphic_IterativePlanModification(graph, result, pessimisticPlan, sigToPlanPess, 0, domainID, PnodeID, numIterationBeforePlanChanges);

//		int weights[queryGraph->getNumOfNodes()];
//		bool b = queryGraph->isIsomorphic_OneMatch_Fast_Pessimistic_2(graph, result, pessimisticPlan, domainID, PnodeID, numIterationBeforePlanChanges, NULL, NULL, weights);
//
//		if(!b) {
//			int* tempPlan = new int[queryGraph->getNumOfNodes()];
//			for(int i=0;i<queryGraph->getNumOfNodes();i++)
//				tempPlan[i] = pessimisticPlan[i];
//			queryGraph->isIsomorphic_IterativePlanModification_2(graph, result, tempPlan, 0, domainID, PnodeID, numIterationBeforePlanChanges, NULL, false, 2);
//			delete[] tempPlan;
//		}

		//if I completed my task, update the results lists
		if(result.size()>0) {
			addValidsMutex.lock();
			validNodes->insert(PnodeID);
			addValidsMutex.unlock();
		}
		if(b)
		{
//			cout<<"PISSIMISTIC"<<endl;
			if(result.size()>0) {
			}
			else {
				addInvalidsMutex.lock();
				invalidNodes->insert(PnodeID);
				addInvalidsMutex.unlock();
			}
		}

//		if(OnodeID==2257) {
//			cout<<"P-BINGO!"<<endl<<flush;
//			exit(0);
//		}

		PnodeID = -1;
		Statistics::interrupt = true;

//		double elapsed = TimeUtility::GetCounterMicro();
//		Statistics::threadedTime+=elapsed;
//		TimeUtility::StartCounterMicro();

		pessimisticDone.unlock();
	}

	void runIsomorphismForThreadOptimistic(){

		//remove me
//		while(true)
//		{
//			if(Statistics::interrupt)
//				{
//					optimisticDone.unlock();
//					return;
//				}
//			cout<<Statistics::interrupt<<endl;
//		}

		int maxToVisit = 10;

		vector<int> result;

		queryGraph->isIsomorphic_OneMatch_Fast_Super_Optimistic(graph, result, optimisticPlan, domainID, OnodeID, maxToVisit);
#if allowThreaded
	if(Statistics::interrupt)
	{
//		double elapsed = TimeUtility::GetCounterMicro();
//		Statistics::threadedTime+=elapsed;
//		TimeUtility::StartCounterMicro();

		optimisticDone.unlock();
		return;
	}
#endif
		if(result.size()==0)
			queryGraph->isIsomorphic_OneMatch_Fast_Super_Optimistic(graph, result, optimisticPlan, domainID, OnodeID, maxToVisit, NULL, true);
#if allowThreaded
	if(Statistics::interrupt)
	{
//		double elapsed = TimeUtility::GetCounterMicro();
//		Statistics::threadedTime+=elapsed;
//		TimeUtility::StartCounterMicro();

		optimisticDone.unlock();
		return;
	}
#endif
		bool b = true;
		if(result.size()==0) {
//			b = queryGraph->isIsomorphic_IterativePlanModification(graph, result, optimisticPlan, 1, domainID, OnodeID, numIterationBeforePlanChanges);
//			b = queryGraph->isIsomorphic_OneMatch_Fast_Optimistic( graph, result, optimisticPlan, domainID, OnodeID, numIterationBeforePlanChanges);
			b = queryGraph->isIsomorphic_IterativePlanModification(graph, result, optimisticPlan, sigToPlanOpt, 1, domainID, OnodeID, numIterationBeforePlanChanges);

//			if(!b) {
//				int* tempPlan = new int[queryGraph->getNumOfNodes()];
//				for(int i=0;i<queryGraph->getNumOfNodes();i++)
//					tempPlan[i] = optimisticPlan[i];
//				queryGraph->isIsomorphic_IterativePlanModification(graph, result, tempPlan, 1, domainID, OnodeID, numIterationBeforePlanChanges);
//				delete[] tempPlan;
//			}
		}

		if(result.size()>0) {
			addValidsMutex.lock();
			validNodes->insert(OnodeID);
			addValidsMutex.unlock();
		}
		if(b) {
			if(result.size()>0) {
			}
			else{
				if(!Statistics::interrupt)
				{
					addInvalidsMutex.lock();
					invalidNodes->insert(OnodeID);
					addInvalidsMutex.unlock();
				}
			}
		}

//		if(OnodeID==2257) {
//			cout<<"O-BINGO!"<<endl<<flush;
//			exit(0);
//		}

		OnodeID = -1;
		Statistics::interrupt = true;

//		double elapsed = TimeUtility::GetCounterMicro();
//		Statistics::threadedTime+=elapsed;
//		TimeUtility::StartCounterMicro();

//		cout<<"[O"<<flush;
		optimisticDone.unlock();
//		cout<<"[O]"<<endl<<flush;

	}

	/**
	 * Do pivoted subgraph isomorphism using two threads; one for optimistic and the other for pessimistic
	 * */
	void doThreaded(set<int>* nodesList, bool realThreaded) {
//		cout<<"This object = "<<this<<endl<<flush;

//		if(realThreaded)
//			TimeUtility::StartCounterMicro();

		//preparation
		int* invalidPlan = queryGraph->generateSelectBasedPlan(domainID, graph);
//		int* invalidPlan = selectGoodPlan(queryGraph, graph, domainID);
		cout<<"To be used plan: ";
		for(int i=0;i<queryGraph->getNumOfNodes();i++)
			cout<<invalidPlan[i]<<",";
		cout<<endl;


		if(nodesList==NULL)
			nodesList = graph->getNodeIDsByLabel(queryGraph->getNodeWithID(domainID)->getLabel());
		numIterationBeforePlanChanges = queryGraph->getNumOfNodes()*10000;

		int n = queryGraph->getNumOfNodes();
		optimisticPlan  = new int[n];
		pessimisticPlan  = new int[n];
		for(int i=0;i<n;i++) {
			optimisticPlan[i] = invalidPlan[i];
			pessimisticPlan[i] = invalidPlan[i];
		}

		//Create an asio::io_service and a thread_group (through pool in essence)
		boost::asio::io_service ioService;
		boost::thread_group threadpool;
		//This will start the ioService processing loop. All tasks assigned with ioService.post() will start executing.
		boost::asio::io_service::work work(ioService);

		/*
		 * This will add 2 threads to the thread pool. (You could just put it in a for loop)
		 */
		for(int i=0;i<2;i++) {
			threadpool.create_thread(
					boost::bind(&boost::asio::io_service::run, &ioService)
			);
		}

		int counter = 0;

//		if(realThreaded) {
//			double elapsed = TimeUtility::GetCounterMicro();
//			Statistics::threadedTime+=elapsed;
//		}

//		if(realThreaded)
//			TimeUtility::StartCounterMicro();

		sigToPlanPess = new tr1::unordered_map<string, int*>();
		sigToPlanOpt = new tr1::unordered_map<string, int*>();

		for(set<int>::iterator iter = nodesList->begin();iter!=nodesList->end();iter++) {

			pessimisticDone.lock();
			optimisticDone.lock();

//			double elapsed;
//			if(realThreaded)
//			{
//				double elapsed = TimeUtility::GetCounterMicro();
//				Statistics::threadedTime+=elapsed;
//
//				TimeUtility::StartCounterMicro();
//			}

			if(counter%100000==0 && counter!=0)
				cout<<counter<<"/"<<nodesList->size()<<endl;
			counter++;

//			cout<<"NodeID = "<<(*iter)<<endl;

			vector<int> result;

			PnodeID = (*iter);
			OnodeID = (*iter);

//			if(showForDebug)
//			{
//				if(realThreaded)
//					cout<<"R";
//				cout<<"node: "<<PnodeID<<" time = "<<elapsed<<endl;
//			}

			Statistics::interrupt = false;

			ioService.post(boost::bind(&DoThreaded::runIsomorphismForThreadPessimistic, this));
			ioService.post(boost::bind(&DoThreaded::runIsomorphismForThreadOptimistic, this));

//			ioService.post(boost::bind(&DoThreaded::runIsomorphismForThreadPessimistic_RRR, this));

//			ioService.post(boost::bind(&DoThreaded::doNothingP, this));
//			ioService.post(boost::bind(&DoThreaded::justLoop, this));
		}

		if(realThreaded)
		{
			Statistics::numValids_threaded = validNodes->size();
			Statistics::numInvalids_threaded = invalidNodes->size();
		}

		//needed to fix the mutex problem
		pessimisticDone.lock();
		optimisticDone.lock();
		pessimisticDone.unlock();
		optimisticDone.unlock();

//		if(realThreaded)
//		{
//			double elapsed = TimeUtility::GetCounterMicro();
//			Statistics::threadedTime+=elapsed;
//
//			TimeUtility::StartCounterMicro();
//		}


		/*cout<<counter_mutex<<endl;
		while(true) {
			if(counter_mutex==0)
				break;
//			cout<<counter_mutex<<endl;
		}*/

//		boost::this_thread::sleep(boost::posix_time::microseconds(10));

//		cout<<"LLLL1"<<endl<<flush;

		//This will stop the ioService processing loop. Any tasks you add behind this point will not execute.
		ioService.stop();
		//wait for all tasks to finish
		threadpool.join_all();

//		cout<<"LLLL2"<<endl<<flush;

		/*
		 * Will wait till all the threads in the thread pool are finished with
		 * their assigned tasks and 'join' them. Just assume the threads inside
		 * the threadpool will be destroyed by this method.
		 */

		/*
		//initialize the threads
		PnodeID = -1;
		OnodeID = -1;
		boost::thread t1;
		boost::thread t2;
		t_pessimistic = &t1;
		t_optimistic = &t2;

		t1 = boost::thread(boost::bind(&DoThreaded::runIsomorphismForThreadPessimistic, this));
		t2 = boost::thread(boost::bind(&DoThreaded::runIsomorphismForThreadOptimistic, this));

//		boost::this_thread::sleep(boost::posix_time::milliseconds(2000));

		int counter = 0;
		int maxToVisit = 10;

		for(set<int>::iterator iter = nodesList->begin();iter!=nodesList->end();iter++) {
			if(counter%100000==0) cout<<counter<<"/"<<nodesList->size()<<endl;
			counter++;

			vector<int> result;

			PnodeID = (*iter);
			OnodeID = (*iter);
			cout<<"NodeID = "<<PnodeID<<": "<<flush;
//			cout<<"PNodeID "<<PnodeID<<": "<<flush;
//			cout<<"ONodeID "<<OnodeID<<": "<<flush;

//			t_pessimistic->join();
//			cout<<"PESS_joined."<<flush;
//			t_optimistic->join();
//			cout<<"OPTI_joined."<<flush;

			Statistics::interrupt = false;

			//allows threads to get nodeIDs
			PnodeIDAvail.unlock();
			OnodeIDAvail.unlock();

			//wait for thread to finish
			optimisticDone.lock();
			pessimisticDone.lock();

			optimisticDone.unlock();
			pessimisticDone.unlock();

//			cout<<endl;

			//the exact result
			int valid = 0;
			if(result.size()>0) {
				valid = 1;
				Statistics::trueValids++;
			}
			else {
				Statistics::trueInvalids++;
			}

			if(idToValidity!=NULL) {
				idToValidity->insert(std::pair<int, int>((*iter), valid));
			}
		}*/

//		PnodeID = -2;
//		OnodeID = -2;

//		t_pessimistic->join();
//		t_optimistic->join();

		Statistics::interrupt = false;

		delete[] optimisticPlan;
		delete[] pessimisticPlan;
		delete[] invalidPlan;
		delete sigToPlanPess;
		delete sigToPlanOpt;

//		if(realThreaded)
//		{
//			double elapsed = TimeUtility::GetCounterMicro();
//			Statistics::threadedTime+=elapsed;
//		}
	}
};

/**
 * Two phases technique;
 * First phase runs the two algorithms; pessimistic and optimistic, then it flags each node with the best in time
 * Second phase runs one of the codes based on the flag corresponding to each node
 * graph: input graph
 * queryGraph: the query as a graph
 * domainID: fixed domain id
 * type: 0: pessimistic, 1: optimistic
 */
void doBest(GraphX* graph, GraphX* queryGraph, int domainID, tr1::unordered_map<int, int>* idToValidity, bool showValids, bool bestInTime) {

	cout<<"BEST "<<" Querying initiated ..."<<endl;

	tr1::unordered_map<int, int> nodeToFunction;

	tr1::unordered_map<string, int*>* sigToPlan = new tr1::unordered_map<string, int*>();

	for(int iteration = 0;iteration<2;iteration++) {
		cout<<"Iteration#"<<iteration<<endl;
		//preparation
		int* planO = queryGraph->generateSelectBasedPlan(domainID, graph);
		int* planP = queryGraph->generateSelectBasedPlan(domainID, graph);
		set<int>* nodesList = graph->getNodeIDsByLabel(queryGraph->getNodeWithID(domainID)->getLabel());
		long numIterationBeforePlanChanges = queryGraph->getNumOfNodes()*10000;

		int counter = 0;
		int maxToVisit = 10;

		vector<int> validNodeIDs;

		for(set<int>::iterator iter = nodesList->begin();iter!=nodesList->end();iter++) {
			if(counter%100000==0) cout<<counter<<"/"<<nodesList->size()<<endl;
			counter++;
	//		if(counter!=3) continue;
			vector<int> result;

			if(iteration==0) {
				double pessimisticTime = 0;
				double optimisticTime = 0;

				//do optimistic
				TimeUtility::StartCounterMicro();
				queryGraph->isIsomorphic_OneMatch_Fast_Super_Optimistic(graph, result, planO, domainID, (*iter), maxToVisit);
				if(result.size()==0)
					queryGraph->isIsomorphic_OneMatch_Fast_Super_Optimistic(graph, result, planO, domainID, (*iter), maxToVisit, NULL, true);
	//			if(result.size()==0)
	//				queryGraph->isIsomorphic_OneMatch_Fast_Super_Optimistic(graph, result, plan, domainID, (*iter), maxToVisit);
				if(result.size()==0)
					queryGraph->isIsomorphic_IterativePlanModification(graph, result, planO, 1, domainID, (*iter), numIterationBeforePlanChanges);
				optimisticTime = TimeUtility::GetCounterMicro();

				result.clear();

				//do pessimistic
				TimeUtility::StartCounterMicro();
				queryGraph->isIsomorphic_IterativePlanModification(graph, result, planP, 0, domainID, (*iter), numIterationBeforePlanChanges);
				pessimisticTime = TimeUtility::GetCounterMicro();

				if(bestInTime) {
					if(pessimisticTime<optimisticTime)
						nodeToFunction.insert(std::pair<int, int>((*iter), 0));
					else
						nodeToFunction.insert(std::pair<int, int>((*iter), 1));
				}
				else
				{
					if(result.size()==0)
						nodeToFunction.insert(std::pair<int, int>((*iter), 0));
					else
						nodeToFunction.insert(std::pair<int, int>((*iter), 1));
				}
			}
			else
			{
				int decision = nodeToFunction.find((*iter))->second;
				TimeUtility::StartCounterMicro();
				if(decision==0) {
//					queryGraph->isIsomorphic_IterativePlanModification(graph, result, planP, 0, domainID, (*iter), numIterationBeforePlanChanges);
					queryGraph->isIsomorphic_IterativePlanModification(graph, result, planP, sigToPlan, 0, domainID, (*iter), numIterationBeforePlanChanges);
				}
				else
				{
					queryGraph->isIsomorphic_OneMatch_Fast_Super_Optimistic(graph, result, planO, domainID, (*iter), maxToVisit);
					if(result.size()==0)
						queryGraph->isIsomorphic_OneMatch_Fast_Super_Optimistic(graph, result, planO, domainID, (*iter), maxToVisit, NULL, true);
		//			if(result.size()==0)
		//				queryGraph->isIsomorphic_OneMatch_Fast_Super_Optimistic(graph, result, planO, domainID, (*iter), maxToVisit);
//					if(result.size()==0)
//						queryGraph->isIsomorphic_IterativePlanModification(graph, result, planO, 1, domainID, (*iter), numIterationBeforePlanChanges);
					if(result.size()==0)
						queryGraph->isIsomorphic_IterativePlanModification(graph, result, planO, sigToPlan, 1, domainID, (*iter), numIterationBeforePlanChanges);

//					//the exact result
//					int valid = 0;
//					if(result.size()>0) {
//						valid = 1;
//						Statistics::trueValids++;
//						validNodeIDs.push_back(*iter);
//					}
//					else {
//						Statistics::trueInvalids++;
//					}
//
//					if(idToValidity!=NULL) {
//						idToValidity->insert(std::pair<int, int>((*iter), valid));
//					}
				}

				if(bestInTime)
					Statistics::best_timeTime+=TimeUtility::GetCounterMicro();
				else
					Statistics::best_desisionTime+=TimeUtility::GetCounterMicro();
			}
		}

//		if(showValids) {
//			cout<<"the list of valid node IDs:"<<endl;
//			for(vector<int>::iterator iter = validNodeIDs.begin();iter!=validNodeIDs.end();iter++) {
//				cout<<*iter<<endl;
//			}
//		}

		delete[] planP;
		delete[] planO;
	}
}

/**
 * Do isomorphism defaulting to one of the functions: optimistic or pessimistic
 * graph: input graph
 * queryGraph: the query as a graph
 * domainID: fixed domain id
 * type: 0: pessimistic, 1: optimistic
 */
void doDefault(GraphX* graph, GraphX* queryGraph, int domainID, int type, tr1::unordered_map<int, int>* idToValidity, bool showValids) {

	string task = "UNKNOWN";
	if(type==0)  task = "PESSIMISTIC";
	if(type==1)  task = "OPTIMISTIC";
	cout<<"DEFAULT "<<task<<" Querying initiated ..."<<endl;

	//preparation
	//int* validPlan = queryGraph->generateTreeFirstPlan(domainID, graph);
	int* invalidPlan = queryGraph->generateSelectBasedPlan(domainID, graph);
//	int* invalidPlan = selectGoodPlan(queryGraph, graph, domainID);
	set<int>* nodesList = graph->getNodeIDsByLabel(queryGraph->getNodeWithID(domainID)->getLabel());
	long numIterationBeforePlanChanges = queryGraph->getNumOfNodes()*10000;

	int * plan  = invalidPlan;

//	if(type==0) {
//		plan = invalidPlan;
//		delete[] validPlan;
//		validPlan = NULL;
//	}
//	else {
//		plan = invalidPlan;
//		delete[] validPlan;
//		validPlan = NULL;
//	}

	int counter = 0;
	int maxToVisit = 10;

	vector<int> validNodeIDs;

	tr1::unordered_map<string, int*>* sigToPlan = new tr1::unordered_map<string, int*>();

	for(set<int>::iterator iter = nodesList->begin();iter!=nodesList->end();iter++) {
//		cout<<graph->getNodeWithID((*iter))->getFeaturesKey()<<endl;
		if(counter%100000==0) cout<<counter<<"/"<<nodesList->size()<<endl;
		counter++;
//		if(counter!=3) continue;
		vector<int> result;

//		for(int i=0;i<queryGraph->getNumOfNodes();i++)
//			cout<<validPlan[i]<<",";
//		cout<<endl;
//		for(int i=0;i<queryGraph->getNumOfNodes();i++)
//			cout<<invalidPlan[i]<<",";
//		cout<<endl;

//		cout<<"For node: "<<(*iter)<<"plan is:";
//		for(int i=0;i<queryGraph->getNumOfNodes();i++)
//			cout<<invalidPlan[i]<<",";
//		cout<<endl;

		if(type==1) {
			queryGraph->isIsomorphic_OneMatch_Fast_Super_Optimistic(graph, result, plan, domainID, (*iter), maxToVisit);
			if(result.size()==0)
				queryGraph->isIsomorphic_OneMatch_Fast_Super_Optimistic(graph, result, plan, domainID, (*iter), maxToVisit, NULL, true);
//			if(result.size()==0)
//				queryGraph->isIsomorphic_OneMatch_Fast_Super_Optimistic(graph, result, plan, domainID, (*iter), maxToVisit);
			if(result.size()==0) {
				queryGraph->isIsomorphic_IterativePlanModification(graph, result, plan, sigToPlan, 1, domainID, (*iter), numIterationBeforePlanChanges);
//				queryGraph->isIsomorphic_IterativePlanModification(graph, result, plan, type, domainID, (*iter), numIterationBeforePlanChanges);
				if(result.size()>0)
					Statistics::opt_validFoundInvalid++;
			}

			if(result.size()==0) {
				Statistics::opt_numInvalids++;
			}
			else {
				Statistics::opt_numValids++;
			}

		}
		else
		{
			//queryGraph->isIsomorphic_IterativePlanModification(graph, result, plan, type, domainID, (*iter), numIterationBeforePlanChanges);
			queryGraph->isIsomorphic_IterativePlanModification(graph, result, plan, sigToPlan, 0, domainID, (*iter), numIterationBeforePlanChanges);

//			int weights[queryGraph->getNumOfNodes()];
//			bool b = queryGraph->isIsomorphic_OneMatch_Fast_Pessimistic_2(graph, result, invalidPlan, domainID, *iter, numIterationBeforePlanChanges, NULL, NULL, weights);
//			if(!b) {
//				int* tempPlan = new int[queryGraph->getNumOfNodes()];
//				for(int i=0;i<queryGraph->getNumOfNodes();i++)
//					tempPlan[i] = invalidPlan[i];
//				queryGraph->isIsomorphic_IterativePlanModification_2(graph, result, tempPlan, 0, domainID, *iter, numIterationBeforePlanChanges, NULL, false, 2);
//				delete[] tempPlan;
//			}
		}

		//the exact result
		int valid = 0;
		if(result.size()>0) {
			valid = 1;
			Statistics::trueValids++;
//			cout<<"VALID"<<endl;
			validNodeIDs.push_back(*iter);
		}
		else {
			Statistics::trueInvalids++;
//			cout<<"INVALID"<<endl;
		}

		if(idToValidity!=NULL) {
			idToValidity->insert(std::pair<int, int>((*iter), valid));
		}
	}

	if(showValids) {
		cout<<"the list of valid node IDs:"<<endl;
		for(vector<int>::iterator iter = validNodeIDs.begin();iter!=validNodeIDs.end();iter++) {
			cout<<*iter<<endl;
		}
	}

	delete plan;
	delete sigToPlan;
}

/**
 * threadedType refers to whether: 1- use ML to predict the type, 2- always optimistic, 3- always pessimistic
 */
void doQuery_2threads(GraphX* graph, GraphX* queryGraph, int domainID, tr1::unordered_map<int, int>* idToValidity, bool showValids) {
	cout<<"DoQuery (2 threads) initiated ..."<<endl;

	TimeUtility::StartCounterMicro();

	double percentage = 0.1;//the percentage of nodes to use for training

	int* invalidPlan = queryGraph->generateSelectBasedPlan(domainID, graph);
	cout<<"To be used plan: ";
	for(int i=0;i<queryGraph->getNumOfNodes();i++) {
		cout<<invalidPlan[i]<<",";
	}
	cout<<endl;

	long elapsed = TimeUtility::GetCounterMicro();
	Statistics::h_predictionPreparationTime+=elapsed;
//	cout<<"Plans generation time = "<<elapsed<<endl;

	TimeUtility::StartCounterMicro();

	if(invalidPlan==NULL) {
		return;
	}

	//generate candidate nodes
	set<int>* nodesList = graph->getNodeIDsByLabel(queryGraph->getNodeWithID(domainID)->getLabel());

	double maxNumTrainNodes = 1000.0;

	if(nodesList->size()*percentage>maxNumTrainNodes)
		percentage = maxNumTrainNodes/nodesList->size();

	//select the list of nodes to use for training
	srand(time(NULL));
	set<int> trainingNodeIDs;
	for(set<int>::iterator tempIter = nodesList->begin();tempIter!=nodesList->end();tempIter++)
	{
		int r = rand() % 1000000;
		if(r<percentage*1000000) {
//			trainingNodeIDs.insert(*tempIter);
			double v = ((Features*)queryGraph->getNodeWithID(domainID)->getFeatures())->avgDifference(((Features*)graph->getNodeWithID(*tempIter)->getFeatures()));
			if(v>-1)
				trainingNodeIDs.insert(*tempIter);
		}
	}

	bool donotTrain = false;
	if(trainingNodeIDs.size()<10) {
		cout<<"No enough instances to train ... training is skipped!"<<endl;
		donotTrain = true;
		trainingNodeIDs.clear();
	}
	else
		cout<<trainingNodeIDs.size()<<"/"<<nodesList->size()<<" selected for training."<<endl;

	NodeX* queryNode = queryGraph->getNodeWithID(domainID);
	Features* queryNodeFeatures = (Features*)queryNode->getFeatures();

	tr1::unordered_set<int> featuresNames;

	vector<NodeX* > trainingFS;//containing training nodes

	RFClassifier model;
	Normalizer<RealVector> normalizer;

	bool alwaysValid = true;
	bool alwaysInvalid = true;

	int nTrainValidNodes = 0;
	int nTrainInvalidNodes = 0;

	Statistics::h_trainingTime+=TimeUtility::GetCounterMicro();

	tr1::unordered_map<string, NodeX*> visitedNodeSig;
	tr1::unordered_map<int, int> nodeIDToDecision;

	vector<int> validNodeIDs;

	//training step
	if(!donotTrain) {
		TimeUtility::StartCounterMicro();

		tr1::unordered_map<int, int> nodeToValidity;

		//do training using two threads
		DoThreaded dt(graph, queryGraph, domainID);
		dt.doThreaded(&trainingNodeIDs, false);

		tr1::unordered_set<int>* validTrainingNodes = dt.getValidNodes();
//		cout<<"validTrainingNodes->size() = "<<validTrainingNodes->size()<<endl;

		for(set<int>::iterator iter = trainingNodeIDs.begin();iter!=trainingNodeIDs.end();iter++)
		{
			NodeX* graphNode = graph->getNodeWithID((*iter));
			Features* graphNodeFeatures = (Features*)graphNode->getFeatures();

			graphNodeFeatures->addToFeaturesNames(featuresNames);

			//assign outcome
			int valid = 0;

			if(validTrainingNodes->find((*iter))!=validTrainingNodes->end())
				valid = 1;

			if(valid)
			{
				nTrainValidNodes++;
				alwaysInvalid = false;
				validNodeIDs.push_back(*iter);
				Statistics::h_numValids++;
			}
			else
			{
				nTrainInvalidNodes++;
				alwaysValid = false;
				Statistics::h_numInvalids++;
			}

			nodeToValidity.insert(std::pair<int, int>((*iter), valid));

			trainingFS.push_back(graphNode);

			//add this node to the list of visited so that it can be used for other nodes
			string featuresKey = graphNode->getFeaturesKey();
			tr1::unordered_map<string, NodeX*>::iterator tempIter = visitedNodeSig.find(featuresKey);
			if(tempIter!=visitedNodeSig.end()) {
			} else {
				visitedNodeSig.insert(std::pair<string, NodeX*>(featuresKey, graphNode));
			}

			nodeIDToDecision.insert(std::pair<int, int>((*iter), valid));
		}

		//balance the classes
		bool balance = true;
		if(balance && !alwaysValid && !alwaysInvalid)
		{
			int a = -1;//-1 data is balanced, 0- biased to invalid, 1- biased to valid
			if((nTrainValidNodes/((double)nTrainValidNodes+nTrainInvalidNodes))<0.4)
				a = 0;
			else if((nTrainInvalidNodes/((double)nTrainValidNodes+nTrainInvalidNodes))<0.4)
				a = 1;

			while(a!=-1) {
				int r = rand()%trainingFS.size();
				NodeX* node = trainingFS[r];
				double valid = nodeToValidity.find(node->getID())->second;
				if(a==0 && valid==0) {
					trainingFS.erase(trainingFS.begin()+r);
					nTrainInvalidNodes--;
					if((nTrainValidNodes/((double)nTrainValidNodes+nTrainInvalidNodes))>=0.4)
						a = -1;
				}
				else if(a==1 && valid==1) {
					trainingFS.erase(trainingFS.begin()+r);
					nTrainValidNodes--;
					if((nTrainInvalidNodes/((double)nTrainValidNodes+nTrainInvalidNodes))>=0.4)
						a = -1;
				}
			}
		}

		//build the model using the collected training data
		if(!alwaysValid && !alwaysInvalid) {
			std::vector<RealVector> inputs;
			std::vector<unsigned int> labels;

			for(vector<NodeX* >::iterator iter = trainingFS.begin();iter!=trainingFS.end();iter++) {
				NodeX* node = (*iter);
				Features* tempFS = (Features*) node->getFeatures();

				RealVector input;

				for(tr1::unordered_set<int>::iterator iter1 = featuresNames.begin();iter1!=featuresNames.end();iter1++) {
					int name = (*iter1);

					Feature* tempF = tempFS->getFeature(name);
					if(tempF==NULL)
						input.push_back(0);
					else
						input.push_back(tempF->getValue());
				}

				inputs.push_back(input);

				labels.push_back((unsigned int)nodeToValidity.find(node->getID())->second);
			}

			ClassificationDataset dataset = createLabeledDataFromRange(inputs, labels);

			//normalization
	//		bool removeMean = true;
	//		NormalizeComponentsUnitVariance<RealVector> normalizingTrainer(removeMean);
	//		normalizingTrainer.train(normalizer, dataset.inputs());
	//		LabeledData<RealVector, unsigned int> normalizedData = transformInputs(dataset, normalizer);

			RFTrainer trainer;
	//		trainer.train(model, normalizedData);
			trainer.train(model, dataset);

			cout<<"training done using "<<trainingFS.size()<<" instances."<<endl;
		}
		else
		{
			cout<<"No training since either alwaysvalid or alwaysinvalid"<<endl;
		}

		Statistics::h_trainingTime+=TimeUtility::GetCounterMicro();
	}
	else {
		//since no training, set all predictions to invalid
		alwaysInvalid = true;
		alwaysValid = false;
	}

//	cout<<"nTrainNodes = "<<nTrainNodes<<endl;
//	cout<<"nTrainValidNodes = "<<nTrainValidNodes<<endl;
//	cout<<"nTrainInvalidNodes = "<<nTrainInvalidNodes<<endl;
	/////////////////////////////////////////////

	//start the testing phase; using the model to predict for next nodes

	TimeUtility::StartCounterMicro();
	//nodes visited earlier
	vector<int> toBePredictedNodes;

	for(set<int>::iterator iter = nodesList->begin();iter!=nodesList->end();iter++)
	{
		int predicted = -1;
		int id = (*iter);

		//this node has been already checked (in the training phase)
		if(trainingNodeIDs.find(id)!=trainingNodeIDs.end())
			continue;

		//if all training resulted in one of either decisions
		if(alwaysValid) {
			nodeIDToDecision.insert(std::pair<int, int>((*iter), 1));
			continue;
		}
		else if(alwaysInvalid) {
			nodeIDToDecision.insert(std::pair<int, int>((*iter), 0));
			continue;
		}

		//check if a similar node was visited before
		NodeX* node = graph->getNodeWithID(id);
		string featuresKey = node->getFeaturesKey();
		tr1::unordered_map<string, NodeX*>::iterator tempIter = visitedNodeSig.find(featuresKey);
		if(tempIter!=visitedNodeSig.end()) {
			predicted = tempIter->second->getID()+2;
			Statistics::h_nmCached++;
			node->confidence = -1;
		} else {
			visitedNodeSig.insert(std::pair<string, NodeX*>(featuresKey, node));
		}

		nodeIDToDecision.insert(std::pair<int, int>(id,predicted));
		if(predicted==-1) {
			toBePredictedNodes.push_back(id);
		}
	}

	//do the predictions
	std::vector<RealVector> inputs;
	for(vector<int>::iterator iter = toBePredictedNodes.begin();iter!=toBePredictedNodes.end();iter++) {
		int nodeID = *iter;
		NodeX* graphNode = graph->getNodeWithID(nodeID);
		Features* graphNodeFeatures = (Features*)graphNode->getFeatures();

		RealVector input;
		for(tr1::unordered_set<int>::iterator iter1 = featuresNames.begin();iter1!=featuresNames.end();iter1++) {

			Feature* tempF;

			if(graphNodeFeatures->getFeatuesSize()<6)
				tempF = graphNodeFeatures->getFeature_Sequential((*iter1));
			else
				tempF = graphNodeFeatures->getFeature((*iter1));

			if(tempF==NULL)
				input.push_back(0);
			else
				input.push_back(tempF->getValue());
		}

		inputs.push_back(input);
	}

	elapsed = TimeUtility::GetCounterMicro();
	Statistics::h_predictionPreparationTime+=elapsed;
	if(showForDebug)
		cout<<"Statistics::h_predictionPreparationTime: "<<elapsed<<endl;

	//employ the model to get predictions
	TimeUtility::StartCounterMicro();
	Data<RealVector> predictions;
	if(toBePredictedNodes.size()>0) {
		UnlabeledData<RealVector> dataset = createUnlabeledDataFromRange(inputs);
		predictions = model(dataset.inputs());
	}
	Statistics::h_predictionTime+=TimeUtility::GetCounterMicro();

	TimeUtility::StartCounterMicro();

	//assign predictions
	Data<RealVector>::element_range::iterator pos = predictions.elements().begin();

	for(vector<int>::iterator iter = toBePredictedNodes.begin();iter!=toBePredictedNodes.end();iter++)
	{
		int nodeID = *iter;
		int prediction = -1;

		if(showForDebug) {
			cout<<nodeID<<" prediction value: ("<<(*pos)[0]<<", "<<(*pos)[1]<<")"<<endl;
		}
		if((*pos)[0]>(*pos)[1])
			prediction = 0;
		else
			prediction = 1;

		nodeIDToDecision.erase(nodeID);

		double confidence = abs(((*pos)[0])-((*pos)[1]));
		if(confidence == 0)
			confidence = 0.001;

//		double diff = queryNodeFeatures->avgDifference(((Features*)graph->getNodeWithID(nodeID)->getFeatures()));
//		double diff = queryNodeFeatures->maxSatisfyingDifference(((Features*)graph->getNodeWithID(nodeID)->getFeatures()));
		NodeX* node = graph->getNodeWithID(nodeID);
		double diff = node->neighborsCount;

		node->confidence = confidence;
		nodeIDToDecision.insert(std::pair<int, int>(nodeID, prediction));

		++pos;
	}

	toBePredictedNodes.clear();
	elapsed = TimeUtility::GetCounterMicro();
	Statistics::h_predictionPreparationTime+=elapsed;

	if(showForDebug)
		cout<<"Statistics::h_predictionPreparationTime: "<<elapsed<<endl;

	//cout<<"Time for 2-threaded is: "<<elapsed<<endl;

	TimeUtility::StartCounterMicro();

	//do the 2 threaded nodes
	cout<<"Do ML-threaded"<<endl;
	DoDividedThreaded ddt(graph, queryGraph, domainID);
	ddt.setValues(&trainingNodeIDs, &nodeIDToDecision, &validNodeIDs, NULL);
	ddt.doThreaded();
//	Statistics::h_nmMLDecided = nodeIDToDecision.size() - threadedNodes.size() - trainingNodeIDs.size();

	if(showValids) {
		cout<<"the list of valid node IDs:"<<endl;
		for(vector<int>::iterator iter = validNodeIDs.begin();iter!=validNodeIDs.end();iter++) {
			cout<<*iter<<endl;
		}
	}

	delete[] invalidPlan;

	elapsed = TimeUtility::GetCounterMicro();
	Statistics::h_optimizedSubIsoTime+=elapsed;

}

void doQuery(GraphX* graph, GraphX* queryGraph, int domainID, tr1::unordered_map<int, int>* idToValidity, bool showValids) {

	int modelType;
	modelType = 1;//model type; 1- Randomforest, 2- KNN, 3- SVM, 4- NN

	cout<<"Querying initiated ..."<<endl;

	TimeUtility::StartCounterMicro();

	double percentage = 0.1;//the percentage of nodes to use for training

//	int* validPlan = queryGraph->generateTreeFirstPlan(domainID, graph);
	int* invalidPlan = queryGraph->generateSelectBasedPlan(domainID, graph);
	int* validPlan = new int[queryGraph->getNumOfNodes()];

//	int* invalidPlan = selectGoodPlan(queryGraph, graph, domainID);
	cout<<"To be used plan: ";
	for(int i=0;i<queryGraph->getNumOfNodes();i++)
		cout<<invalidPlan[i]<<",";
	cout<<endl;

	long elapsed = TimeUtility::GetCounterMicro();
	Statistics::predictionPreparationTime+=elapsed;
	cout<<"Plans generation time = "<<elapsed<<endl;

	TimeUtility::StartCounterMicro();

//	int invalidPlan[] = {0,3,5,8,6,7,9,1,2,4};

//	cout<<"InvalidPlan: ";
//	for(int i=0;i<queryGraph->getNumOfNodes();i++)
//		cout<<invalidPlan[i]<<",";
//	cout<<endl;
//	if(true) return;

	if(invalidPlan==NULL) {
//		cout<<"Early no results"<<endl;
		return;
	}

	//generate candidate nodes
	set<int>* nodesList = graph->getNodeIDsByLabel(queryGraph->getNodeWithID(domainID)->getLabel());

	double maxNumTrainNodes = 1000.0;

	if(nodesList->size()*percentage>maxNumTrainNodes)
		percentage = maxNumTrainNodes/nodesList->size();

	//select the list of nodes to use for training
	srand(time(NULL));
	tr1::unordered_set<int> trainingNodeIDs;
	for(set<int>::iterator tempIter = nodesList->begin();tempIter!=nodesList->end();tempIter++)
	{
		int r = rand() % 1000000;
		if(r<percentage*1000000)
			trainingNodeIDs.insert(*tempIter);
	}

	bool donotTrain = false;
	if(trainingNodeIDs.size()<10) {
		cout<<"No enough instances to train ... training is skipped!"<<endl;
		donotTrain = true;
		trainingNodeIDs.clear();
	}
	else
		cout<<trainingNodeIDs.size()<<"/"<<nodesList->size()<<" selected for training."<<endl;

	NodeX* queryNode = queryGraph->getNodeWithID(domainID);
	Features* queryNodeFeatures = (Features*)queryNode->getFeatures();

	tr1::unordered_set<int> featuresNames;

	vector<NodeX* > trainingFS;//containing training nodes

	//Radom forest model
	RFClassifier model;
	Normalizer<RealVector> normalizer;

	//KNN model
	NearestNeighborClassifier<RealVector>* KNN;

	//SVM classifier
	double gamma = 0.5;         // kernel bandwidth parameter
	GaussianRbfKernel<> kernel(gamma); // Gaussian kernel
	double C = 1000.0;          // regularization parameter
	bool bias = true;           // use bias/offset parameter
	CSvmTrainer<RealVector> trainer1(&kernel, C, bias);
	KernelClassifier<RealVector> kc;

	//Neural network model
	FFNet<LogisticNeuron,LinearNeuron> network;

	bool alwaysValid = true;
	bool alwaysInvalid = true;

	long numIterationBeforePlanChanges = queryGraph->getNumOfNodes()*10000;

	int nTrainNodes = 0;
	int nTrainValidNodes = 0;
	int nTrainInvalidNodes = 0;

	Statistics::trainingTime+=TimeUtility::GetCounterMicro();

	vector<int> validNodeIDs;

	vector<tr1::unordered_map<int, int>*>* embeddings = NULL;
	tr1::unordered_map<int, tr1::unordered_map<string, void*>*>* embeddingsFeatures = NULL;

	tr1::unordered_map<string, int*>* sigToPlan = new tr1::unordered_map<string, int*>();

	//training step
	if(!donotTrain) {
		TimeUtility::StartCounterMicro();

		embeddings = new vector<tr1::unordered_map<int, int>*>();

		tr1::unordered_map<int, int> nodeToValidity;

		int counter = 0;
		for(tr1::unordered_set<int>::iterator iter = trainingNodeIDs.begin();iter!=trainingNodeIDs.end();iter++)
		{
//			cout<<"NodeID = "<<(*iter)<<endl;
			NodeX* graphNode = graph->getNodeWithID((*iter));
//			cout<<"Node f key: "<<graphNode->getFeaturesKey()<<flush;
			Features* graphNodeFeatures = (Features*)graphNode->getFeatures();

			graphNodeFeatures->addToFeaturesNames(featuresNames);

			vector<int> result;
//			queryGraph->isIsomorphic_OneMatch_Fast_Pessimistic(graph, result, invalidPlan, domainID, *iter);
//			if(nTrainValidNodes>nTrainInvalidNodes) {
//				queryGraph->isIsomorphic_IterativePlanModification(graph, result, invalidPlan, 1, domainID, *iter, numIterationBeforePlanChanges);
//			}
//			else {
//				queryGraph->isIsomorphic_IterativePlanModification(graph, result, invalidPlan, 0, domainID, *iter, numIterationBeforePlanChanges);
//			}

//			int* tempPlan = new int[queryGraph->getNumOfNodes()];
//			for(int i=0;i<queryGraph->getNumOfNodes();i++)
//				tempPlan[i] = invalidPlan[i];

//			queryGraph->isIsomorphic_IterativePlanModification(graph, result, invalidPlan, 0, domainID, *iter, numIterationBeforePlanChanges, NULL, false);

			queryGraph->isIsomorphic_IterativePlanModification(graph, result, invalidPlan, sigToPlan, 0, domainID, *iter, numIterationBeforePlanChanges);

//			int weights[queryGraph->getNumOfNodes()];
//			bool b = queryGraph->isIsomorphic_OneMatch_Fast_Pessimistic_2(graph, result, invalidPlan, domainID, *iter, numIterationBeforePlanChanges, NULL, NULL, weights);
//			if(!b) {
//				int* tempPlan = new int[queryGraph->getNumOfNodes()];
//				for(int i=0;i<queryGraph->getNumOfNodes();i++)
//					tempPlan[i] = invalidPlan[i];
//				queryGraph->isIsomorphic_IterativePlanModification_2(graph, result, tempPlan, 0, domainID, *iter, numIterationBeforePlanChanges, NULL, false, 2);
//				delete[] tempPlan;
//			}

			//outcome
			int valid = 0;
			if(result.size()>0)
			{
				valid = 1;
				nTrainValidNodes++;
				alwaysInvalid = false;
				Statistics::foundValids++;
				validNodeIDs.push_back(*iter);
				Statistics::numValids_optimal++;

//				for(int i=0;i<queryGraph->getNumOfNodes();i++)
//					invalidPlan[i] = tempPlan[i];
			}
			else
			{
				nTrainInvalidNodes++;
				alwaysValid = false;
				Statistics::foundInvalids++;
				Statistics::numInvalids_optimal++;
			}

//			delete[] tempPlan;

//			cout<<", valid = "<<valid<<endl<<flush;
			nodeToValidity.insert(std::pair<int, int>((*iter), valid));

			trainingFS.push_back(graphNode);

			counter++;
//			if(counter%10==0)
//				cout<<"training "<<counter<<"/"<<trainingNodeIDs.size()<<endl;
		}

		if(modelType==4)
		{
			unsigned numInput=featuresNames.size();//2;
			unsigned numHidden=32;
			unsigned numOutput=1;//1;
			network.setStructure(numInput,numHidden,numOutput,FFNetStructures::Normal,true);
		}

		//print embeddings
//		cout<<"Training embeddings ..."<<endl;
//		for(vector<tr1::unordered_map<int, int>*>::iterator it = embeddings->begin();it!=embeddings->end();it++) {
//			tr1::unordered_map<int, int>* ce = *it;
//			for(tr1::unordered_map<int, int>::iterator it2 = ce->begin();it2!=ce->end();it2++) {
//				cout<<it2->first<<":"<<it2->second<<", ";
//			}
//			cout<<endl;
//		}

		//** prepare feature vectors for valid node embeddings **//
		//insert empty vectors, one per query node
		embeddingsFeatures = new tr1::unordered_map<int, tr1::unordered_map<string, void*>*>();
		for(int i=0;i<queryGraph->getNumOfNodes();i++) {
			embeddingsFeatures->insert(std::pair<int, tr1::unordered_map<string, void*>*>(i, new tr1::unordered_map<string, void*>()));
		}

		for(vector<tr1::unordered_map<int, int>*>::iterator embedsIter = embeddings->begin();embedsIter!=embeddings->end();embedsIter++) {
			tr1::unordered_map<int, int>* embedding = *embedsIter;

			for(tr1::unordered_map<int, int>::iterator iter1 = embedding->begin();iter1 != embedding->end(); iter1++) {
				int queryNode = iter1->first;
				int graphNode = iter1->second;
				NodeX* nn = graph->getNodeWithID(graphNode);
				Features* graphNodeFeatures = (Features*)nn->getFeatures();
				embeddingsFeatures->find(queryNode)->second->insert(std::pair<string, void*>(nn->getFeaturesKey(), graphNodeFeatures));
			}
		}

		//delete embeddings here
		for(vector<tr1::unordered_map<int, int>*>::iterator tempIter = embeddings->begin();tempIter!=embeddings->end();tempIter++)
			delete (*tempIter);
		delete embeddings;

//		while(featuresNames.size()>10) featuresNames.erase(featuresNames.begin());
//		cout<<"featuresNames.size() = "<<featuresNames.size()<<endl;

		//balance the classes
		bool balance = false;
		if(balance && !alwaysValid && !alwaysInvalid)
		{
			int a = -1;//-1 data is balanced, 0- biased to invalid, 1- baised to valid
			if((nTrainValidNodes/((double)nTrainValidNodes+nTrainInvalidNodes))<0.4)
				a = 0;
			else if((nTrainInvalidNodes/((double)nTrainValidNodes+nTrainInvalidNodes))<0.4)
				a = 1;

			while(a!=-1) {
				int r = rand()%trainingFS.size();
				NodeX* node = trainingFS[r];
				Features* fs = (Features*)node->getFeatures();
				double valid = nodeToValidity.find(node->getID())->second;
				if(a==0 && valid==0) {
					trainingFS.erase(trainingFS.begin()+r);
					nTrainInvalidNodes--;
					if((nTrainValidNodes/((double)nTrainValidNodes+nTrainInvalidNodes))>=0.4)
						a = -1;
				}
				else if(a==1 && valid==1) {
					trainingFS.erase(trainingFS.begin()+r);
					nTrainValidNodes--;
					if((nTrainInvalidNodes/((double)nTrainValidNodes+nTrainInvalidNodes))>=0.4)
						a = -1;
				}
			}
		}

		//build the model using the collected training data
		if(!alwaysValid && !alwaysInvalid) {
			std::vector<RealVector> inputs;
			std::vector<unsigned int> labels;

			for(vector<NodeX* >::iterator iter = trainingFS.begin();iter!=trainingFS.end();iter++) {
				NodeX* node = (*iter);
				Features* tempFS = (Features*) node->getFeatures();

				RealVector input;
//				input.resize(featuresNames.size());
//				for(int i=0;i<featuresNames.size();i++)
//					input(i) = 0;

//				int index = 0;
				shark::blas::vector<double>::const_iterator iter2 = input.begin();
				for(tr1::unordered_set<int>::iterator iter1 = featuresNames.begin();iter1!=featuresNames.end();iter1++) {
					int name = (*iter1);
					Feature* tempF = tempFS->getFeature(name);
					if(tempF==NULL)
						input.push_back(0);//(*iter2) = 0;
					else
						input.push_back(tempF->getValue());
//						(*iter2) = tempF->getValue();
//						input[index] = tempF->getValue();

//					index++;
					iter2++;
				}

				inputs.push_back(input);

				labels.push_back((unsigned int)nodeToValidity.find(node->getID())->second);
			}

			ClassificationDataset dataset = createLabeledDataFromRange(inputs, labels);

			//normalization
	//		bool removeMean = true;
	//		NormalizeComponentsUnitVariance<RealVector> normalizingTrainer(removeMean);
	//		normalizingTrainer.train(normalizer, dataset.inputs());
	//		LabeledData<RealVector, unsigned int> normalizedData = transformInputs(dataset, normalizer);

			switch(modelType) {
			case 1: //Random forest training
				{
				RFTrainer trainer;
//				trainer.train(model, normalizedData);
				trainer.train(model, dataset);
				}
				break;
			case 2: //KNN training
				{
				KDTree<RealVector> tree(dataset.inputs());
				TreeNearestNeighbors<RealVector,unsigned int> algorithm(dataset,&tree);
				const unsigned int K = 1; // number of neighbors for kNN
				KNN = new NearestNeighborClassifier<RealVector>(&algorithm,K);
				}
				break;
			case 3:
				{
				trainer1.train(kc, dataset);
				}
				break;
			case 4:
				{
					//create error function
					CrossEntropy loss; // surrogate loss for training
					ErrorFunction error(dataset,&network,&loss);
					//initialize Rprop and initialize the network randomly
					initRandomUniform(network,-0.1,0.1);
					IRpropPlus optimizer;
					error.init();
					optimizer.init(error);
					unsigned numberOfSteps = 1000;
					for(unsigned step = 0; step != numberOfSteps; ++step)
						optimizer.step(error);
				}
				break;
			}

			cout<<"training done using "<<trainingFS.size()<<" instances."<<endl;
			nTrainNodes = trainingFS.size();
		}
		else
		{
			cout<<"No training since either alwaysvalid or alwaysinvalid"<<endl;
		}

		Statistics::trainingTime+=TimeUtility::GetCounterMicro();
	}
	else {
		//since no training, set all predictions to invalid
		alwaysInvalid = true;
		alwaysValid = false;
	}

	for(int i=0;i<queryGraph->getNumOfNodes();i++) {
		validPlan[i] = invalidPlan[i];
	}

//	cout<<"nTrainNodes = "<<nTrainNodes<<endl;
//	cout<<"nTrainValidNodes = "<<nTrainValidNodes<<endl;
//	cout<<"nTrainInvalidNodes = "<<nTrainInvalidNodes<<endl;
	/////////////////////////////////////////////

	//start the testing phase; using the model to predict for next nodes

	TimeUtility::StartCounterMicro();
	//nodes visited earlier
	tr1::unordered_map<string, NodeX*> visitedNodeSig;
	tr1::unordered_map<int, int> nodeIDToDecision;
	vector<int> toBePredictedNodes;

	for(set<int>::iterator iter = nodesList->begin();iter!=nodesList->end();iter++)
	{
		int predicted = -1;
		int id = (*iter);

		//this node has been already checked (in the training phase)
		if(trainingNodeIDs.find(id)!=trainingNodeIDs.end())
			continue;

		//if all training resulted in one of either decisions
		if(alwaysValid) {
			nodeIDToDecision.insert(std::pair<int, int>((*iter), 1));
			continue;
		}
		else if(alwaysInvalid) {
			nodeIDToDecision.insert(std::pair<int, int>((*iter), 0));
			continue;
		}

		//check if a similar node was visited before
		NodeX* node = graph->getNodeWithID(id);
		string featuresKey = node->getFeaturesKey();
		tr1::unordered_map<string, NodeX*>::iterator tempIter = visitedNodeSig.find(featuresKey);
		if(tempIter!=visitedNodeSig.end()) {
			predicted = tempIter->second->getID()+2;
		} else {
			visitedNodeSig.insert(std::pair<string, NodeX*>(featuresKey, node));
		}

		nodeIDToDecision.insert(std::pair<int, int>(id,predicted));
		if(predicted==-1)
			toBePredictedNodes.push_back(id);
	}

//	cout<<"toBePredictedNodes size = "<<toBePredictedNodes.size()<<endl;

	//do the predictions
	std::vector<RealVector> inputs;
	for(vector<int>::iterator iter = toBePredictedNodes.begin();iter!=toBePredictedNodes.end();iter++) {
		int nodeID = *iter;
		NodeX* graphNode = graph->getNodeWithID(nodeID);
		Features* graphNodeFeatures = (Features*)graphNode->getFeatures();

		RealVector input;
//		input.resize(featuresNames.size());
//		for(unsigned int i=0;i<featuresNames.size();i++)
//			input(i) = 0;

//		int index = 0;
		for(tr1::unordered_set<int>::iterator iter1 = featuresNames.begin();iter1!=featuresNames.end();iter1++) {
			Feature* tempF;
			if(graphNodeFeatures->getFeatuesSize()<6)
				tempF = graphNodeFeatures->getFeature_Sequential((*iter1));
			else
				tempF = graphNodeFeatures->getFeature((*iter1));

			if(tempF==NULL)
				input.push_back(0);
			else
				input.push_back(tempF->getValue());
		}
		inputs.push_back(input);
	}

	elapsed = TimeUtility::GetCounterMicro();
	Statistics::predictionPreparationTime+=elapsed;
	if(showForDebug)
		cout<<"Statistics::predictionPreparationTime: "<<elapsed<<endl;

	//employ the model to get predictions
	TimeUtility::StartCounterMicro();
	Data<RealVector> predictions;
	Data<unsigned int> predictions_3;
	if(toBePredictedNodes.size()>0) {
		UnlabeledData<RealVector> dataset = createUnlabeledDataFromRange(inputs);

		switch(modelType) {
		case 1:
			predictions = model(dataset.inputs());
			break;
		case 2:
			predictions_3 = (*KNN)(dataset.inputs());
			break;
		case 3:
			predictions_3 = kc(dataset.inputs());
			break;
		case 4:
			Softmax probabilty(1);
			predictions = (network>>probabilty)(dataset.inputs());
			break;
		}
	}

	Statistics::predictionTime+=TimeUtility::GetCounterMicro();

	TimeUtility::StartCounterMicro();
	//holding previous nodes and results
//	tr1::unordered_map<string, int> nodeSigToDecision;

	//assign predictions
//	int index = 0;

//		for ( = elements.begin(); pos != elements.end(); ++pos) {
//			std::cout << *pos << std::endl;
//		}


	switch(modelType) {
		case 1:
		{
			Data<RealVector>::element_range::iterator pos = predictions.elements().begin();
			for(vector<int>::iterator iter = toBePredictedNodes.begin();iter!=toBePredictedNodes.end();iter++)
			{
				int nodeID = *iter;
				int prediction = -1;

				if(showForDebug) {
					cout<<nodeID<<" prediction value: ("<<(*pos)[0]<<", "<<(*pos)[1]<<")"<<endl;
				}
				if((*pos)[0]>(*pos)[1])
					prediction = 0;
				else
					prediction = 1;

				nodeIDToDecision.erase(nodeID);
				nodeIDToDecision.insert(std::pair<int, int>(nodeID, prediction));
				++pos;
			}
		}
		break;
		case 2:
		{
			Data<unsigned int>::element_range::iterator pos = predictions_3.elements().begin();
			for(vector<int>::iterator iter = toBePredictedNodes.begin();iter!=toBePredictedNodes.end();iter++)
			{
				int nodeID = *iter;
				int prediction = -1;

				if(showForDebug) {
					cout<<nodeID<<" prediction value: ("<<(*pos)<<")"<<endl;
				}
				prediction = (*pos);

				nodeIDToDecision.erase(nodeID);
				nodeIDToDecision.insert(std::pair<int, int>(nodeID, prediction));
				++pos;
			}
		}
		break;
		case 3:
		{
			Data<unsigned int>::element_range::iterator pos = predictions_3.elements().begin();
			for(vector<int>::iterator iter = toBePredictedNodes.begin();iter!=toBePredictedNodes.end();iter++)
			{
				int nodeID = *iter;
				int prediction = -1;

				if(showForDebug) {
					cout<<nodeID<<" prediction value: ("<<(*pos)<<")"<<endl;
				}
				prediction = (*pos);

				nodeIDToDecision.erase(nodeID);
				nodeIDToDecision.insert(std::pair<int, int>(nodeID, prediction));
				++pos;
			}
		}
		break;
		case 4:
		{
			Data<RealVector>::element_range::iterator pos = predictions.elements().begin();
			for(vector<int>::iterator iter = toBePredictedNodes.begin();iter!=toBePredictedNodes.end();iter++)
			{
				int nodeID = *iter;
				int prediction = -1;

				if(showForDebug) {
					cout<<nodeID<<" prediction value: ("<<(*pos)[0]<<", "<<(*pos)[1]<<")"<<endl;
				}
				if((*pos)[0]<0.5)
					prediction = 0;
				else
					prediction = 1;

				nodeIDToDecision.erase(nodeID);
				nodeIDToDecision.insert(std::pair<int, int>(nodeID, prediction));
				++pos;
			}
		}
		break;
	}
	toBePredictedNodes.clear();
	elapsed = TimeUtility::GetCounterMicro();
	Statistics::predictionPreparationTime+=elapsed;

	if(showForDebug)
		cout<<"Statistics::predictionPreparationTime: "<<elapsed<<endl;

	int counter = 0;
	int maxToVisit = 10;
	int numValidsFoundValid = 0;
	int numValidsFoundInvalid = 0;

	for(tr1::unordered_map<int, int>::iterator iter = nodeIDToDecision.begin();iter!=nodeIDToDecision.end();iter++) {

		double prevValidsFoundInvalid = 1;

		TimeUtility::StartCounterMicro();
		//get the result from the default function
		int valid = -1;
		if(idToValidity!=NULL) {
			tr1::unordered_map<int, int>::iterator tIter = idToValidity->find(iter->first);
			if(tIter!=idToValidity->end())
				valid = tIter->second;
		}

		//do subgraph isomorphism for current node
		int predicted = iter->second;

		NodeX* graphNode = graph->getNodeWithID(iter->first);

		//assign the source node ID that give the decision
		int sourceOfDecision = iter->first;

		//check if a similar node was visited before
		if(predicted>1) {
			string featuresKey = graphNode->getFeaturesKey();
			sourceOfDecision = predicted-2;
			tr1::unordered_map<int, int>::iterator ToPrediction = nodeIDToDecision.find(predicted-2);
//			tr1::unordered_map<string, int>::iterator sigToPrediction = nodeSigToDecision.find(featuresKey);
			if(ToPrediction!=nodeIDToDecision.end()) {
				predicted = ToPrediction->second;
//				cout<<"A similar node was predicted previously."<<" inherited prediction is: "<<predicted<<endl;
			}
			else
			{
				cout<<"ERRRROR2653623"<<endl;
				exit(0);
			}
		}

		counter++;
		if(showForDebug)
			cout<<counter<<"/"<<(nodeIDToDecision.size())<<". Node: "<<(iter->first)<<"predicted = "<<predicted<<", node sig = "<<graphNode->getFeaturesKey()<<",";
		if(counter%100000==0)
			cout<<"Actual: "<<counter<<"/"<<(nodeIDToDecision.size())<<endl;

		int foundValid = 0;//decision found by prediction

		Statistics::optimizedSubIsoTime+=TimeUtility::GetCounterMicro();

		if(predicted==1) {

//			int* tempPlan = new int[queryGraph->getNumOfNodes()];
//			for(int i=0;i<queryGraph->getNumOfNodes();i++)
//				tempPlan[i] = validPlan[i];

			//conduct optimistic search
			TimeUtility::StartCounterMicro();
			vector<int> result;
			queryGraph->isIsomorphic_OneMatch_Fast_Super_Optimistic(graph, result, validPlan, domainID, iter->first, maxToVisit);
//			long elapsed_A1 = TimeUtility::GetCounterMicro();
//			TimeUtility::StartCounterMicro();
			if(result.size()==0)
				queryGraph->isIsomorphic_OneMatch_Fast_Super_Optimistic(graph, result, validPlan, domainID, iter->first, maxToVisit, NULL, true);
//			long elapsed_A2 = TimeUtility::GetCounterMicro();
//			TimeUtility::StartCounterMicro();
//			if(result.size()==0)
//				queryGraph->isIsomorphic_OneMatch_Fast_Super_Optimistic(graph, result, invalidPlan, domainID, iter->first, maxToVisit, embeddingsFeatures);
//			long elapsed_A3 = TimeUtility::GetCounterMicro();

//			TimeUtility::StartCounterMicro();
			if(result.size()==0)
			{
//				queryGraph->isIsomorphic_OneMatch_Fast_Optimistic(graph, result, invalidPlan, domainID, *iter);

				//newly add on 12-s-2017
//				if(usePess4Opt)
//					queryGraph->isIsomorphic_IterativePlanModification(graph, result, invalidPlan, 0, domainID, iter->first, numIterationBeforePlanChanges);
//				else
//					queryGraph->isIsomorphic_IterativePlanModification(graph, result, invalidPlan, 1, domainID, iter->first, numIterationBeforePlanChanges);

				//queryGraph->isIsomorphic_IterativePlanModification(graph, result, validPlan, 1, domainID, iter->first, numIterationBeforePlanChanges, NULL, false);
				queryGraph->isIsomorphic_IterativePlanModification(graph, result, validPlan, sigToPlan, 1, domainID, iter->first, numIterationBeforePlanChanges);

//				queryGraph->isIsomorphic_IterativePlanModification(graph, result, invalidPlan, 0, domainID, iter->first, numIterationBeforePlanChanges, NULL, false, 1);

//				bool b = queryGraph->isIsomorphic_OneMatch_Fast_Optimistic( graph, result, invalidPlan, domainID, iter->first, numIterationBeforePlanChanges);
//				if(!b) {
//					int* tempPlan = new int[queryGraph->getNumOfNodes()];
//					for(int i=0;i<queryGraph->getNumOfNodes();i++)
//						tempPlan[i] = invalidPlan[i];
//					queryGraph->isIsomorphic_IterativePlanModification(graph, result, tempPlan, 1, domainID, iter->first, numIterationBeforePlanChanges);
//					delete[] tempPlan;
//				}

				Statistics::validFoundInvalid++;
				if(showForDebug)
					cout<<" validfoundinvalid ";

				numValidsFoundInvalid++;
			}
			else {
				Statistics::validFoundValid++;
				numValidsFoundValid++;
			}

//			cout<<"A1 = "<<elapsed_A1<<"A2 = "<<elapsed_A2<<"A3 = "<<elapsed_A3<<" | ";

			long elapsed = TimeUtility::GetCounterMicro();//+elapsed_A1+elapsed_A2+elapsed_A3;
			Statistics::optimizedSubIsoTime+=elapsed;

			//newly add on 12-s-2017
			/*if(checkPess && elapsed>20000000) {
				if(showForDebug)
					cout<<"Trying pessimistic ..."<<incPess<<","<<incOpt<<endl;

				TimeUtility::StartCounterMicro();

				vector<int> result_1;
				queryGraph->isIsomorphic_IterativePlanModification(graph, result_1, invalidPlan, 0, domainID, iter->first, numIterationBeforePlanChanges);

				long elapsed_1 = TimeUtility::GetCounterMicro();

				if(showForDebug)
					cout<<"elapsed = "<<elapsed<<", elapsed_1"<<elapsed_1<<endl;

				if(elapsed_1<elapsed)
					incPess++;
				else
					incOpt++;

				int total = incPess+incOpt;
				if(total>20) {
					if((incPess/((double)total))>0.7)
						usePess4Opt = true;

					checkPess = false;
				}
			}*/

			if(result.size()>0)
				Statistics::timeCorrectlySpentOnValid+=elapsed;
			else
				Statistics::timeIncorrectlySpentOnValid+=elapsed;

			if(result.size()>0) {
				foundValid = 1;
				Statistics::foundValids++;
				Statistics::numValids_optimal++;
				validNodeIDs.push_back(iter->first);
			}
			else {
				Statistics::foundInvalids++;
				Statistics::numInvalids_optimal++;
				numValidsFoundInvalid--;

//				for(int i=0;i<queryGraph->getNumOfNodes();i++)
//					validPlan[i] = tempPlan[i];
			}
//			delete[] tempPlan;

			Statistics::predictedValids++;
			if(foundValid==1)
			{
				if(showForDebug) cout<<" [CORRECT]"<<", ";
				Statistics::numCorrects++;
			}
			else if(foundValid==0)
			{
				if(showForDebug) cout<<" [INCORRECT]"<<", ";
				Statistics::numIncorrects++;
				int nID = graphNode->getID();
//				nodeIDToDecision.erase(nID);
//				nodeIDToDecision.insert(std::pair<int, int>(nID, foundValid));
				//nodeIDToDecision.find(nID)->second = foundValid;
				nodeIDToDecision.find(sourceOfDecision)->second = foundValid;
			}
			if(showForDebug) cout<<elapsed<<endl;

//			double currValidsFoundInvalid = ((double)numValidsFoundInvalid)/(numValidsFoundInvalid+numValidsFoundValid);
//			if(currValidsFoundInvalid>0.1 && maxToVisit<1000 && (numValidsFoundInvalid+numValidsFoundValid)>50) {
//				if(maxToVisit>20 && currValidsFoundInvalid>=prevValidsFoundInvalid) {
//
//				}
//				else
//				{
//					maxToVisit=maxToVisit*2;
//					if(maxToVisit>1000)
//						maxToVisit = 1000;
//					numValidsFoundInvalid = 0;
//					numValidsFoundValid = 0;
//					cout<<"MaxToVisit Increased to: "<<maxToVisit<<endl;
//				}
//			}
		}
		else if(predicted==0)
		{
//			int* tempPlan = new int[queryGraph->getNumOfNodes()];
//			for(int i=0;i<queryGraph->getNumOfNodes();i++)
//				tempPlan[i] = invalidPlan[i];

			//conduct pessimistic search
			TimeUtility::StartCounterMicro();
			vector<int> result;
//			queryGraph->isIsomorphic_OneMatch_Fast_Pessimistic(graph, result, invalidPlan, domainID, *iter);
			//queryGraph->isIsomorphic_IterativePlanModification(graph, result, invalidPlan, 0, domainID, iter->first, numIterationBeforePlanChanges, NULL, false, 1);
			queryGraph->isIsomorphic_IterativePlanModification(graph, result, invalidPlan, sigToPlan, 0, domainID, iter->first, numIterationBeforePlanChanges);

//			int weights[queryGraph->getNumOfNodes()];
//			bool b = queryGraph->isIsomorphic_OneMatch_Fast_Pessimistic_2(graph, result, invalidPlan, domainID, iter->first, numIterationBeforePlanChanges, NULL, NULL, weights);
//			if(!b) {
//				int* tempPlan = new int[queryGraph->getNumOfNodes()];
//				for(int i=0;i<queryGraph->getNumOfNodes();i++)
//					tempPlan[i] = invalidPlan[i];
//				queryGraph->isIsomorphic_IterativePlanModification_2(graph, result, tempPlan, 0, domainID, iter->first, numIterationBeforePlanChanges, NULL, false, 2);
//				delete[] tempPlan;
//			}

			long elapsed = TimeUtility::GetCounterMicro();
			Statistics::optimizedSubIsoTime+=elapsed;
			if(result.size()>0)
				Statistics::timeIncorrectlySpentOnInvalid+=elapsed;
			else
				Statistics::timeCorrectlySpentOnInvalid+=elapsed;

			if(result.size()>0) {
//				cout<<"VALID NODE: "<<iter->first<<endl;
			}

			if(result.size()>0) {
				foundValid = 1;
				Statistics::foundValids++;
				Statistics::numValids_optimal++;
				validNodeIDs.push_back(iter->first);

//				for(int i=0;i<queryGraph->getNumOfNodes();i++)
//					invalidPlan[i] = tempPlan[i];
			}
			else {
				Statistics::foundInvalids++;
				Statistics::numInvalids_optimal++;
			}

//			delete[] tempPlan;

			Statistics::predictedInvalids++;
			if(foundValid==0)
			{
				if(showForDebug) cout<<" [CORRECT]"<<", ";
				Statistics::numCorrects++;
			}
			else if(foundValid==1)
			{
				if(showForDebug) cout<<" [INCORRECT]"<<", ";
				Statistics::numIncorrects++;
				int nID = graphNode->getID();
//				nodeIDToDecision.erase(nID);
//				nodeIDToDecision.insert(std::pair<int, int>(nID, foundValid));
//				nodeIDToDecision.find(nID)->second = foundValid;
				nodeIDToDecision.find(sourceOfDecision)->second = foundValid;
			}
			if(showForDebug) cout<<elapsed<<endl;
		}
		else {
			cout<<"Error55533: no prediction is found for this node"<<endl;
			exit(0);
		}

		if(valid!=-1 && foundValid!=valid)
		{
			cout<<"Error645454: "<<foundValid<<","<<valid<<endl;
			exit(0);
		}
	}

	if(showValids) {
		cout<<"the liust of valid node IDs:"<<endl;
		for(vector<int>::iterator iter = validNodeIDs.begin();iter!=validNodeIDs.end();iter++) {
			cout<<*iter<<endl;
		}
	}

	delete[] invalidPlan;

	for(tr1::unordered_map<string, int*>::iterator iterPlan = sigToPlan->begin();iterPlan!=sigToPlan->end();iterPlan++) {
		delete[] iterPlan->second;
	}
	delete sigToPlan;
}

void doQuery_advancedPlanning(GraphX* graph, GraphX* queryGraph, int domainID, tr1::unordered_map<int, int>* idToValidity, bool showValids, bool twoThreads, bool useDifferentPlans, int threadedType) {

	cout<<"Querying initiated [Advanced planning] ..."<<endl;

	TimeUtility::StartCounterMicro();

	double percentage = 0.1;//the percentage of nodes to use for training

//	int* validPlan = queryGraph->generateTreeFirstPlan(domainID, graph);
	int* invalidPlan = queryGraph->generateSelectBasedPlan(domainID, graph);
	int* validPlan = new int[queryGraph->getNumOfNodes()];

	vector<int*> plans;
	if(useDifferentPlans)
		plans = queryGraph->generateRandomPlans(10, domainID);
//	plans.clear();
	plans.insert(plans.begin(), invalidPlan);

//	int* invalidPlan = selectGoodPlan(queryGraph, graph, domainID);

	long elapsed = TimeUtility::GetCounterMicro();
	if(twoThreads)
		Statistics::h_predictionPreparationTime+=elapsed;
	else
		Statistics::predictionPreparationTime+=elapsed;
	cout<<"Plans generation time = "<<elapsed<<", number of plans = "<<plans.size()<<endl;

	TimeUtility::StartCounterMicro();

	if(invalidPlan==NULL) {
//		cout<<"Early no results"<<endl;
		return;
	}

	//generate candidate nodes
	set<int>* nodesList = graph->getNodeIDsByLabel(queryGraph->getNodeWithID(domainID)->getLabel());

	double maxNumTrainNodes = 1000.0;

	if(nodesList->size()*percentage>maxNumTrainNodes)
		percentage = maxNumTrainNodes/nodesList->size();

	//select the list of nodes to use for training
	srand(time(NULL));
	tr1::unordered_set<int> trainingNodeIDs;
	for(set<int>::iterator tempIter = nodesList->begin();tempIter!=nodesList->end();tempIter++)
	{
		int r = rand() % 1000000;
		if(r<percentage*1000000)
			trainingNodeIDs.insert(*tempIter);
	}

	bool donotTrain = false;
	if(trainingNodeIDs.size()<10) {
		cout<<"No enough instances to train ... training is skipped!"<<endl;
		donotTrain = true;
		trainingNodeIDs.clear();
	}
	else
		cout<<trainingNodeIDs.size()<<"/"<<nodesList->size()<<" selected for training."<<endl;

	if(threadedType>1) {
		donotTrain = true;
		cout<<"ML prediction is DISABLED ... training is skipped!"<<endl;
	}

	NodeX* queryNode = queryGraph->getNodeWithID(domainID);
	Features* queryNodeFeatures = (Features*)queryNode->getFeatures();

	tr1::unordered_set<int> featuresNames;

	vector<NodeX* > trainingFS;//containing training nodes

	RFClassifier model;
	RFClassifier optPlanModel;//model for optimisic nodes planning
	RFClassifier pessPlanModel;//model for pessimistic nodes planning
	Normalizer<RealVector> normalizer;

	bool alwaysValid = true;
	bool alwaysInvalid = true;

	long numIterationBeforePlanChanges = queryGraph->getNumOfNodes()*10000;

	int nTrainNodes = 0;
	int nTrainValidNodes = 0;
	int nTrainInvalidNodes = 0;

	if(twoThreads)
		Statistics::h_trainingTime+=TimeUtility::GetCounterMicro();
	else
		Statistics::trainingTime+=TimeUtility::GetCounterMicro();

	vector<int> validNodeIDs;

	vector<tr1::unordered_map<int, int>*>* embeddings = NULL;
	tr1::unordered_map<int, tr1::unordered_map<string, void*>*>* embeddingsFeatures = NULL;

	tr1::unordered_map<string, int*>* sigToPlan = new tr1::unordered_map<string, int*>();

	PlansStats pStatsPess;
	PlansStats pStatsOpt;

	//training step
	if(!donotTrain) {
		TimeUtility::StartCounterMicro();

		embeddings = new vector<tr1::unordered_map<int, int>*>();

		tr1::unordered_map<int, int> nodeToValidity;

		int counter = 0;
		for(tr1::unordered_set<int>::iterator iter = trainingNodeIDs.begin();iter!=trainingNodeIDs.end();iter++)
		{
//			cout<<"NodeID = "<<(*iter)<<endl;
			NodeX* graphNode = graph->getNodeWithID((*iter));
//			cout<<"Node f key: "<<graphNode->getFeaturesKey()<<flush;
			Features* graphNodeFeatures = (Features*)graphNode->getFeatures();

			graphNodeFeatures->addToFeaturesNames(featuresNames);

			vector<int> result;

			queryGraph->isIsomorphic_IterativePlanModification(graph, result, invalidPlan, sigToPlan, 0, domainID, *iter, numIterationBeforePlanChanges);

			//outcome
			int valid = 0;
			if(result.size()>0)
			{
				valid = 1;
				nTrainValidNodes++;
				alwaysInvalid = false;
				if(twoThreads)
				{
//					Statistics::h_foundValids++;
					Statistics::h_numValids++;
				}
				else
				{
					Statistics::foundValids++;
					Statistics::numValids_optimal++;
				}

				validNodeIDs.push_back(*iter);
			}
			else
			{
				nTrainInvalidNodes++;
				alwaysValid = false;
				if(twoThreads)
				{
//					Statistics::h_foundInvalids++;
					Statistics::h_numInvalids++;
				}
				else
				{
					Statistics::foundInvalids++;
					Statistics::numInvalids_optimal++;
				}
			}

			nodeToValidity.insert(std::pair<int, int>((*iter), valid));

			trainingFS.push_back(graphNode);

			counter++;
		}

		//** prepare feature vectors for valid node embeddings **//
		//insert empty vectors, one per query node
		embeddingsFeatures = new tr1::unordered_map<int, tr1::unordered_map<string, void*>*>();
		for(int i=0;i<queryGraph->getNumOfNodes();i++) {
			embeddingsFeatures->insert(std::pair<int, tr1::unordered_map<string, void*>*>(i, new tr1::unordered_map<string, void*>()));
		}

		for(vector<tr1::unordered_map<int, int>*>::iterator embedsIter = embeddings->begin();embedsIter!=embeddings->end();embedsIter++) {
			tr1::unordered_map<int, int>* embedding = *embedsIter;

			for(tr1::unordered_map<int, int>::iterator iter1 = embedding->begin();iter1 != embedding->end(); iter1++) {
				int queryNode = iter1->first;
				int graphNode = iter1->second;
				NodeX* nn = graph->getNodeWithID(graphNode);
				Features* graphNodeFeatures = (Features*)nn->getFeatures();
				embeddingsFeatures->find(queryNode)->second->insert(std::pair<string, void*>(nn->getFeaturesKey(), graphNodeFeatures));
			}
		}

		//delete embeddings here
		for(vector<tr1::unordered_map<int, int>*>::iterator tempIter = embeddings->begin();tempIter!=embeddings->end();tempIter++)
			delete (*tempIter);
		delete embeddings;

		//prepare search order planning based on ML

		//build 2 models for the plans, one for optimistic and the other for pessimistic
		//******************************
		std::vector<RealVector> opt_inputs;
		std::vector<unsigned int> opt_labels;

		std::vector<RealVector> pess_inputs;
		std::vector<unsigned int> pess_labels;

		for(vector<NodeX* >::iterator iter = trainingFS.begin();iter!=trainingFS.end();iter++) {
			NodeX* node = (*iter);
			Features* tempFS = (Features*) node->getFeatures();

			RealVector input;

			shark::blas::vector<double>::const_iterator iter2 = input.begin();
			for(tr1::unordered_set<int>::iterator iter1 = featuresNames.begin();iter1!=featuresNames.end();iter1++) {
				int name = (*iter1);
				Feature* tempF = tempFS->getFeature(name);
				if(tempF==NULL)
					input.push_back(0);//(*iter2) = 0;
				else
					input.push_back(tempF->getValue());

				iter2++;
			}

			int validity = nodeToValidity.find(node->getID())->second;
			long bestTime = -1;
			int bestPlan = queryGraph->selectBestPlan(plans, validity, graph, node->getID(), bestTime);
			if(validity==0) {
				pStatsPess.addPlan(plans[bestPlan], queryGraph->getNumOfNodes());
				pStatsPess.addTime(plans[bestPlan], queryGraph->getNumOfNodes(), bestTime);
			} else if(validity==1) {
				pStatsOpt.addPlan(plans[bestPlan], queryGraph->getNumOfNodes());
				pStatsOpt.addTime(plans[bestPlan], queryGraph->getNumOfNodes(), bestTime);
			}

			if(showForDebug) {
				cout<<"valid="<<validity<<", bestPlan="<<bestPlan<<", bestTime="<<bestTime<<", features=";
				tempFS->print(cout);
				cout<<endl;
			}

			if(validity==1) {
				opt_inputs.push_back(input);
				opt_labels.push_back((unsigned int)bestPlan);
			}
			else {
				pess_inputs.push_back(input);
				pess_labels.push_back((unsigned int)bestPlan);
			}
		}

		cout<<"opt_inputs.size() = "<<opt_inputs.size()<<endl<<flush;
		//train for optimistic
		ClassificationDataset opt_dataset;
		if(opt_inputs.size()>0) {
			opt_dataset = createLabeledDataFromRange(opt_inputs, opt_labels);
			RFTrainer opt_trainer;
			opt_trainer.train(optPlanModel, opt_dataset);
		}

		cout<<"pess_inputs.size() = "<<pess_inputs.size()<<endl<<flush;
		//train for pessimistic
		ClassificationDataset pess_dataset;
		if(pess_inputs.size()>0) {
			pess_dataset = createLabeledDataFromRange(pess_inputs, pess_labels);
			RFTrainer pess_trainer;
			pess_trainer.train(pessPlanModel, pess_dataset);
		}
		//******************************

//		if(true) {
//			cout<<"Exittttttt"<<endl;
//			exit(0);
//		}

		//balance the classes
		bool balance = false;
		if(balance && !alwaysValid && !alwaysInvalid)
		{
			int a = -1;//-1 data is balanced, 0- biased to invalid, 1- baised to valid
			if((nTrainValidNodes/((double)nTrainValidNodes+nTrainInvalidNodes))<0.4)
				a = 0;
			else if((nTrainInvalidNodes/((double)nTrainValidNodes+nTrainInvalidNodes))<0.4)
				a = 1;

			while(a!=-1) {
				int r = rand()%trainingFS.size();
				NodeX* node = trainingFS[r];
				Features* fs = (Features*)node->getFeatures();
				double valid = nodeToValidity.find(node->getID())->second;
				if(a==0 && valid==0) {
					trainingFS.erase(trainingFS.begin()+r);
					nTrainInvalidNodes--;
					if((nTrainValidNodes/((double)nTrainValidNodes+nTrainInvalidNodes))>=0.4)
						a = -1;
				}
				else if(a==1 && valid==1) {
					trainingFS.erase(trainingFS.begin()+r);
					nTrainValidNodes--;
					if((nTrainInvalidNodes/((double)nTrainValidNodes+nTrainInvalidNodes))>=0.4)
						a = -1;
				}
			}
		}

		//build the model using the collected training data
		if(!alwaysValid && !alwaysInvalid) {
			std::vector<RealVector> inputs;
			std::vector<unsigned int> labels;

			for(vector<NodeX* >::iterator iter = trainingFS.begin();iter!=trainingFS.end();iter++) {
				NodeX* node = (*iter);
				Features* tempFS = (Features*) node->getFeatures();

				RealVector input;
//				input.resize(featuresNames.size());
//				for(int i=0;i<featuresNames.size();i++)
//					input(i) = 0;

//				int index = 0;
				shark::blas::vector<double>::const_iterator iter2 = input.begin();
				for(tr1::unordered_set<int>::iterator iter1 = featuresNames.begin();iter1!=featuresNames.end();iter1++) {
					int name = (*iter1);
					Feature* tempF = tempFS->getFeature(name);
					if(tempF==NULL)
						input.push_back(0);//(*iter2) = 0;
					else
						input.push_back(tempF->getValue());
//						(*iter2) = tempF->getValue();
//						input[index] = tempF->getValue();

//					index++;
					iter2++;
				}

				inputs.push_back(input);

				labels.push_back((unsigned int)nodeToValidity.find(node->getID())->second);
			}

			ClassificationDataset dataset = createLabeledDataFromRange(inputs, labels);

			//normalization
	//		bool removeMean = true;
	//		NormalizeComponentsUnitVariance<RealVector> normalizingTrainer(removeMean);
	//		normalizingTrainer.train(normalizer, dataset.inputs());
	//		LabeledData<RealVector, unsigned int> normalizedData = transformInputs(dataset, normalizer);

			RFTrainer trainer;
	//		trainer.train(model, normalizedData);
			trainer.train(model, dataset);

			cout<<"training done using "<<trainingFS.size()<<" instances."<<endl;
			nTrainNodes = trainingFS.size();
		}
		else
		{
			cout<<"No training since either alwaysvalid or alwaysinvalid"<<endl;
		}

		if(twoThreads)
			Statistics::h_trainingTime+=TimeUtility::GetCounterMicro();
		else
			Statistics::trainingTime+=TimeUtility::GetCounterMicro();
	}
	else {
		//since no training, set all predictions to invalid
		alwaysInvalid = true;
		alwaysValid = false;
	}

	if(threadedType==2)
		alwaysValid = true;
	if(threadedType==3)
		alwaysInvalid = true;

	for(int i=0;i<queryGraph->getNumOfNodes();i++) {
		validPlan[i] = invalidPlan[i];
	}

//	cout<<"nTrainNodes = "<<nTrainNodes<<endl;
//	cout<<"nTrainValidNodes = "<<nTrainValidNodes<<endl;
//	cout<<"nTrainInvalidNodes = "<<nTrainInvalidNodes<<endl;
	/////////////////////////////////////////////

	//start the testing phase; using the model to predict for next nodes

	TimeUtility::StartCounterMicro();
	//nodes visited earlier
	tr1::unordered_map<string, NodeX*> visitedNodeSig;
	tr1::unordered_map<int, int> nodeIDToDecision;
	tr1::unordered_map<int, int> nodeIDToPlanPess;
	tr1::unordered_map<int, int> nodeIDToPlanOpt;
	vector<int> toBePredictedNodes;

	for(set<int>::iterator iter = nodesList->begin();iter!=nodesList->end();iter++)
	{
		int predicted = -1;
		int id = (*iter);

		//this node has been already checked (in the training phase)
		if(trainingNodeIDs.find(id)!=trainingNodeIDs.end())
			continue;

		//if all training resulted in one of either decisions
		if(alwaysValid) {
			nodeIDToDecision.insert(std::pair<int, int>((*iter), 1));
			nodeIDToPlanPess.insert(std::pair<int, int>((*iter), 0));
			nodeIDToPlanOpt.insert(std::pair<int, int>((*iter), 0));
			continue;
		}
		else if(alwaysInvalid) {
			nodeIDToDecision.insert(std::pair<int, int>((*iter), 0));
			nodeIDToPlanPess.insert(std::pair<int, int>((*iter), 0));
			nodeIDToPlanOpt.insert(std::pair<int, int>((*iter), 0));
			continue;
		}

		//check if a similar node was visited before
		NodeX* node = graph->getNodeWithID(id);
		string featuresKey = node->getFeaturesKey();
		tr1::unordered_map<string, NodeX*>::iterator tempIter = visitedNodeSig.find(featuresKey);
		if(tempIter!=visitedNodeSig.end()) {
			predicted = tempIter->second->getID()+2;
		} else {
			visitedNodeSig.insert(std::pair<string, NodeX*>(featuresKey, node));
		}

		nodeIDToDecision.insert(std::pair<int, int>(id,predicted));
		nodeIDToPlanOpt.insert(std::pair<int, int>(id,predicted));
		nodeIDToPlanPess.insert(std::pair<int, int>(id,predicted));

		if(predicted==-1)
			toBePredictedNodes.push_back(id);
	}

//	cout<<"toBePredictedNodes size = "<<toBePredictedNodes.size()<<endl;
	//do the predictions
	std::vector<RealVector> inputs;
	for(vector<int>::iterator iter = toBePredictedNodes.begin();iter!=toBePredictedNodes.end();iter++) {
		int nodeID = *iter;
		NodeX* graphNode = graph->getNodeWithID(nodeID);
		Features* graphNodeFeatures = (Features*)graphNode->getFeatures();

		RealVector input;
//		input.resize(featuresNames.size());
//		for(unsigned int i=0;i<featuresNames.size();i++)
//			input(i) = 0;

//		int index = 0;
		for(tr1::unordered_set<int>::iterator iter1 = featuresNames.begin();iter1!=featuresNames.end();iter1++) {
			Feature* tempF;
			if(graphNodeFeatures->getFeatuesSize()<6)
				tempF = graphNodeFeatures->getFeature_Sequential((*iter1));
			else
				tempF = graphNodeFeatures->getFeature((*iter1));

			if(tempF==NULL)
				input.push_back(0);
			else
				input.push_back(tempF->getValue());
		}
		inputs.push_back(input);
	}

	elapsed = TimeUtility::GetCounterMicro();
	if(twoThreads)
		Statistics::h_predictionPreparationTime+=elapsed;
	else
		Statistics::predictionPreparationTime+=elapsed;
	if(showForDebug)
		cout<<"Statistics::predictionPreparationTime: "<<elapsed<<endl;

	//employ the model to get predictions
	TimeUtility::StartCounterMicro();
	Data<RealVector> predictions;
	Data<RealVector> optPlan_predictions;
	Data<RealVector> pessPlan_predictions;
	if(toBePredictedNodes.size()>0) {
		UnlabeledData<RealVector> dataset = createUnlabeledDataFromRange(inputs);
		predictions = model(dataset.inputs());
		optPlan_predictions = optPlanModel(dataset.inputs());
		pessPlan_predictions = pessPlanModel(dataset.inputs());
	}

	if(twoThreads)
		Statistics::h_predictionTime+=TimeUtility::GetCounterMicro();
	else
		Statistics::predictionTime+=TimeUtility::GetCounterMicro();

	TimeUtility::StartCounterMicro();
	//holding previous nodes and results
//	tr1::unordered_map<string, int> nodeSigToDecision;

	//assign predictions
//	int index = 0;
	Data<RealVector>::element_range::iterator pos = predictions.elements().begin();
//		for ( = elements.begin(); pos != elements.end(); ++pos) {
//			std::cout << *pos << std::endl;
//		}
	Data<RealVector>::element_range::iterator optPlan_pos = optPlan_predictions.elements().begin();
	Data<RealVector>::element_range::iterator pessPlan_pos = pessPlan_predictions.elements().begin();

	for(vector<int>::iterator iter = toBePredictedNodes.begin();iter!=toBePredictedNodes.end();iter++)
	{
		int nodeID = *iter;
		int prediction = -1;
//		if(predictions.element(index)[0]>predictions.element(index)[1])
		if(showForDebug) {
			cout<<nodeID<<" prediction value: ("<<(*pos)[0]<<", "<<(*pos)[1]<<")"<<endl;
		}
		if((*pos)[0]>(*pos)[1])
			prediction = 0;
		else
			prediction = 1;

		nodeIDToDecision.erase(nodeID);
		nodeIDToDecision.insert(std::pair<int, int>(nodeID, prediction));
//		nodeSigToDecision.insert(std::pair<string, int>(graph->getNodeWithID(nodeID)->getFeaturesKey() ,prediction));

//		index++;

		int selectedPlanOpt = -1;
		int selectedPlanPess = -1;
		double bestScore = 0;

		for(int i = 0;i<(*pessPlan_pos).size();i++) {
			if(showForDebug)
				cout<<"(*pessPlan_pos)["<<i<<"]"<<(*pessPlan_pos)[i]<<",";
			if(bestScore<(*pessPlan_pos)[i])
			{
				bestScore = (*pessPlan_pos)[i];
				selectedPlanPess = i;
			}
		}
		if(showForDebug)
			cout<<endl;

		bestScore = 0;
		for(int i = 0;i<(*optPlan_pos).size();i++) {
			if(showForDebug)
				cout<<"(*optPlan_pos)["<<i<<"]"<<(*optPlan_pos)[i]<<",";
			if(bestScore<(*optPlan_pos)[i])
			{
				bestScore = (*optPlan_pos)[i];
				selectedPlanOpt = i;
			}
		}
		if(showForDebug)
			cout<<endl;

		if(selectedPlanOpt==-1) selectedPlanOpt = 0;
		if(selectedPlanPess==-1) selectedPlanPess = 0;
//		cout<<"prediction = "<<prediction<<", (*pessPlan_pos).size()"<<(*pessPlan_pos).size()<<", (*optPlan_pos).size() = "<<(*optPlan_pos).size()<<", bestScore = "<<bestScore<<", selectedPlan = "<<selectedPlan<<endl;

		nodeIDToPlanPess.erase(nodeID);
		nodeIDToPlanOpt.erase(nodeID);
		nodeIDToPlanPess.insert(std::pair<int, int>(nodeID, selectedPlanPess));
		nodeIDToPlanOpt.insert(std::pair<int, int>(nodeID, selectedPlanOpt));
		if(showForDebug)
			cout<<"nodeID="<<nodeID<<", selectedPlanPess="<<selectedPlanPess<<", selectedPlanOpt="<<selectedPlanOpt<<endl;

		++pos;
		++optPlan_pos;
		++pessPlan_pos;
	}

	toBePredictedNodes.clear();
	elapsed = TimeUtility::GetCounterMicro();
	if(twoThreads)
		Statistics::h_predictionPreparationTime+=elapsed;
	else
		Statistics::predictionPreparationTime+=elapsed;

	if(showForDebug)
		cout<<"Statistics::predictionPreparationTime: "<<elapsed<<endl;

	int counter = 0;
	int maxToVisit = 10;
	int numValidsFoundValid = 0;
	int numValidsFoundInvalid = 0;

	tr1::unordered_map<int, int>::iterator iterPlanPess = nodeIDToPlanPess.begin();
	tr1::unordered_map<int, int>::iterator iterPlanOpt = nodeIDToPlanOpt.begin();

	cout<<nodeIDToDecision.size()<<","<<nodeIDToPlanPess.size()<<","<<nodeIDToPlanOpt.size()<<endl;

	if(twoThreads) {
		TimeUtility::StartCounterMicro();
		cout<<"Do 2-threaded"<<endl;
		DoDividedThreaded_Advanced ddt(graph, queryGraph, domainID);
		ddt.setValues(&trainingNodeIDs, &nodeIDToDecision, &validNodeIDs, NULL, nodeIDToPlanPess, nodeIDToPlanOpt, pStatsPess, pStatsOpt, plans);

		ddt.doThreaded();
		elapsed = TimeUtility::GetCounterMicro();
		Statistics::h_optimizedSubIsoTime+=elapsed;
	}
	else
	{
		for(tr1::unordered_map<int, int>::iterator iter = nodeIDToDecision.begin();iter!=nodeIDToDecision.end();iter++,iterPlanPess++,iterPlanOpt++) {

			TimeUtility::StartCounterMicro();
			//get the result from the default function
			int valid = -1;
			if(idToValidity!=NULL)
				valid = idToValidity->find(iter->first)->second;

			//do subgraph isomorphism for current node
			int predicted = iter->second;

			int selectedPlanPess;
			if(iterPlanPess==nodeIDToPlanPess.end())
			{
				int* tPlan = pStatsPess.getMostPopularPlan();
				if(tPlan!=NULL)
					selectedPlanPess = PlansStats::getPlanNumber(plans, queryGraph->getNumOfNodes(), tPlan);
				else
					selectedPlanPess = 0;
			}
			else
			{
				selectedPlanPess = iterPlanPess->second;
			}

			int selectedPlanOpt;
			if(iterPlanOpt==nodeIDToPlanOpt.end())
			{
				int* tPlan = pStatsOpt.getMostPopularPlan();
				if(tPlan!=NULL)
					selectedPlanOpt = PlansStats::getPlanNumber(plans, queryGraph->getNumOfNodes(), tPlan);
				else
					selectedPlanOpt = 0;
			}
			else
			{
				selectedPlanOpt = iterPlanOpt->second;
			}

			NodeX* graphNode = graph->getNodeWithID(iter->first);

			//assign the source node ID that give the decision
			int sourceOfDecision = iter->first;

			//check if a similar node was visited before
			if(predicted>1) {
				int planPredicted = predicted;
				string featuresKey = graphNode->getFeaturesKey();
				sourceOfDecision = predicted-2;
				tr1::unordered_map<int, int>::iterator ToPrediction = nodeIDToDecision.find(predicted-2);
	//			tr1::unordered_map<string, int>::iterator sigToPrediction = nodeSigToDecision.find(featuresKey);
				if(ToPrediction!=nodeIDToDecision.end()) {
					predicted = ToPrediction->second;
	//				cout<<"A similar node was predicted previously."<<" inherited prediction is: "<<predicted<<endl;
				}
				else
				{
					cout<<"ERRRROR2653623"<<endl;
					exit(0);
				}

				//get the pessimistic plan
				tr1::unordered_map<int, int>::iterator ToPlanPredictionPess = nodeIDToPlanPess.find(planPredicted-2);
				if(ToPlanPredictionPess!=nodeIDToPlanPess.end()) {
					selectedPlanPess = ToPlanPredictionPess->second;
				}
				else
				{
					cout<<"ERRRROR2443623"<<endl;
					exit(0);
				}

				//get the optimistic plan
				tr1::unordered_map<int, int>::iterator ToPlanPredictionOpt = nodeIDToPlanOpt.find(planPredicted-2);
				if(ToPlanPredictionOpt!=nodeIDToPlanOpt.end()) {
					selectedPlanOpt = ToPlanPredictionOpt->second;
				}
				else
				{
					cout<<"ERRRROR2443623"<<endl;
					exit(0);
				}
			}

	//		cout<<"X"<<selectedPlan<<endl<<flush;

			counter++;
			if(showForDebug)
				cout<<counter<<"/"<<(nodeIDToDecision.size())<<". Node: "<<(iter->first)<<"predicted = "<<predicted<<", node sig = "<<graphNode->getFeaturesKey()<<",";
			if(counter%100000==0)
				cout<<"Actual: "<<counter<<"/"<<(nodeIDToDecision.size())<<endl;

			int foundValid = 0;//decision found by prediction

			Statistics::optimizedSubIsoTime+=TimeUtility::GetCounterMicro();

			//do states-based isomorphism:
			//0: do predicted + selectedPlan(predicted)
			//1: do !predicted + selectedPlan(!predicted)
			//2: do predicted + popularPlan(predicted)
			//3: do !predicted + popularPlan(!predicted)
			//4: get back to 0, but without time limit <- the normal doIterations function

			long totalElapsed = 0;
			for(int state = 0;state<5;state++) {

				if(!useDifferentPlans && state==2)
					state = 4;

				if(showForDebug) {
					if(state==0) cout<<" ";
					cout<<"[state="<<state<<"]";
				}

				int selectedPlan;

				int tempPredicted;
				long maxTime = -1;

				switch(state) {
				case 0:
					tempPredicted = predicted;
					if(predicted==0)
						selectedPlan = selectedPlanPess;
					else
						selectedPlan = selectedPlanOpt;
					break;
				case 1:
					tempPredicted = 1-predicted;
					if(tempPredicted==0)
						selectedPlan = selectedPlanPess;
					else
						selectedPlan = selectedPlanOpt;
					break;
				case 2:
					tempPredicted = predicted;
					if(tempPredicted==0) {
						selectedPlan = 0;//PlansStats::getPlanNumber(plans, queryGraph->getNumOfNodes(), pStatsPess.getMostPopularPlan());
						if(selectedPlan==-1) selectedPlan = 0;
					}
					else {
						selectedPlan = 0;//PlansStats::getPlanNumber(plans, queryGraph->getNumOfNodes(), pStatsOpt.getMostPopularPlan());
						if(selectedPlan==-1) selectedPlan = 0;
					}
					break;
				case 3:
					tempPredicted = 1-predicted;
					if(tempPredicted==0) {
						selectedPlan = 0;//PlansStats::getPlanNumber(plans, queryGraph->getNumOfNodes(), pStatsPess.getMostPopularPlan());
						if(selectedPlan==-1) selectedPlan = 0;
					}
					else {
						selectedPlan = 0;//PlansStats::getPlanNumber(plans, queryGraph->getNumOfNodes(), pStatsOpt.getMostPopularPlan());
						if(selectedPlan==-1) selectedPlan = 0;
					}
					break;
				case 4:
					tempPredicted = predicted;
					if(predicted==0)
						selectedPlan = 0;//selectedPlanPess;
					else
						selectedPlan = 0;//selectedPlanOpt;
					maxTime = -1;
					break;
				}

				if(state<4) {
					if(tempPredicted==1) {
//						maxTime = pStatsOpt.getMaxAcceptableTime(plans[selectedPlan], queryGraph->getNumOfNodes());//3332
//						maxTime = pStatsOpt.getAvgAcceptableTime(plans[selectedPlan], queryGraph->getNumOfNodes());//3332
						maxTime = pStatsOpt.getAcceptableTime(plans[selectedPlan], queryGraph->getNumOfNodes());//3332
					}
					else {
//						maxTime = pStatsPess.getMaxAcceptableTime(plans[selectedPlan], queryGraph->getNumOfNodes());//52
//						maxTime = pStatsPess.getAvgAcceptableTime(plans[selectedPlan], queryGraph->getNumOfNodes());//52
						maxTime = pStatsPess.getAcceptableTime(plans[selectedPlan], queryGraph->getNumOfNodes());//52
					}

					if(maxTime<10) maxTime = 10;
				}

				if(showForDebug)
					cout<<"maxTime="<<maxTime;

				if(tempPredicted==1) {
					//conduct optimistic search
					TimeUtility::StartCounterMicro();
					vector<int> result;
					queryGraph->isIsomorphic_OneMatch_Fast_Super_Optimistic(graph, result, plans[selectedPlan], domainID, iter->first, maxToVisit);
					if(result.size()==0)
						queryGraph->isIsomorphic_OneMatch_Fast_Super_Optimistic(graph, result, plans[selectedPlan], domainID, iter->first, maxToVisit, NULL, true);

					if(result.size()==0)
					{
						if(state<4) {
							bool b = queryGraph->isIsomorphic_OneMatch_Fast_Optimistic(graph,
									result,
									plans[selectedPlan],
									domainID,
									iter->first,
									-1,
									NULL,
									NULL,
									maxTime);

//							bool tryOpt = false;
//							bool b = queryGraph->isIsomorphic_OneMatch_Fast_Pessimistic(graph,
//															result,
//															plans[selectedPlan],
//															tryOpt,
//															domainID,
//															iter->first,
//															-1,
//															NULL,
//															NULL,
//															NULL,
//															maxTime);

							//if cannot complete within the alloted time, continue for the next for iteration
							if(!b) {
								long elapsed = TimeUtility::GetCounterMicro();//+elapsed_A1+elapsed_A2+elapsed_A3;
								Statistics::optimizedSubIsoTime+=elapsed;
								if(showForDebug) cout<<"elpsd="<<elapsed;
								totalElapsed+=elapsed;
								continue;
							}

						}
						else
						{
							queryGraph->isIsomorphic_IterativePlanModification(graph, result, plans[selectedPlan], sigToPlan, 1, domainID, iter->first, numIterationBeforePlanChanges);
						}

						Statistics::validFoundInvalid++;
						if(showForDebug)
							cout<<" validfoundinvalid ";

						numValidsFoundInvalid++;
					}
					else {
						Statistics::validFoundValid++;
						numValidsFoundValid++;
					}

					long elapsed = TimeUtility::GetCounterMicro();//+elapsed_A1+elapsed_A2+elapsed_A3;
					Statistics::optimizedSubIsoTime+=elapsed;

					if(result.size()>0)
						Statistics::timeCorrectlySpentOnValid+=elapsed;
					else
						Statistics::timeIncorrectlySpentOnValid+=elapsed;

					if(result.size()>0) {
						foundValid = 1;
						Statistics::foundValids++;
						Statistics::numValids_optimal++;
						validNodeIDs.push_back(iter->first);
					}
					else {
						Statistics::foundInvalids++;
						Statistics::numInvalids_optimal++;
						numValidsFoundInvalid--;
					}

					/*Statistics::predictedValids++;
					if(foundValid==1)
					{
						if(showForDebug) cout<<" [CORRECT]"<<", ";
						Statistics::numCorrects++;
					}
					else if(foundValid==0)
					{
						if(showForDebug) cout<<" [INCORRECT]"<<", ";
						Statistics::numIncorrects++;
						int nID = graphNode->getID();
						nodeIDToDecision.find(sourceOfDecision)->second = foundValid;
					}*/

					if(showForDebug) cout<<elapsed;
					totalElapsed+=elapsed;

					//break from the states loop
					break;
				}
				else if(tempPredicted==0)
				{
	//				if(showForDebug) {
	//					for(int i=0;i<queryGraph->getNumOfNodes();i++) {
	//						cout<<plans[selectedPlan][i]<<",";
	//					}
	//					cout<<" ";
	//				}

					//conduct pessimistic search
					TimeUtility::StartCounterMicro();
					vector<int> result;

					if(state<4) {
						bool tryOpt = false;
						bool b = queryGraph->isIsomorphic_OneMatch_Fast_Pessimistic(graph,
								result,
								plans[selectedPlan],
								tryOpt,
								domainID,
								iter->first,
								-1,
								NULL,
								NULL,
								NULL,
								maxTime);

						//if cannot complete within the alloted time, continue for the next for iteration
						if(!b) {
							long elapsed = TimeUtility::GetCounterMicro();//+elapsed_A1+elapsed_A2+elapsed_A3;
							Statistics::optimizedSubIsoTime+=elapsed;
							if(showForDebug) cout<<"elpsd="<<elapsed;
							totalElapsed+=elapsed;
							continue;
						}
					}
					else
					{
						queryGraph->isIsomorphic_IterativePlanModification(graph, result, plans[selectedPlan], sigToPlan, 0, domainID, iter->first, numIterationBeforePlanChanges);
					}

					long elapsed = TimeUtility::GetCounterMicro();
					Statistics::optimizedSubIsoTime+=elapsed;
					if(result.size()>0)
						Statistics::timeIncorrectlySpentOnInvalid+=elapsed;
					else
						Statistics::timeCorrectlySpentOnInvalid+=elapsed;

					if(result.size()>0) {
		//				cout<<"VALID NODE: "<<iter->first<<endl;
					}

					if(result.size()>0) {
						foundValid = 1;
						Statistics::foundValids++;
						Statistics::numValids_optimal++;
						validNodeIDs.push_back(iter->first);
					}
					else {
						Statistics::foundInvalids++;
						Statistics::numInvalids_optimal++;
					}

					/*Statistics::predictedInvalids++;
					if(foundValid==0)
					{
						if(showForDebug) cout<<" [CORRECT]"<<", ";
						Statistics::numCorrects++;
					}
					else if(foundValid==1)
					{
						if(showForDebug) cout<<" [INCORRECT]"<<", ";
						Statistics::numIncorrects++;
						int nID = graphNode->getID();
						nodeIDToDecision.find(sourceOfDecision)->second = foundValid;
					}*/

					if(showForDebug) cout<<elapsed;
					totalElapsed+=elapsed;

					//break from the states loop
					break;
				}
				else {
					cout<<"Error55533: no prediction is found for this node"<<endl;
					exit(0);
				}
			}

			///**********
			if(predicted==1) {
				Statistics::predictedValids++;
				if(foundValid==1)
				{
					if(showForDebug) cout<<" [CORRECT]";
					Statistics::numCorrects++;
				}
				else if(foundValid==0)
				{
					if(showForDebug) cout<<" [INCORRECT]";
					Statistics::numIncorrects++;
					int nID = graphNode->getID();
					nodeIDToDecision.find(sourceOfDecision)->second = foundValid;
				}
			} else {
				Statistics::predictedInvalids++;
				if(foundValid==0)
				{
					if(showForDebug) cout<<" [CORRECT]";
					Statistics::numCorrects++;
				}
				else if(foundValid==1)
				{
					if(showForDebug) cout<<" [INCORRECT]";
					Statistics::numIncorrects++;
					int nID = graphNode->getID();
					nodeIDToDecision.find(sourceOfDecision)->second = foundValid;
				}
			}

			if(showForDebug) cout<<", "<<totalElapsed<<endl;

			if(valid!=-1 && foundValid!=valid)
			{
				cout<<"Error64549090: "<<foundValid<<","<<valid<<endl;
				exit(0);
			}
		}
	}

	if(showValids) {
		cout<<"the liust of valid node IDs:"<<endl;
		for(vector<int>::iterator iter = validNodeIDs.begin();iter!=validNodeIDs.end();iter++) {
			cout<<*iter<<endl;
		}
	}

	delete[] invalidPlan;

	for(tr1::unordered_map<string, int*>::iterator iterPlan = sigToPlan->begin();iterPlan!=sigToPlan->end();iterPlan++) {
		delete[] iterPlan->second;
	}
	delete sigToPlan;
}

int main(int argc, char* argv[])
{
	if(false) {
		//graph 1 example
		//p-0,a-1,A-2,I-3
//		GraphX* q2 = new GraphX(1, false);
//		q2->loadFromString("t # 0\nv 0 0\nv 1 1\nv 2 1\nv 3 2\nv 4 3\ne 0 1 1\ne 0 2 1\ne 1 3 1\ne 2 4 1");
//		q2->populateNodesFeatures();
//		q2->printNodesFeatures();

//		GraphX* q1 = new GraphX(1, false);
//		q1->loadFromString("t # 0\nv 0 0\nv 1 0\nv 2 0\nv 3 0\ne 0 1 1\ne 0 2 1\ne 0 3 1");
//		q1->populateNodesFeatures();
//		q1->printNodesFeatures();

		GraphX* g = new GraphX(1, false);
		g->loadFromString("t # 0\nv 0 0\nv 1 0\nv 2 0\nv 3 0\nv 4 0\nv 5 0\nv 6 0\nv 7 1\nv 8 1\nv 9 1\nv 10 1\nv 11 1\nv 12 3\nv 13 2\nv 14 0\nv 15 3\nv 16 2\n"
				"e 0 2 1\ne 0 3 1\ne 1 7 1\ne 1 2 1\ne 2 3 1\ne 4 3 1\ne 5 3 1\ne 6 3 1\ne 6 5 1\ne 7 2 1\ne 8 2 1\ne 7 3 1\ne 8 3 1\ne 9 3 1\n"
				"e 8 5 1\ne 9 4 1\ne 10 5 1\ne 11 4 1\ne 11 5 1\ne 11 6 1\ne 11 16 1\ne 8 16 1\ne 10 15 1\ne 9 15 1\ne 8 14 1\ne 8 12 1\ne 7 13 1\n");
		g->populateNodesFeatures();
		g->printNodesFeatures();

		return 1;

	}
	/*if(false) {

		GraphX* graph1 = new GraphX(1, false);
//		graph1->loadFromString("t # 0\nv 0 13\nv 1 11\nv 2 8\nv 3 11\nv 4 11\nv 5 14\ne 0 1 1\ne 1 2 1\ne 0 3 1\ne 3 4 1\ne 4 5 1");
//		graph1->loadFromString("t # 0\nv 0 6\nv 1 16\nv 2 14\nv 3 10\nv 4 13\nv 5 10\ne 3 5 1\ne 2 5 1\ne 1 5 1\ne 0 1 1\ne 1 2 1\ne 2 3 1\ne 1 3 1\ne 3 4 1\ne 4 5 1");
//		graph1->loadFromString("# t 1\nv 0 12\nv 1 12\nv 2 13\nv 3 13\ne 0 1 1\ne 0 2 1\ne 1 3 1");
		graph1->loadFromString("# t 1\nv 0 36\nv 1 35\nv 2 36\ne 0 1 1\ne 1 2 1");

		graph1->populateNodesFeatures_FAST(2);

		vector<int* > plans = graph1->generateRandomPlans(200, 0);
		for(vector<int*>::iterator iter = plans.begin();iter!=plans.end();iter++) {
			int* plan = (*iter);
			for(int i=0;i<graph1->getNumOfNodes();i++) {
				cout<<plan[i]<<", ";
			}
			cout<<endl;
		}

//		string graphFileName = "/home/abdelhe/KAUST/Courses/PivotSubIso/Datasets/human/human";
//		string graphFileName = "/home/abdelhe/KAUST/Courses/PivotSubIso/Datasets/twitter/twitter_gaussian_25.lg";
		string graphFileName = "/home/abdelhe/KAUST/Courses/PivotSubIso/Datasets/patents";

		GraphX* graph = new GraphX(1, false);
		graph->loadFromFile(graphFileName);

//		graph->getDegreeForPercentNodes(0.99);
		graph->populateNodesFeatures_FAST(2);

		int* selectPlan = graph1->generateSelectBasedPlan(0, graph);
		plans.insert(plans.begin(), selectPlan);

//		int* p = new int[6];
//		p[0] = 0;p[1] = 1;p[2] = 2; p[3] = 5;p[4] = 4; p[5] = 3;
//		plans.push_back(p);

//		set<NodeX*>* nodes = graph->getNodesByLabel(graph1->getNodeWithID(0)->getLabel());
//		set<NodeX*>::iterator iter = nodes->begin();
//		for(int i=0;i<50;i++, iter++) {
//			NodeX* node = (*iter);
//			int bestPlan = graph1->selectBestPlan(plans, 1, graph, node->getID());
//
//			cout<<"Best plan for node: "<<node->getID()<<" is: ";
//			for(int i=0;i<graph1->getNumOfNodes();i++) {
//				cout<<plans[bestPlan][i]<<", ";
//			}
//			cout<<endl;
//		}
		NodeX* node = graph->getNodeWithID(257195);//1025247);
		long bestTime;
		int bestPlan = graph1->selectBestPlan(plans, 0, graph, node->getID(), bestTime);

		cout<<"[PESS] Best plan for node: "<<node->getID()<<" is: ";
		for(int i=0;i<graph1->getNumOfNodes();i++) {
			cout<<plans[bestPlan][i]<<", ";
		}
		cout<<endl;

		bestPlan = graph1->selectBestPlan(plans, 1, graph, node->getID(), bestTime);

		cout<<"[OPT] Best plan for node: "<<node->getID()<<" is: ";
		for(int i=0;i<graph1->getNumOfNodes();i++) {
			cout<<plans[bestPlan][i]<<", ";
		}
		cout<<endl;

		cout<<"The iterative method only:"<<endl;
		vector<int> results;
		bool tryOpt = false;
		graph1->isIsomorphic_OneMatch_Fast_Pessimistic(graph, results, p, tryOpt, 0, node->getID(), 60000, NULL, NULL);

		cout<<"simulating the case: "<<endl;
		vector<int> result;
		tr1::unordered_map<string, int*>* sigToPlan = new tr1::unordered_map<string, int*>();

		TimeUtility::StartCounterMicro();
		bool b = graph1->isIsomorphic_IterativePlanModification(graph, result, p, sigToPlan, 0, 0, node->getID(), 60000);
		long elapsed = TimeUtility::GetCounterMicro();
		cout<<b<<" elapsed = "<<elapsed<<endl;

		cout<<"DONE.";

		return 1;
	}*/
	/*if(true) {
		vector<int> results;
		int* plan = new int[3];
		plan[0] = 0;
		plan[1] = 1;
		plan[2] = 2;

		GraphX* graph1 = new GraphX(1, false);
//		graph1->loadFromString("# t 1\nv 0 0\nv 1 1\nv 2 0\nv 3 0\ne 0 1 1\ne 1 2 1\ne 1 3 1");
		graph1->loadFromString("# t 1\nv 0 36\nv 1 35\nv 2 36\ne 0 1 1\ne 1 2 1");

		GraphX* graph2 = new GraphX(1, false);
//		graph2->loadFromString("# t 1\nv 0 0\nv 1 1\nv 2 0\nv 3 1\nv 4 0\nv 5 0\ne 0 1 1\ne 1 2 1\ne 0 3 1\ne 3 4 1\ne 3 5 1");
		graph2->loadFromFile("/home/abdelhe/KAUST/Courses/PivotSubIso/Datasets/patents/patent_citations.lg");

		bool tryOpt = false;
		graph1->isIsomorphic_OneMatch_Fast_Pessimistic(graph2, results, plan , tryOpt, 0);


		cout<<"results.size() = "<<results.size();
		return 1;
	}*/
	/*if(true) {
		Data<RealVector> inputs;
		Data<RealVector> labels;
		try {
			importCSV(inputs, "data.csv", ' ');
		}
		catch (...) {
			cerr << "unable to read input data from file " <<  argv[1] << endl;
			exit(EXIT_FAILURE);
		}

		try {
			importCSV(labels, "labels.csv");
		}
		catch (...) {
			cerr << "unable to read labels from file " <<  argv[2] << endl;
			exit(EXIT_FAILURE);
		}

		RegressionDataset data(inputs, labels);
		// trainer and model
		LinearRegression trainer;
		LinearModel<> model;

		// train model
		trainer.train(model, data);

		// show model parameters
		cout << "intercept: " << model.offset() << endl;
		cout << "matrix: " << model.matrix() << endl;

//		SquaredLoss<> loss;
//		Data<RealVector> prediction = model(data.inputs());
//		cout << "squared loss: " << loss(data.labels(), prediction) << endl;
	}*/
	/*if(true)
	{
		GraphX* graph = new GraphX(1, false);
		//input graph
		graph->loadFromString("# t 1\nv 0 0\nv 1 1\nv 2 1\nv 3 1\nv 4 2\nv 5 1\nv 6 3\nv 7 1\nv 8 2\nv 9 2\nv 10 3\nv 11 1\nv 12 3\nv 13 0\ne 0 1 1\ne 0 2 1\ne 0 3 1\ne 1 4 1\ne 1 5 1\ne 1 13 1\ne 2 13 1\ne 2 7 1\ne 2 8 1\ne 3 8 1\ne 3 11 1\ne 3 9 1\ne 4 5 1\ne 5 6 1\ne 9 11 1\ne 9 12 1\ne 10 11 1");
		//query graph
//		graph->loadFromString("# t 1\nv 0 0\nv 1 1\nv 2 1\nv 3 2\nv 4 3\ne 0 1 1\ne 1 2 1\ne 1 3 1\ne 2 3 1\ne 3 4 1");
		graph->populateNodesFeatures_FAST(2);
		graph->printNodesFeatures();
		return 1;
	}*/

//	string graphFileName = "/home/abdelhe/workspace/Datasets/TurboIso/Yeast/yeast.graph";
	string graphFileName = "/home/abdelhe/KAUST/Courses/PivotSubIso/Datasets/human/human";
//	string graphFileName = "/home/abdelhe/KAUST/Courses/PivotSubIso/Datasets/cora/coraFSM.lg";
//	string graphFileName = "/home/abdelhe/KAUST/Courses/PivotSubIso/Datasets/hprd/hprd";
//	string graphFileName = "/home/abdelhe/KAUST/Courses/PivotSubIso/Datasets/contactmaps/CMgraph.lg";
//	string graphFileName = "/home/abdelhe/KAUST/Courses/PivotSubIso/Datasets/patents/patent_citations.lg";
//	string graphFileName = "/home/abdelhe/KAUST/Courses/PivotSubIso/Datasets/youtube/youtube.lg";
//	string graphFileName = "/home/abdelhe/KAUST/Courses/PivotSubIso/Datasets/twitter/twitter_gaussian_25.lg";
//	string graphFileName = "/home/abdelhe/KAUST/Courses/PivotSubIso/Datasets/weibo/weibo.lg";

//	string queriesFileName = "/home/abdelhe/KAUST/Courses/PivotSubIso/Datasets/yeast/yeast_q100_10n.lg";
//	string queriesFileName = "/home/abdelhe/KAUST/Courses/PivotSubIso/Datasets/cora/cora_q1000_4n.lg";
	string queriesFileName = "/home/abdelhe/KAUST/Courses/PivotSubIso/Datasets/human/human_q1000_10n.lg";
//	string queriesFileName = "/home/abdelhe/KAUST/Courses/PivotSubIso/Datasets/hprd/hprd_q100_10n.lg";
//	string queriesFileName = "/home/abdelhe/KAUST/Courses/PivotSubIso/Datasets/contactmaps/CMgraph_q1000_4n.lg";
//	string queriesFileName = "/home/abdelhe/KAUST/Courses/PivotSubIso/Datasets/patents/patents_q100_4n.lg";
//	string queriesFileName = "/home/abdelhe/KAUST/Courses/PivotSubIso/Datasets/youtube/youtube_q1000_5n.lg";
//	string queriesFileName = "/home/abdelhe/KAUST/Courses/PivotSubIso/Datasets/twitter/twitter_gaussian_25_q1000_4n.lg";
//	string queriesFileName = "/home/abdelhe/KAUST/Courses/PivotSubIso/Datasets/weibo/weibo_q100_8n.lg";

	string featuresFileName = "";
//	featuresFileName = "/home/abdelhe/KAUST/Courses/PivotSubIso/Datasets/human/human.features";
//	featuresFileName = "/home/abdelhe/KAUST/Courses/PivotSubIso/Datasets/twitter/twitter_gaussian_25.features";
//	featuresFileName = "/home/abdelhe/KAUST/Courses/PivotSubIso/Datasets/weibo/weibo.features";

	bool pessimistic = false;
	bool optimistic = false;
	bool optimal_defaultPlan = false;//this one uses optimistic an pessimistic using the default plan and without detect and recovery step
	bool optimal_onePlan = false;//this one uses optimistic an pessimistic using the default plan and with detect and recovery step
	bool optimal = false;//this one uses optimistic pessimistic using different plans, and selects the best for each node. It also uses detect and recovery step (one thread)
	bool optimal2t = false;//this one uses optimistic pessimistic using different plans, and selects the best for each node. It also uses detect and recovery step (two thread)
	bool threaded = false;//using two threads, one for optimistic and the other for pessimistic. the first finishes, stops the other one.
	int threadedType = 1;//1- or ML based prediction, 2- all optimistic, 3- all pessimistic
	bool best_time = false;
	bool best_deci = false;
	bool hybrid = false;//not in use!
	int minQueryID = -1;
	int maxNumQueries = -1;
	int specificQuery = -1;
	bool statsPerSingleQuery = false;
	bool showValids = false;
	int measurePopulationTime = -1;//-1 no measure, 0- measure using the fast technique, 1- measure using the (original) slow technique

	//get input graph file name
	char * argGfilename = getCmdOption(argv, argv + argc, "-graph");
	if(argGfilename)
	{
		graphFileName = string(argGfilename);
	}

	//get queries file name
	char * argQfilename = getCmdOption(argv, argv + argc, "-queries");
	if(argQfilename)
	{
		queriesFileName = string(argQfilename);
	}

	//load features feom file
	char * argFfilename = getCmdOption(argv, argv + argc, "-features");
	if(argFfilename)
	{
		featuresFileName = string(argFfilename);
	}
	else
		featuresFileName = "";

	//set pessimistic
	char * argPessSS = getCmdOption(argv, argv + argc, "-pessimistic");
	if(argPessSS)
	{
		if(argPessSS[0]=='1')
			pessimistic = true;
		else
			pessimistic = false;
	}

	//set optimistic
	char * argOptiSS = getCmdOption(argv, argv + argc, "-optimistic");
	if(argOptiSS)
	{
		if(argOptiSS[0]=='1')
			optimistic = true;
		else
			optimistic = false;
	}

	//set optimal_defaultPlan
	char * argOptDPSS = getCmdOption(argv, argv + argc, "-optimalDP");
	if(argOptDPSS)
	{
		if(argOptDPSS[0]=='1')
			optimal_defaultPlan = true;
		else
			optimal_defaultPlan = false;
	}

	//set optimal_defaultPlan
	char * argOptOneDPSS = getCmdOption(argv, argv + argc, "-optimalone");
	if(argOptOneDPSS)
	{
		if(argOptOneDPSS[0]=='1')
			optimal_onePlan = true;
		else
			optimal_onePlan = false;
	}

	//set oprimal
	char * argOptSS = getCmdOption(argv, argv + argc, "-optimal");
	if(argOptSS)
	{
		if(argOptSS[0]=='1')
			optimal = true;
		else
			optimal = false;
	}

	//set optimal 2threads
	char * argOpt2hSS = getCmdOption(argv, argv + argc, "-optimal2t");
	if(argOpt2hSS)
	{
		if(argOpt2hSS[0]=='1')
			optimal2t = true;
		else
			optimal2t = false;

		//get the threading type
		char * threadedTypeSS = getCmdOption(argv, argv + argc, "-threadedType");
		if(threadedTypeSS)
		{
			threadedType = atoi(threadedTypeSS);
		}
		else
		{
			threadedType = 1;
		}
	}

	//set hybrid
	char * argHybridSS = getCmdOption(argv, argv + argc, "-hybrid");
	if(argHybridSS)
	{
		if(argHybridSS[0]=='1')
			hybrid = true;
		else
			hybrid = false;
	}

	//set threaded
	char * argThrddSS = getCmdOption(argv, argv + argc, "-threaded");
	if(argThrddSS)
	{
		if(argThrddSS[0]=='1')
			threaded = true;
		else
			threaded = false;
	}

	//set best_time
	char * argBestTSS = getCmdOption(argv, argv + argc, "-besttime");
	if(argBestTSS)
	{
		if(argBestTSS[0]=='1')
			best_time = true;
		else
			best_time = false;
	}

	//set best_decision
	char * argBestDSS = getCmdOption(argv, argv + argc, "-bestdecision");
	if(argBestDSS)
	{
		if(argBestDSS[0]=='1')
			best_deci = true;
		else
			best_deci = false;
	}

	//set minimum query ID
	char * argMinQuery = getCmdOption(argv, argv + argc, "-minQN");
	if(argMinQuery)
	{
		minQueryID = atoi(argMinQuery);
	}

	//set maximum number of queries
	char * argMaxNumQueries = getCmdOption(argv, argv + argc, "-maxNQ");
	if(argMaxNumQueries)
	{
		maxNumQueries = atoi(argMaxNumQueries);
	}

	//set specific query number
	char * argSpecificQuery = getCmdOption(argv, argv + argc, "-specificQ");
	if(argSpecificQuery)
	{
		specificQuery = atoi(argSpecificQuery);
	}

	//set statistics shwoing time, whether per query or for the whole queries
	char * argSPQ = getCmdOption(argv, argv + argc, "-statsQuery");
	if(argSPQ)
	{
		if(argSPQ[0]=='1')
			statsPerSingleQuery = true;
		else
			statsPerSingleQuery = false;
	}

	//to print valid nodes
	char * argShowValidsSS = getCmdOption(argv, argv + argc, "-showValids");
	if(argShowValidsSS)
	{
		if(argShowValidsSS[0]=='1')
			showValids = true;
		else
			showValids = false;
	}

	//to just measure the time NS is computed for the input graph
	char * argMeasureNST = getCmdOption(argv, argv + argc, "-measureNSTime");
	if(argMeasureNST)
	{
		measurePopulationTime = atoi(argMeasureNST);
	}

	if(optimal_defaultPlan && optimal) {
		cout<<"Cannot use optimal_defaultPlan and optimal together"<<endl;
		return 1;
	}

	//create a model based on training on the first % of the candidate nodes
	cout<<"Loading graph data from: "<<graphFileName<<" ... ";

	GraphX* graph = new GraphX(1, false);//create a graph with id=its partition id
	graph->loadFromFile(graphFileName);
	cout<<"#Nodes = "<<graph->getNumOfNodes()<<", #edges = "<<graph->getNumOfEdges()<<endl;
	cout<<"DONE."<<endl;

	cout<<"Collecting statistics ...";
	graph->getDegreeForPercentNodes(0.99);
	cout<<"DONE."<<endl;

	cout<<"Populating data ..."<<flush;
	if(measurePopulationTime>-1) {
		TimeUtility::StartCounterMicro();

		if(measurePopulationTime==0)
			graph->populateNodesFeatures_FAST(2);
		else
			graph->populateNodesFeatures();

		long elapsedPopulation = TimeUtility::GetCounterMicro();
		cout<<"Population time is: "<<elapsedPopulation<<" microseconds"<<endl;
		cout<<"Exiting."<<endl;
		return 0;
	}
	else {
		if(featuresFileName.length()==0) {
			graph->populateNodesFeatures_FAST(2);
	//		graph->populateNodesFeatures();
		}
		else
		{
			//loading nodes features
			cout<<"Loading nodes features from file: "<<featuresFileName<<endl;
			graph->loadNodeFeatures(featuresFileName);
			cout<<"Loading DONE."<<endl;

			//to generate the features file
	//		graph->populateNodesFeatures_FAST(2);
	//		graph->storeNodeFeatures(featuresFileName);
	//		return 0;
		}
	}
	graph->generateFeaturesKeys();
	cout<<"Population done."<<endl;

	/*if(true) {
//		graph->printNodesFeatures();
//		graph->storeNodeFeatures("humanFeatures");

		graph->loadNodeFeatures("humanFeatures");
		graph->printNodesFeatures();
		cout<<"DONE.";
		return 0;
	}*/

	cout<<"Loading queries from file from: "<<queriesFileName;
	Queries* queries = new Queries();
	queries->loadFromFile(queriesFileName);
	cout<<queries->size()<<" queries are loaded."<<endl;

	if(!statsPerSingleQuery)
		Statistics::initialize();

	for(int i=0;i<queries->size();i++) {

		if(statsPerSingleQuery)
			Statistics::initialize();

		if(i<minQueryID) continue;
		if(maxNumQueries!=-1 && i>maxNumQueries) continue;
		if(specificQuery!=-1 && i!=specificQuery) continue;

		cout<<"Query#"<<i<<endl;

//		if(i!=0) continue;//365,3, 172

		int domainID = 0;
		GraphX* queryGraph = queries->at(i)->getGraph();
		queryGraph->populateNodesFeatures_FAST(2);
//		queryGraph->populateNodesFeatures();
//			cout<<*queryGraph<<endl;

		tr1::unordered_map<int, int>* idToValidity = new tr1::unordered_map<int, int>();

		//run in two threaded
		if(threaded)
		{
			cout<<"Threaded ..."<<endl;
			TimeUtility::StartCounterMicro();
			DoThreaded dt(graph, queryGraph, domainID);
			dt.doThreaded(NULL, true);
//			continue;
#if allowThreaded
			Statistics::interrupt = false;
#endif
			Statistics::threadedTime+=TimeUtility::GetCounterMicro();
		}

		//run default pessimistic sub iso
		if(pessimistic)
		{
			TimeUtility::StartCounterMicro();
			doDefault(graph, queryGraph, domainID, 0, idToValidity, showValids);
			Statistics::defaultPessimisticTime+=TimeUtility::GetCounterMicro();
		}

		//run default optimistic sub iso
		if(optimistic)
		{
			TimeUtility::StartCounterMicro();
			doDefault(graph, queryGraph, domainID, 1, idToValidity, showValids);
			Statistics::defaultOptimisticTime+=TimeUtility::GetCounterMicro();
		}

		//run optimal_defaultPlan
		if(optimal_defaultPlan) {
			TimeUtility::StartCounterMicro();
			doQuery(graph, queryGraph, domainID, idToValidity, showValids);
			Statistics::bestTime=Statistics::optimizedSubIsoTime+Statistics::predictionPreparationTime+Statistics::predictionTime+Statistics::trainingTime;
		}

		if(optimal_onePlan) {
			TimeUtility::StartCounterMicro();
			doQuery_advancedPlanning(graph, queryGraph, domainID, NULL, showValids, false, false, 1);//idToValidity);
			Statistics::bestTime=Statistics::optimizedSubIsoTime+Statistics::predictionPreparationTime+Statistics::predictionTime+Statistics::trainingTime;
		}

		//run optimal
		if(optimal)
		{
			TimeUtility::StartCounterMicro();
			doQuery_advancedPlanning(graph, queryGraph, domainID, NULL, showValids, false, true, 1);//idToValidity);
			Statistics::bestTime=Statistics::optimizedSubIsoTime+Statistics::predictionPreparationTime+Statistics::predictionTime+Statistics::trainingTime;
		}

		//run optimal in 2 threads
		if(optimal2t)
		{
			TimeUtility::StartCounterMicro();
//			doQuery_2threads(graph, queryGraph, domainID, NULL, showValids);
			if(threadedType==1)
				doQuery_advancedPlanning(graph, queryGraph, domainID, NULL, showValids, true, true, threadedType);
			else
				doQuery_advancedPlanning(graph, queryGraph, domainID, NULL, showValids, true, false, threadedType);
			//Statistics::hybridTime+=TimeUtility::GetCounterMicro();
			Statistics::hybridTime=Statistics::h_optimizedSubIsoTime+Statistics::h_predictionPreparationTime+Statistics::h_predictionTime+Statistics::h_trainingTime;
		}

		/*if(hybrid)
		{
			TimeUtility::StartCounterMicro();
//			doHybrid(graph, queryGraph, domainID, NULL, showValids);
//			doHybrid_Testing(graph, queryGraph, domainID, NULL, showValids);
			doHybrid_super(graph, queryGraph, domainID, NULL, showValids);
			Statistics::hybridTime=Statistics::h_optimizedSubIsoTime+Statistics::h_predictionPreparationTime+Statistics::h_predictionTime+Statistics::h_trainingTime;
		}*/

		//run best based on time
		if(best_time)
		{
			doBest(graph, queryGraph, domainID, idToValidity, showValids, true);
		}

		//run best based on time
		if(best_deci)
		{
			doBest(graph, queryGraph, domainID, idToValidity, showValids, false);
		}

		delete idToValidity;

		if(statsPerSingleQuery)
			Statistics::print();
	}
	if(!statsPerSingleQuery)
		Statistics::print();

	delete graph;

	delete queries;

	cout<<"Querying completed."<<endl<<flush;

	return 0;
}
