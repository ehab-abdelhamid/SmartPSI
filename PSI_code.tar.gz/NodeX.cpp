/*
 * NodeX.cpp
 *
 *  Created on: Mar 16, 2013
 *      Author: ehab
 */

#include <iostream>
#include <sstream>
#include <tr1/unordered_map>
#include "EdgeX.h"
#include "NodeX.h"
#include "Features.h"

NodeX::NodeX(int id, double label)
{
	this->id = id;
	this->label = label;
	std::ostringstream strs;
	strs << label;
	labelStr = strs.str();
	nodeStats = NULL;
	features = NULL;
	neighborsCount = 0;
}

NodeX::~NodeX()
{
	for( map<int, void*>::const_iterator ii=edges.begin(); ii!=edges.end(); ++ii)
    {
    	EdgeX* edge = (EdgeX*)((*ii).second);
    	delete edge;
    }
	edges.clear();

	for( map<int, void*>::const_iterator ii=revEdges.begin(); ii!=revEdges.end(); ++ii)
	{
	  	EdgeX* edge = (EdgeX*)((*ii).second);
	   	delete edge;
	}
	revEdges.clear();

	if(features!=NULL) {
		delete ((Features*)features);
	}
}

/**
 * Add an edge to this node
 * Parameters: the other node, and the edge label
 */
void NodeX::addEdge(NodeX* otherNode, double edgeLabel, int graphType)
{
	if(edges.find(otherNode->getID())!=edges.end())
		return;
	EdgeX* edge = new EdgeX(edgeLabel, otherNode);
	edges[otherNode->getID()] = edge;

	if(graphType==1)
	{
		EdgeX* edge = new EdgeX(edgeLabel, this);
		otherNode->revEdges[this->getID()] = edge;
	}
}

void NodeX::removeEdge(NodeX* otherNode, int graphType)
{
	map<int, void*>::iterator iter = edges.find(otherNode->getID());
	if(iter!=edges.end())
		delete iter->second;
	edges.erase(otherNode->getID());

	if(graphType==1)
	{
		//do somethingh here
		map<int, void*>::iterator iter = otherNode->revEdges.find(this->getID());
		if(iter!=revEdges.end())
			delete iter->second;
		revEdges.erase(this->getID());
	}
}

void* NodeX::getEdgeForDestNode(int destNodeID )
{
	map<int, void*>::iterator temp = edges.find(destNodeID);
	if(temp==edges.end())
		return NULL;
	else
		return (*temp).second;
}

bool NodeX::isItConnectedWithNodeID(int nodeID)
{
	//check node connectivity
	if(edges.find(nodeID)==edges.end())
		return false;

	return true;
}

bool NodeX::isItConnectedWithNodeID(int nodeID, double label)
{
	//check node connectivity
	map<int, void*>::iterator iter = edges.find(nodeID);
	if(iter==edges.end())
		return false;

	//check edge label
	if(((EdgeX*)iter->second)->getLabel()!=label)
		return false;

	return true;
}

/**
 * check whether the 'node' parameter in neighborhood consistent with 'this' node
 */
bool NodeX::isNeighborhoodConsistent(NodeX* node)
{
	tr1::unordered_map<double, int> labels;
	//populate labels of this node
	for(map<int, void*>::iterator iter = edges.begin();iter!=edges.end();iter++)
	{
		double otherNodeLabel = ((EdgeX*)iter->second)->getLabel();
		tr1::unordered_map<double, int>::iterator tempIter = labels.find(otherNodeLabel);
		if(tempIter==labels.end())
			labels.insert(std::pair<double, int>(otherNodeLabel, 1));
		else
		{
			int currentCount = tempIter->second;
			labels.erase(otherNodeLabel);
			labels.insert(std::pair<double, int>(otherNodeLabel, currentCount+1));
		}
	}

	//check labels against this's labels
	for(map<int, void*>::iterator iter = node->getEdgesIterator();iter!=node->getEdgesEndIterator();iter++)
	{
		double otherNodeLabel = ((EdgeX*)iter->second)->getLabel();
		tr1::unordered_map<double, int>::iterator tempIter = labels.find(otherNodeLabel);
		if(tempIter==labels.end())
			return false;
		int currentCount = tempIter->second;
		labels.erase(otherNodeLabel);
		if(currentCount>1)
			labels.insert(std::pair<double, int>(otherNodeLabel, currentCount-1));
	}

	return true;
}

void NodeX::setStats(NodeStats* nodeStats) {
	if(this->nodeStats!=NULL)
		delete this->nodeStats;
	this->nodeStats = nodeStats;
}

void NodeX::setFeatures(void* features)
{
	if(this->features!=NULL)
		delete ((Features*)this->features);
	this->features = features;
}

ostream& operator<<(ostream& os, const NodeX& n)
{
    os << n.id << '[' << n.label << "]" <<endl;
    for( map<int, void*>::const_iterator ii=n.edges.begin(); ii!=n.edges.end(); ++ii)
    {
    	EdgeX* edge = (EdgeX*)((*ii).second);
    	os<<"--"<<edge->getLabel()<<"-->"<<edge->getOtherNode()->getID()<<endl;
    }
    return os;
}

/**
 * features key: we generated it by concatenating the values to a string
 * Previously, what we do is that we generate a number that should represent the features (with some minor false positives!)
 */
void NodeX::generateFeaturesKey() {
	//long feature key
//	featuresKey = "";
	std::ostringstream strs;
	for(vector<Feature*>::iterator iter = ((Features*)features)->getVectorBegin();iter!=((Features*)features)->getVectorEnd();iter++) {
		Feature* tempFeature = (*iter);
		double tempValue = tempFeature->getValue();

		//relaxation
		if(tempValue>1000) tempValue = ((int)(tempValue/1000))*1000;
		else if(tempValue>100) tempValue = ((int)(tempValue/100))*100;
		else if(tempValue>10) tempValue=(int)tempValue;

		strs << tempValue << ",";
	}

	strs<<this->getEdgesSize();
	featuresKey = strs.str();

//	std::ostringstream strs;
//	strs << a;
//	std::string str = strs.str();
//
//	featuresKey = str;

	//short feature key
	/*double a = 0;
	for(vector<Feature*>::iterator iter = ((Features*)features)->getVectorBegin();iter!=((Features*)features)->getVectorEnd();iter++) {
		Feature* tempFeature = (*iter);
		double tempValue = tempFeature->getValue();
		a+=tempValue;
	}

	std::ostringstream strs;
	strs << a;
	std::string str = strs.str();

	featuresKey = str;*/
}
