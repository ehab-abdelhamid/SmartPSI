/*
 * utils.cpp
 *
 *  Created on: Mar 19, 2013
 *      Author: ehab
 */
#include <iostream>
#include<sstream>
#include <string.h>
#include <algorithm>
#include <math.h>
#include"utils.h"
#include "Features.h"

string intToString(int a)
{
	stringstream sstmGF;
	sstmGF << a;
	return sstmGF.str();
}

string doubleToString(double a)
{
	stringstream sstmGF;
	sstmGF << a;
	return sstmGF.str();
}

int getPos(char* str, char c)
{
	for(int i=0;i<strlen(str);i++)
	{
		if(str[i]==c)
			return i;
	}
	return -1;
}

//get time in milli seconds
long long getmsofday()
{
   struct timeval tv;
   struct timezone tz;
   gettimeofday(&tv, &tz);
   return (long long)tv.tv_sec*1000 + tv.tv_usec/1000;
}

char* getCmdOption(char ** begin, char ** end, const std::string & option)
{
    char ** itr = std::find(begin, end, option);
    if (itr != end && ++itr != end)
    {
        return *itr;
    }
    return 0;
}

bool cmdOptionExists(char** begin, char** end, const std::string& option)
{
    return std::find(begin, end, option) != end;
}

int getNumElems(vector<map<string, void*>* >* a)
{
	int counter = 0;
	for(int i=0;i<a->size();i++)
	{
		counter+=a->at(i)->size();
	}
	return counter;
}

/**
 * genertes a plan based on trials on several graph nodes using different plans and select the best plan
 */
int* selectGoodPlan(GraphX* query, GraphX* graph, int domainID) {
	set<int>* nodesList = graph->getNodeIDsByLabel(query->getNodeWithID(domainID)->getLabel());

	int numTrialNodes = 5;
	if(nodesList->size()>500)
		numTrialNodes = 10;

	Features* queryNodeFeatures = (Features*)query->getNodeWithID(domainID)->getFeatures();
	tr1::unordered_set<NodeX* > trialNodes;

	long numIterationBeforePlanChanges = query->getNumOfNodes()*10000;

	//select the trial nodes
	int nodesCount = 0;
	for(set<int>::iterator tempIter = nodesList->begin();tempIter!=nodesList->end();tempIter++)
	{
		NodeX* graphNode = graph->getNodeWithID(*tempIter);
		Features* graphNodeFeatures = (Features*)graphNode->getFeatures();
		if(queryNodeFeatures->isSatisfiedBy(graphNodeFeatures)==-1)
			continue;

		trialNodes.insert(graphNode);
		nodesCount++;
		if(nodesCount==numTrialNodes)
			break;
	}

	//iterate over plans until finding a good one
	int numMaxPlans = 10;
	int numPlans = 0;
	int* invalidPlan = query->generateSelectBasedPlan(domainID, graph);
	int* bestPlan = new int[query->getNumOfNodes()];
	for(int i=0;i<query->getNumOfNodes();i++) {
		bestPlan[i] = invalidPlan[i];
	}

	set<long> check;
	long bestWeight = -1;

	while(true) {
//		cout<<"Current plan: ";
//		for(int i=0;i<query->getNumOfNodes();i++)
//			cout<<invalidPlan[i]<<",";
//		cout<<endl;

		int v = 0;
		for(int i=0;i<query->getNumOfNodes();i++) {
			v = v + (i*invalidPlan[i]);
		}

		if(check.find(v)!=check.end() || numPlans==numMaxPlans) {
			delete[] invalidPlan;
			break;
		}
		else
			check.insert(v);

		int* totalWeights = new int[query->getNumOfNodes()];
		for(int i=0;i<query->getNumOfNodes();i++)
			totalWeights[i]=0;

		for(tr1::unordered_set<NodeX* >::iterator iter = trialNodes.begin();iter!=trialNodes.end();iter++) {
			NodeX* node = (*iter);

			int* weights = new int[query->getNumOfNodes()];
			for(int i=0;i<query->getNumOfNodes();i++)
				weights[i] = 0;

			vector<int> results;

			query->isIsomorphic_OneMatch_Fast_Pessimistic_2(graph, results, invalidPlan, domainID, node->getID(), numIterationBeforePlanChanges, NULL, NULL, weights);

			for(int i=0;i<query->getNumOfNodes();i++)
				totalWeights[i]+=weights[i];

			delete[] weights;
		}

		int currentWeight = 0;
		for(int i=0;i<query->getNumOfNodes();i++)
			currentWeight+=totalWeights[i];

		if(currentWeight<bestWeight || bestWeight==-1) {
			int* temp = bestPlan;
			bestPlan = invalidPlan;
			invalidPlan = temp;
			bestWeight = currentWeight;
		}

//		cout<<"Current weight = "<<currentWeight<<" vs Best weight = "<<bestWeight<<endl;

//		cout<<"Best plan: ";
//		for(int i=0;i<query->getNumOfNodes();i++)
//			cout<<bestPlan[i]<<",";
//		cout<<endl;

		delete[] invalidPlan;

		numPlans++;
		invalidPlan = query->generateWeightsBasedPlan(domainID, totalWeights, graph);
	}

	return bestPlan;
}

//*******************************
//Plans statistics
//*******************************
PlanTimesPair::PlanTimesPair(int* plan, int planLength) {
	this->planLength = planLength;
	this->plan = plan;
	long sig = PlanTimesPair::getSignature(plan, planLength);
}

void PlanTimesPair::addTime(long t) {
	time.push_back(t);
}

long PlanTimesPair::getMaxAcceptableTime() {
	long maxTime = 0;

	for(vector<long>::iterator iter = time.begin();iter!=time.end();iter++) {
		if(maxTime<(*iter))
			maxTime = (*iter);
	}

	return maxTime*2;
}

long PlanTimesPair::getAvgAcceptableTime() {
	long sum = 0;

	for(vector<long>::iterator iter = time.begin();iter!=time.end();iter++) {
		sum+=(*iter);
	}

	return sum/time.size()*2;
}

/**
 * get the maximum number of a specific percentage of the times list (then multiply by 2)
 */
long PlanTimesPair::getTopPercentileTime(double percentile) {
	vector<long> ordered;
	for(vector<long>::iterator iter = time.begin();iter!=time.end();iter++) {
		ordered.push_back((*iter));
	}
	std::sort(ordered.begin(), ordered.end());

	double lastPosition = ordered.size()*percentile;

	return ordered[lastPosition]*2;
}

long PlanTimesPair::getSignature(int* plan, int length) {
	long sig = 0;
	for(int i=0;i<length;i++) {
		sig+=(pow(10, i)*plan[i]);
	}
	return sig;
}

void PlansStats::addPlan(int* plan, int length) {
	long tempSig = PlanTimesPair::getSignature(plan, length);
	PlanTimesPair* ptp = new PlanTimesPair(plan, length);
	plans.insert(std::pair<long, PlanTimesPair*>(tempSig, ptp));
}

void PlansStats::addTime(int* plan, int length, long time) {
	long tempSig = PlanTimesPair::getSignature(plan, length);
	tr1::unordered_map<long, PlanTimesPair* >::iterator iter = plans.find(tempSig);
	if(iter==plans.end())
		return;
	iter->second->addTime(time);
}

long PlansStats::getMaxAcceptableTime(int* plan, int length) {
	long sig = PlanTimesPair::getSignature(plan, length);
	tr1::unordered_map<long, PlanTimesPair* >::iterator iter = plans.find(sig);
	if(iter==plans.end())
		return -1;

	PlanTimesPair* ptp = iter->second;
	return ptp->getMaxAcceptableTime();
}

long PlansStats::getAvgAcceptableTime(int* plan, int length) {
	long sig = PlanTimesPair::getSignature(plan, length);
	tr1::unordered_map<long, PlanTimesPair* >::iterator iter = plans.find(sig);
	if(iter==plans.end())
		return -1;

	PlanTimesPair* ptp = iter->second;
	return ptp->getAvgAcceptableTime();
}

long PlansStats::getAcceptableTime(int* plan, int length) {
	long sig = PlanTimesPair::getSignature(plan, length);
	tr1::unordered_map<long, PlanTimesPair* >::iterator iter = plans.find(sig);
	if(iter==plans.end())
		return -1;

	PlanTimesPair* ptp = iter->second;
	return ptp->getTopPercentileTime(0.90);
}

int PlansStats::getPlanNumber(vector<int*> plans, int length, int* plan) {

	if(plan==NULL) return -1;

	for(int j = 0;j<plans.size();j++) {
		bool found = true;
		for(int i=0;i<length;i++) {
			if(plan[i]!=plans[j][i]) {
				found = false;
				break;
			}
		}
		if(found) return j;
	}
	return -1;
}

int* PlansStats::getMostPopularPlan() {
	int popularity = 0;
	int* popularPlan  = NULL;
	for(tr1::unordered_map<long, PlanTimesPair* >::iterator iter = plans.begin();iter!=plans.end();iter++) {
		PlanTimesPair* ptp = iter->second;
		if(popularity<ptp->getNUmberofTimes()) {
			popularity=ptp->getNUmberofTimes();
			popularPlan=ptp->getPlan();
		}
	}
	return popularPlan;
}
