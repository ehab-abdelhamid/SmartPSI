/*
 * BasicIndex.h
 *
 *  Created on: May 29, 2016
 *      Author: abdelhe
 */

#ifndef BASICINDEX_H_
#define BASICINDEX_H_

#include "Queries.h"

class BasicIndex
{
private:
	Queries* queries;

public:
	void setQueries(Queries* q) {this->queries = q;}
	void buildIndex(char* );
	void loadIndex(char* );
	bool parseData(istream& data);
	void printIndex();
	int* getOrderForQuery(Query* q);
};



#endif /* BASICINDEX_H_ */
