/*
 * BasicIndex.cpp
 *
 *  Created on: May 29, 2016
 *      Author: abdelhe
 */

#include <iostream>
#include <fstream>
#include <stdlib.h>
#include "BasicIndex.h"

void BasicIndex::buildIndex(char* fileName)
{
	ofstream myfile;
	myfile.open (fileName);

	//loop over queries
	for(int i=0;i<queries->size();i++)
	{
		Query* query = queries->at(i);
		myfile << (*query->getGraph());
		//output best plan
		int* bestPlan =  query->getBestPlan();
		myfile<<"p";
		for(int j=0;j<query->getGraph()->getNumOfNodes();j++)
			myfile<<bestPlan[j]<<",";
		myfile<<endl;
	}

	myfile.close();
}

void BasicIndex::loadIndex(char* fileName)
{
	queries = new Queries();

	ifstream myfile;
	myfile.open (fileName);

	if(!myfile)
	{
		cout << "While opening the index file: "<<fileName<<" an error is encountered" << endl;
		return;
	}

	bool b = parseData(myfile);
	if(!b)
	{
		cout<<"Could not parse file!"<<endl;
	}
}

bool BasicIndex::parseData(istream& data)
{
	GraphX* currentGraph = 0;
	int* currentPlan = 0;

	while (true)
	{
		char ch;
		data>>ch;

		if(data.eof()) break;

		//graphs separator
		if(ch=='t')
		{
			if(currentGraph!=0)
			{
				Query* query = new Query(currentGraph);
				query->setBestPlan(currentPlan);
				delete[] currentPlan;
				queries->addQuery(query);

//				query->print();
			}

			currentGraph = new GraphX();

			data>>ch;
			int temp;
			data>>temp;
		}
		//to add nodes
		else if(ch=='v')
		{
			int id;
			double label;
			data>>id;
			data>>label;
			currentGraph->AddNode(id, label);
		}
		//to add edges
		else if(ch=='e')
		{
			int id1;
			int id2;
			double label;
			data>>id1;
			data>>id2;
			data>>label;
			currentGraph->addEdge(id1, id2, label);
		}
		else if(ch=='p')
		{
			int graphSize = currentGraph->getNumOfNodes();
			currentPlan = new int[graphSize];
			for(int i=0;i<graphSize;i++)
			{
				data>>currentPlan[i];
				data>>ch;
			}
		}
		else
		{
			cout<<"Error!";
			exit(0);
		}
	}

	if(currentGraph->getNumOfNodes()>0)
	{
		Query* query = new Query(currentGraph);
		queries->addQuery(query);
		query->setBestPlan(currentPlan);
		delete[] currentPlan;
	}

	return true;
}

int* BasicIndex::getOrderForQuery(Query* q)
{
	int graphSize = q->getGraph()->getNumOfNodes();
	int* order = new int[graphSize];

	//create a vector of found orders
	vector<int>** weights = new vector<int>*[graphSize];
	for(int i=0;i<graphSize;i++)
	{
		weights[i] = new vector<int>();
	}


	for(int i = 0;i<queries->size();i++)
	{
		Query* indexQ = queries->at(i);

		if(!q->getGraph()->canSatisfy(indexQ->getGraph()))
			continue;

		vector<map<int, int>* > result;
		tr1::unordered_map<int, tr1::unordered_set<int>*> domains_values;

		indexQ->getGraph()->isIsomorphic(q->getGraph(), result, domains_values, 0, -1, -1, false);

//		cout<<"#results = "<<result.size()<<endl;

		for(int j = 0;j<result.size();j++)
		{
			map<int, int>* m = result.at(j);
			for(map<int, int>::iterator iter = m->begin();iter!=m->end();iter++)
			{
				int indexQNodeID = iter->first;
				int qNodeID = iter->second;

				//get the order of the index query node ID
				int* bestPlan = indexQ->getBestPlan();

				int l = 0;
				for(;l<indexQ->getGraph()->getNumOfNodes();l++)
				{
					if(bestPlan[l]==indexQNodeID)
						break;
				}
				if(l>=indexQ->getGraph()->getNumOfNodes())
				{
					cout<<"Error: this node is not found in the order!: "<<indexQNodeID<<endl;
					exit(0);
				}

				weights[qNodeID]->push_back(l);
			}
		}
	}

	double* avg = new double[graphSize];

	//get the avg order per node
	for(int i=0;i<graphSize;i++)
	{
		avg[i] = 0;
		for(int j=0;j<weights[i]->size();j++)
		{
			avg[i]+=weights[i]->at(j);
//			cout<<weights[i]->at(j)<<",";
		}

		if(weights[i]->size()>0)
			avg[i] = avg[i]/weights[i]->size();
		else
			avg[i] = 10000;//set a high average value for nodes not found earlier in the training order

//		cout<<i<<": avg is: "<<avg[i]<<endl;
	}

	for(int i=0;i<graphSize;i++)
	{
		delete weights[i];
	}
	delete[] weights;

	//assign the orders here

	int indexOrder = 0;

	//select the first node with the lowest average
	double min = avg[0];
	int minIndex = 0;
	for(int i = 1;i< graphSize;i++)
	{
		if(avg[i]<min)
		{
			min = avg[i];
			minIndex = i;
		}
	}

	order[indexOrder] = minIndex;

	tr1::unordered_set<int> visitedNodeIDs;
	visitedNodeIDs.insert(minIndex);

	//get next connections
	tr1::unordered_set<int> availableNodeIDs;
	while(true)
	{
		//update availableNodeIDs with neighbors of the most recently selected node
		NodeX* node = q->getGraph()->getNodeWithID(order[indexOrder]);
		for(map<int, void*>::iterator iter=node->getEdgesIterator();iter!=node->getEdgesEndIterator();iter++)
		{
			int destNodeID = iter->first;

			//do not add already visited nodes
			if(visitedNodeIDs.find(destNodeID)!=visitedNodeIDs.end())
				continue;

			availableNodeIDs.insert(destNodeID);
		}

		//break when no more available nodes are available
		if(availableNodeIDs.size()==0)
			break;

		//select a node with lowest weight from availableNodeIDs
		tr1::unordered_set<int>::iterator iter = availableNodeIDs.begin();
		int minNodeID = *iter;
		double minAvg = avg[minNodeID];
		iter++;
		for(;iter!=availableNodeIDs.end();iter++) {
			int tempMinNodeID = *iter;
			double tempMinAvg = avg[minNodeID];

			if(tempMinAvg>minAvg) {
				minNodeID = tempMinNodeID;
				minAvg = tempMinAvg;
			}
		}

		//assign the order
		indexOrder++;
		order[indexOrder] = minNodeID;
		availableNodeIDs.erase(minNodeID);
		visitedNodeIDs.insert(minNodeID);
	}

	if(indexOrder!=(graphSize-1))
	{
		cout<<"Error2746: "<<indexOrder<<"!="<<graphSize<<endl;
		exit(0);
	}

	delete[] avg;

	return order;
}

void BasicIndex::printIndex()
{
	cout<<"#Queries = "<<queries->size()<<endl;

	for(int i=0;i<queries->size();i++)
	{
		Query* q = queries->at(i);
		cout<<*q->getGraph()<<endl;
		cout<<"Best plan: ";
		int* plan = q->getBestPlan();
		for(int j=0;j<q->getGraph()->getNumOfNodes();j++)
		{
			cout<<plan[j]<<",";
		}
		cout<<endl;
	}

}
