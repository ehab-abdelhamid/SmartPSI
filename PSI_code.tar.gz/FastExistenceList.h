/*
 * FastExistenceList.h
 *
 *  Created on: Oct 26, 2016
 *      Author: abdelhe
 */

#ifndef FASTEXISTENCELIST_H_
#define FASTEXISTENCELIST_H_

#include "NodeX.h"

class FastExistenceList {
private:
	NodeX** list;
	int size;
	int pos;

public:
	FastExistenceList(int size);
	~FastExistenceList();
	bool exists(NodeX* a);
	void add(NodeX* a);
	void remove(NodeX* a);
	void clear();
	void print();
};



#endif /* FASTEXISTENCELIST_H_ */
