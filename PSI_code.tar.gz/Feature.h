/*
 * Feature.h
 *
 *  Created on: Sep 27, 2016
 *      Author: abdelhe
 */

#ifndef FEATURE_H_
#define FEATURE_H_

#include <string>

using namespace std;

class Feature {
private:
	int name;
	double value;

public:
	Feature(int name, double value) {this->name = name; this->value = value; }
	int getName() { return name; }
	double getValue() { return value; }
	void updateValue(double value) { this->value = value; }
	void print(ostream& out) { out<<name<<":"<<value; }
};



#endif /* FEATURE_H_ */
