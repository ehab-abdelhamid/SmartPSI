/*
 * Statistics.h
 *
 *  Created on: Jan 16, 2017
 *      Author: abdelhe
 */

#ifndef STATISTICS_H_
#define STATISTICS_H_

class Statistics {
public:
	static int predictedValids;
	static int predictedInvalids;
	static int numCorrects;
	static int numIncorrects;
	static int trueValids;
	static int trueInvalids;
	static int foundValids;
	static int foundInvalids;
	static int validFoundInvalid;
	static int validFoundValid;
	static long defaultPessimisticTime;
	static long defaultOptimisticTime;
	static long predictionPreparationTime;
	static long predictionTime;
	static long timeCorrectlySpentOnValid;
	static long timeIncorrectlySpentOnValid;
	static long timeCorrectlySpentOnInvalid;
	static long timeIncorrectlySpentOnInvalid;
	static long bestTime;
	static long trainingTime;
	static long optimizedSubIsoTime;
	static long threadedTime;
	static long best_timeTime;
	static long best_desisionTime;
	static bool interrupt;
	static int numValids_threaded;
	static int numInvalids_threaded;
	static int numValids_optimal;
	static int numInvalids_optimal;
	//----------HYBRID
	static long h_predictionPreparationTime;
	static long h_trainingTime;
	static long h_predictionTime;
	static long h_optimizedSubIsoTime;
	static long h_numCorrects;
	static long h_numIncorrects;
	static long h_numValids;
	static long h_numInvalids;
	static long hybridTime;
	static long numInconfidentDecisions;
	static long h_nmMLDecided;
	static long h_nmCached;
	//---OPTIMISTIC
	static long opt_validFoundInvalid;
	static long opt_numValids;
	static long opt_numInvalids;

	static void initialize() {
		predictedValids = 0;
		predictedInvalids = 0;
		numCorrects = 0;
		numIncorrects = 0;
		trueValids = 0;
		trueInvalids = 0;
		foundValids = 0;
		foundInvalids = 0;
		validFoundInvalid = 0;
		validFoundValid = 0;
		defaultPessimisticTime = 0;
		defaultOptimisticTime = 0;
		predictionPreparationTime = 0;
		predictionTime = 0;
		timeCorrectlySpentOnValid = 0;
		timeIncorrectlySpentOnValid = 0;
		timeCorrectlySpentOnInvalid = 0;
		timeIncorrectlySpentOnInvalid = 0;
		bestTime = 0;
		trainingTime = 0;
		optimizedSubIsoTime = 0;
		threadedTime = 0;
		best_timeTime = 0;
		best_desisionTime = 0;
		interrupt = false;
		numValids_threaded = 0;
		numInvalids_threaded = 0;
		numValids_optimal = 0;
		numInvalids_optimal = 0;
		h_predictionPreparationTime = 0;
		h_trainingTime = 0;
		h_predictionTime = 0;
		h_optimizedSubIsoTime = 0;
		h_numCorrects = 0;
		h_numIncorrects = 0;
		h_numValids = 0;
		h_numInvalids = 0;

		hybridTime = 0;
		numInconfidentDecisions = 0;
		h_nmMLDecided = 0;
		h_nmCached = 0;

		opt_validFoundInvalid = 0;
		opt_numValids = 0;
		opt_numInvalids = 0;

	}

	static void print() {
		cout<<"---------------------------------"<<endl;
		cout<<"------------ RESULTS ------------"<<endl;
		cout<<"---------------------------------"<<endl;
		cout<<"trueValids =        "<<trueValids<<endl;
		cout<<"trueInvalids =      "<<trueInvalids<<endl;
		cout<<"foundValids =       "<<foundValids<<endl;
		cout<<"foundInvalids =     "<<foundInvalids<<endl;
		cout<<"predictedValids =   "<<predictedValids<<endl;
		cout<<"predictedInvalids = "<<predictedInvalids<<endl;
		cout<<"---------------------------------"<<endl;
		cout<<"numValids_threaded =   "<<numValids_threaded<<endl;
		cout<<"numInvalids_threaded = "<<numInvalids_threaded<<" <-- this could be a little bit less than the correct value due to threading!"<<endl;
		cout<<"--"<<endl;
		cout<<"numValids_optimal =    "<<numValids_optimal<<endl;
		cout<<"numInvalids_optimal =  "<<numInvalids_optimal<<endl;
		cout<<"---------------------------------"<<endl;
		cout<<"validFoundInvalid = "<<validFoundInvalid<<endl;
		cout<<"validFoundValid =    "<<validFoundValid<<endl;
		cout<<"---------------------------------"<<endl;
		cout<<"-OPTIMISTIC:---------------------"<<endl;
		cout<<"#VALIDS:                                "<<opt_numValids<<endl;
		cout<<"#INVALIDS:                              "<<opt_numInvalids<<endl;
		cout<<"Valids found invalid at the super step: "<<opt_validFoundInvalid<<endl;
		cout<<"---------------------------------"<<endl;
		cout<<"-OPTIMAL:------------------------"<<endl;
		cout<<"Training time =    "<<trainingTime<<endl;
		cout<<"pred. prep. time = "<<predictionPreparationTime<<endl;
		cout<<"pred. time =       "<<predictionTime<<endl;
		cout<<"Opt. time =        "<<optimizedSubIsoTime<<
				"[CV="<<timeCorrectlySpentOnValid<<
				" ,IV="<<timeIncorrectlySpentOnValid<<
				", CI="<<timeCorrectlySpentOnInvalid<<
				", II="<<timeIncorrectlySpentOnInvalid<<"]"<<endl;
		cout<<"---------------------------------"<<endl;
		cout<<"numCorrects = "<<numCorrects<<endl;
		cout<<"numIncorrects = "<<numIncorrects<<endl;
		cout<<"Accuracy = "<<(((double)numCorrects)/(numCorrects+numIncorrects))<<endl;
		cout<<"-HYBRID:------------------------"<<endl;
		cout<<"[H] Training time =    "<<h_trainingTime<<endl;
		cout<<"[H] pred. prep. time = "<<h_predictionPreparationTime<<endl;
		cout<<"[H] pred. time =       "<<h_predictionTime<<endl;
		cout<<"[H] Opt. time =        "<<h_optimizedSubIsoTime<<endl;
		cout<<"[H] #Inconfidents    = "<<numInconfidentDecisions<<endl;
		cout<<"[H] #ML decision     = "<<h_nmMLDecided<<endl;
		cout<<"[H] #Cached          = "<<h_nmCached<<endl;
		cout<<"---------------------------------"<<endl;
		cout<<"[H] numValids = "<<h_numValids<<endl;
		cout<<"[H] numInvalids = "<<h_numInvalids<<endl;
		cout<<"[H] numCorrects = "<<h_numCorrects<<endl;
		cout<<"[H] numIncorrects = "<<h_numIncorrects<<endl;
		cout<<"[H] Accuracy = "<<(((double)h_numCorrects)/(h_numCorrects+h_numIncorrects))<<endl;
		cout<<"---------------------------------"<<endl;
		cout<<"Default [Pess] time = "<<defaultPessimisticTime<<endl;
		cout<<"Default [Opti] time = "<<defaultOptimisticTime<<endl;
		cout<<"Best time =           "<<bestTime<<endl;
		cout<<"Threaded time =       "<<threadedTime<<endl;
		cout<<"Hybrid time =         "<<hybridTime<<endl;
		cout<<"Lower bound (time) =  "<<best_timeTime<<endl;
		cout<<"Lower bound (deci) =  "<<best_desisionTime<<endl;
	}
};



#endif /* STATISTICS_H_ */
