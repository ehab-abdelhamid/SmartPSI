/*
 * Query.h
 *
 *  Created on: Oct 22, 2015
 *      Author: abdelhe
 */

#ifndef QUERY_H_
#define QUERY_H_

#include "GraphX.h"

class Query
{
private:
	long bestTime;
	long worstTime;
	int* bestPlan = 0;
	int* worstPlan = 0;
	GraphX* graph;
	int id;

public:
	Query(GraphX* );
	~Query();
	void addPlan(int* , int, vector<int*>& , int maxPrefix, GraphX* inputGraph);

	GraphX* getGraph();
	vector<int* > getPossiblePlans(int maxPrefix, GraphX* inputGraph);
	vector<int* > getPossiblePlans_restricted(int startNodeID, int maxPrefix, GraphX* inputGraph);
	void printPlans(vector<int* >);

	void initWorstBestTimes() {worstTime = -1;bestTime = 10000000;}
	void setBestTime(long bt) {bestTime = bt;}
	long getBestTime() {return bestTime;}
	void setWorstTime(long wt) {worstTime = wt;}
	long getWorstTime() {return worstTime;}

	void setBestPlan(int* bp);
	int* getBestPlan() {return bestPlan;}
	void setWorstPlan(int* wp);
	int* getWorstPlan() {return worstPlan;}

	void print();
	int getID() { return id; }
};



#endif /* QUERY_H_ */
