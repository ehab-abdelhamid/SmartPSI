/*
 * Queries.cpp
 *
 *  Created on: Oct 22, 2015
 *      Author: abdelhe
 */

#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <sstream>
#include "Queries.h"
#include "TimeUtility.h"
#include "Features.h"

/**
 * my version of fann_run
 */
/*fann_type * my_fann_run(struct fann * ann, fann_type * input)
{
	struct fann_neuron *neuron_it, *last_neuron, *neurons, **neuron_pointers;
	unsigned int i, num_connections, num_input, num_output;
	fann_type neuron_sum, *output;
	fann_type *weights;
	struct fann_layer *layer_it, *last_layer;
	unsigned int activation_function;
	fann_type steepness;

	// store some variabels local for fast access
	struct fann_neuron *first_neuron = ann->first_layer->first_neuron;

	fann_type max_sum;

	// first set the input
	num_input = ann->num_input;
	for(i = 0; i != num_input; i++)
	{
		first_neuron[i].value = input[i];
	}
	// Set the bias neuron in the input layer
	(ann->first_layer->last_neuron - 1)->value = 1;

	last_layer = ann->last_layer;
	for(layer_it = ann->first_layer + 1; layer_it != last_layer; layer_it++)
	{
		last_neuron = layer_it->last_neuron;
		for(neuron_it = layer_it->first_neuron; neuron_it != last_neuron; neuron_it++)
		{
			if(neuron_it->first_con == neuron_it->last_con)
			{
				// bias neurons
				neuron_it->value = 1;
				continue;
			}

			activation_function = neuron_it->activation_function;
			steepness = neuron_it->activation_steepness;

			neuron_sum = 0;
			num_connections = neuron_it->last_con - neuron_it->first_con;
			weights = ann->weights + neuron_it->first_con;

			if(ann->connection_rate >= 1)
			{
				neurons = (layer_it - 1)->first_neuron;

				// unrolled loop start
				i = num_connections & 3;	// same as modulo 4
				switch (i)
				{
					case 3:
						neuron_sum += fann_mult(weights[2], neurons[2].value);
					case 2:
						neuron_sum += fann_mult(weights[1], neurons[1].value);
					case 1:
						neuron_sum += fann_mult(weights[0], neurons[0].value);
					case 0:
						break;
				}

				for(; i != num_connections; i += 4)
				{
					neuron_sum +=
						fann_mult(weights[i], neurons[i].value) +
						fann_mult(weights[i + 1], neurons[i + 1].value) +
						fann_mult(weights[i + 2], neurons[i + 2].value) +
						fann_mult(weights[i + 3], neurons[i + 3].value);
				}
				// unrolled loop end

//				*
//				 * for(i = 0;i != num_connections; i++){
//				 * printf("%f += %f*%f, ", neuron_sum, weights[i], neurons[i].value);
//				 * neuron_sum += fann_mult(weights[i], neurons[i].value);
//				 * }
			}
			else
			{
				neuron_pointers = ann->connections + neuron_it->first_con;

				i = num_connections & 3;	// same as modulo 4
				switch (i)
				{
					case 3:
						neuron_sum += fann_mult(weights[2], neuron_pointers[2]->value);
					case 2:
						neuron_sum += fann_mult(weights[1], neuron_pointers[1]->value);
					case 1:
						neuron_sum += fann_mult(weights[0], neuron_pointers[0]->value);
					case 0:
						break;
				}

				for(; i != num_connections; i += 4)
				{
					neuron_sum +=
						fann_mult(weights[i], neuron_pointers[i]->value) +
						fann_mult(weights[i + 1], neuron_pointers[i + 1]->value) +
						fann_mult(weights[i + 2], neuron_pointers[i + 2]->value) +
						fann_mult(weights[i + 3], neuron_pointers[i + 3]->value);
				}
			}
			neuron_sum = fann_mult(steepness, neuron_sum);

			max_sum = 150/steepness;
			if(neuron_sum > max_sum)
				neuron_sum = max_sum;
			else if(neuron_sum < -max_sum)
				neuron_sum = -max_sum;

			neuron_it->sum = neuron_sum;

			fann_activation_switch(activation_function, neuron_sum, neuron_it->value);
		}
	}

	// set the output
	output = ann->output;
	num_output = ann->num_output;
	neurons = (ann->last_layer - 1)->first_neuron;
	for(i = 0; i != num_output; i++)
	{
		output[i] = neurons[i].value;
	}
	return ann->output;
}*/

/**
 * utility function to scale values given some pre-computed parameters
 */
/*void scale_data_using_factors(fann_type ** data, unsigned int num_data, unsigned int num_elem, fann_type new_min, fann_type new_max, fann_type old_min, fann_type old_max, fann_type new_span, fann_type factor) {
	unsigned int dat, elem;
	fann_type temp;

	for(dat = 0; dat < num_data; dat++)
	{
		for(elem = 0; elem < num_elem; elem++)
		{
			temp = (data[dat][elem] - old_min) * factor + new_min;
			if(temp < new_min)
			{
				data[dat][elem] = new_min;
//				printf("error %f < %f\n", temp, new_min);
			}
			else if(temp > new_max)
			{
				data[dat][elem] = new_max;
//				printf("error %f > %f\n", temp, new_max);
			}
			else
			{
				data[dat][elem] = temp;
			}
		}
	}
}*/

/*void scale_fanns_using_factors(fann_type * data, unsigned int num_elem, fann_type new_min, fann_type new_max, fann_type old_min, fann_type old_max, fann_type new_span, fann_type factor) {
	unsigned int dat, elem;
	fann_type temp;

	for(elem = 0; elem < num_elem; elem++)
	{
		temp = (data[elem] - old_min) * factor + new_min;
		if(temp < new_min)
		{
			data[elem] = new_min;
		}
		else if(temp > new_max)
		{
			data[elem] = new_max;
		}
		else
		{
			data[elem] = temp;
		}
	}
}*/

/**
 * print features as an ARFF file
 */
/*void printAsARFF(ostream& out, ostream& out_map, tr1::unordered_set<string>& featuresNames, vector<Features* >& allFeatures) {
	cout<<"printing to a file ...";
	out<<"@RELATION data"<<endl;
	for(tr1::unordered_set<string>::iterator iter = featuresNames.begin();iter!=featuresNames.end();iter++) {
		if((*iter).compare("Time")==0) continue;
		out<<"@ATTRIBUTE "<<(*iter)<<" NUMERIC"<<endl;
	}
	out<<"@ATTRIBUTE Time NUMERIC"<<endl;

	out<<endl;
	out<<"@DATA"<<endl;

	int count = 1;
	vector<Features* >::iterator iter = allFeatures.begin();
	for(;iter!=allFeatures.end();iter++) {
		Features* fs = *iter;
		string name = "Time";
		fs->printAsARFF(out, featuresNames, name);
		out<<endl;

		//the query mapping file
		out_map<<count<<" "<<fs->getQueryID()<<" ";
		int* plan = fs->getPlan();
		for(int i=0;i<fs->getPlanLength();i++) {
			out_map<<plan[i]<<",";
		}
		out_map<<endl;

		count++;
	}
	cout<<"DONE."<<endl;
}*/

/**
 * print features as an ARFF file
 */
/*void printAsFANNCSV(ostream& out, ostream& out_map, tr1::unordered_set<string>& featuresNames, vector<Features* >& allFeatures, char c) {
//	cout<<"printing to a file ...";

	out<<allFeatures.size()<<" "<<"24"<<" "<<1<<endl;//48

	int count = 1;
	vector<Features* >::iterator iter = allFeatures.begin();
	for(;iter!=allFeatures.end();iter++) {
		Features* fs = *iter;
		string str = "Time";
		fs->printAsFANNCSV(out, featuresNames, c, str);
		out<<endl;

		//the query mapping file
		out_map<<count<<" "<<fs->getQueryID()<<" ";
		int* plan = fs->getPlan();
		for(int i=0;i<fs->getPlanLength();i++) {
			out_map<<plan[i]<<",";
		}
		out_map<<endl;

		count++;
	}
//	cout<<"DONE."<<endl;
}*/

Queries::Queries()
{
	queries = new vector<Query* >();

	//temp to fill the normalize list
	string names [] ={"degree4","authority4","pageRank1","eccentricity0","numTriangles0","closenessCentrality0","betweennessCentrality4","hub5","clusteringCoefficient2","weightedDegree3","qSelectivity0","qDegree2","eigenvectorCentrality0","degree5","pageRank0","eccentricity1","closenessCentrality1","betweennessCentrality5","hub3","hub4","clusteringCoefficient1","weightedDegree2","qSelectivity1","qDegree1","eigenvectorCentrality1","degree2","authority1","closenessCentrality2","hub2","clusteringCoefficient0","weightedDegree1","qDegree0","eigenvectorCentrality2","degree3","pageRank5","authority0","eccentricity4","numTriangles5","closenessCentrality4","closenessCentrality3","betweennessCentrality0","hub1","weightedDegree0","eigenvectorCentrality4","eigenvectorCentrality3","degree0","authority3","pageRank4","numTriangles3","eccentricity5","numTriangles4","closenessCentrality5","betweennessCentrality1","hub0","qSelectivity4","eigenvectorCentrality5","degree1","pageRank3","authority2","numTriangles2","eccentricity2","betweennessCentrality2","qSelectivity2","weightedDegree5","clusteringCoefficient5","qSelectivity5","qDegree5","pageRank2","authority5","numTriangles1","eccentricity3","betweennessCentrality3","clusteringCoefficient3","qSelectivity3","weightedDegree4","clusteringCoefficient4","qDegree3","qDegree4"};
	double divideBy [] = {9.92122,0.000503453,0.000472465,10,25,5.57921,12301.4,0.000503453,0.22181,13.1667,12519,4,0.0801155,13.1667,0.000472465,10,5.57921,12301.4,0.000503453,0.000503453,0.22181,13.1667,12519,5,0.0801155,13.1667,0.000503453,5.57921,0.000503453,0.22181,13.1667,5,0.0801155,13.1667,0.000472465,0.000503453,10,25,5.57921,5.57921,12301.4,0.000503453,13.1667,0.0801155,0.0801155,13.1667,0.000503453,0.000472465,25,10,25,5.57921,12301.4,0.000503453,12519,0.0801155,13.1667,0.000472465,0.000503453,25,10,12301.4,12519,13.1667,0.22181,12519,1,0.000472465,0.000503453,25,10,12301.4,0.22181,12519,13.1667,0.22181,3,2};
	for(int i=0;i<78;i++)
		this->tempNameToNormalizeValue.insert(std::pair<string, double>(names[i], divideBy[i]));
}

bool Queries::loadFromFile(string fileName)
{
	cout<<"Loading queries from file: "<<fileName<<endl;
	ifstream file (fileName.c_str(), ios::in);
	if(!file)
	{
		cout << "While opening a file an error is encountered" << endl;
		return false;
	}

	if(!parseData(file))
	{
		file.close();
		return false;
	}

	cout<<"#Queries: "<<queries->size()<<" loaded successfully."<<endl;

	file.close();
}

bool Queries::parseData(istream& data)
{
	GraphX* currentGraph = 0;

	while (true)
	{
		char ch;
		data>>ch;

		if(data.eof()) break;

		//graphs separator
		if(ch=='t')
		{
			if(currentGraph!=0)
			{
				Query* query = new Query(currentGraph);
				queries->push_back(query);
				queriesByID.insert(std::pair<int, Query*>(query->getID(), query));
			}

			data>>ch;
			int id;
			data>>id;
			currentGraph = new GraphX(id, 0);
		}
		//to add nodes
		else if(ch=='v')
		{
			int id;
			double label;
			data>>id;
			data>>label;
			currentGraph->AddNode(id, label);
		}
		//to add edges
		else if(ch=='e')
		{
			currentGraph->setNumNodesBeforeDeletingNodes(currentGraph->getNumOfNodes());
			int id1;
			int id2;
			double label;
			data>>id1;
			data>>id2;
			data>>label;
			currentGraph->addEdge(id1, id2, label);
		}
		else
		{
			cout<<"Error!";
			exit(0);
		}
	}

	if(currentGraph->getNumOfNodes()>0)
	{
		Query* query = new Query(currentGraph);
		queries->push_back(query);
		queriesByID.insert(std::pair<int, Query*>(query->getID(), query));
	}

	return true;
}

void Queries::exexuteQueries(GraphX* dataGraph)
{
	int totalNumResults = 0;

	for(int i=0;i<queries->size();i++)
	{
		Query* query = queries->at(i);

		TimeUtility::StartCounterMicro();

		//select the best node to start with
		int numNodes = query->getGraph()->getNumOfNodes();
		int bestNodeID = -1;
		double bestScore = 0;
		for(int j=0;j<numNodes;j++)
		{
			NodeX* node = query->getGraph()->getNodeWithID(j);
			double label = node->getLabel();
			int numNodesWithLabel = query->getGraph()->getNodeIDsByLabel(label)->size();
			int degree = node->getEdgesSize();

			double score = degree/((double)numNodesWithLabel);
			if(score>bestScore)
			{
				bestNodeID = node->getID();
				bestScore = score;
			}
		}

		vector<map<int, int>* > result;
		tr1::unordered_map<int, tr1::unordered_set<int>*> domains_values;
		query->getGraph()->isIsomorphic(dataGraph, result, domains_values, 0, bestNodeID, -1, false);

		long elapsedTime = TimeUtility::GetCounterMicro();

		cout<<"Query#"<<i<<", number of results = "<<result.size()<<". Time = "<<elapsedTime<<" microseconds"<<endl;
		totalTime+=elapsedTime;
		totalNumResults+=result.size();
	}

	cout<<"Total #results: "<<totalNumResults<<endl;
}

void Queries::discoverSlowestFastestPlans(GraphX* dataGraph)
{
	long* bestTime = new long[queries->size()];
	long* worstTime = new long[queries->size()];
	int** bestPlan = new int*[queries->size()];
	int** worstPlan = new int*[queries->size()];

	int totalBestTime = 0;
	int totalWorstTime = 0;

	for(int i=0;i<queries->size();i++)
	{
		Query* query = queries->at(i);
		vector<int* > plans = query->getPossiblePlans(-1, dataGraph);
		cout<<"Query#: "<<i<<" generated "<<plans.size()<<" plans."<<endl;
		cout<<"Query is: "<<(*query->getGraph())<<endl;

		bestTime[i] = 1000000;
		bestPlan[i] = 0;
		worstTime[i] = -1;
		worstPlan[i] = 0;

		int numResults=-1;//-1 to indicate it is not set yet

		for(int j=0;j<plans.size();j++)
		{
			int* plan = plans.at(j);

			TimeUtility::StartCounterMicro();

			vector<map<int, int>* > result;
			tr1::unordered_map<int, tr1::unordered_set<int>*> domains_values;

			//printing plan
//			cout<<"Plan: ";
//			for(int j=0;j<query->getGraph()->getNumOfNodes();j++)
//				cout<<plan[j]<<", ";
//			cout<<endl<<flush;

			query->getGraph()->isIsomorphic(dataGraph, result, domains_values, plan, -1, -1, false);

			long elapsedTime = TimeUtility::GetCounterMicro();

			//printing results
//			cout<<"result.size() = "<<result.size()<<endl;
//			for(int j=0;j<result.size();j++)
//			{
//				map<int, int>* m = result.at(j);
//				for(map<int, int>::iterator iter = m->begin();iter!=m->end();iter++)
//				{
//					cout<<iter->first<<":"<<iter->second<<", ";
//				}
//				cout<<endl;
//			}

			//printing elapsed time
			cout<<"elapsedtime = "<<elapsedTime<<endl;

			if(numResults==-1)
				numResults = result.size();
			else
			{
				if(numResults!=result.size())
				{
					cout<<"Error51110: numResults!=result.size() -> numResults = "<<numResults<<", result.size() = "<<result.size()<<endl;
					cout<<j;

					for(int j=0;j<plans.size();j++)
					{
						delete[] plans[j];
					}

					for(int j=0;j<result.size();j++)
					{
						delete result.at(j);
					}

					exit(0);
				}
			}


			for(int j=0;j<result.size();j++)
			{
				delete result.at(j);
			}

			if(elapsedTime<bestTime[i])
			{
				bestTime[i] = elapsedTime;
				bestPlan[i] = plan;
			}
			if(elapsedTime>worstTime[i])
			{
				worstTime[i] = elapsedTime;
				worstPlan[i] = plan;
			}
		}



		int* tempBestPlan = bestPlan[i];
		bestPlan[i] = new int[query->getGraph()->getNumOfNodes()];
		int* tempWorstPlan = worstPlan[i];
		worstPlan[i] = new int[query->getGraph()->getNumOfNodes()];
		for(int j=0;j<query->getGraph()->getNumOfNodes();j++)
		{
			bestPlan[i][j] = tempBestPlan[j];
			worstPlan[i][j] = tempWorstPlan[j];
		}

		query->setBestPlan(bestPlan[i]);
		query->setBestTime(bestTime[i]);
		query->setWorstPlan(worstPlan[i]);
		query->setWorstTime(worstTime[i]);

		for(int j=0;j<plans.size();j++)
		{
			delete[] plans[j];
		}

		cout<<"#results: "<<numResults<<endl;
		cout<<"Best time [micro seconds]: "<<bestTime[i];
		cout<<" for plan: ";
		for(int j=0;j<query->getGraph()->getNumOfNodes();j++)
			cout<<bestPlan[i][j]<<", ";
		cout<<endl;
		totalBestTime+=bestTime[i];

		cout<<"Worst time [microseconds]: "<<worstTime[i];
		cout<<" for plan: ";
		for(int j=0;j<query->getGraph()->getNumOfNodes();j++)
			cout<<worstPlan[i][j]<<", ";
		cout<<endl;
		totalWorstTime += worstTime[i];
	}

	cout<<endl;
	cout<<"Total best time (millis): "<<(totalBestTime/1000)<<endl;
	cout<<"Total worst time (millis): "<<(totalWorstTime/1000)<<endl;
	cout<<endl;

	//clear all
	delete[] bestTime;
	delete[] worstTime;
	for(int i=0;i<queries->size();i++)
	{
		delete[] bestPlan[i];
		delete[] worstPlan[i];
	}
	delete[] bestPlan;
	delete[] worstPlan;
}

/**
 * given the ste of queries, for each query generate all plans, execute them
 * then, get from 1 to n prefixes and show the statistics per query for how
 * much execution time varies when we fix a prefix of length L
 */
void Queries::discoverStatisticsOfPlans(GraphX* dataGraph)
{
	for(int i=0;i<queries->size();i++)
	{
		Query* query = queries->at(i);
		vector<int* > plans = query->getPossiblePlans(-1, dataGraph);
		cout<<"Query#: "<<i<<" generated "<<plans.size()<<" plans."<<endl;
		cout<<"Query is: "<<(*query->getGraph())<<endl;

		for(int j=0;j<plans.size();j++)
		{
			int* plan = plans.at(j);

			TimeUtility::StartCounterMicro();

			vector<map<int, int>* > result;
			tr1::unordered_map<int, tr1::unordered_set<int>*> domains_values;

			//printing plan
			for(int j=0;j<query->getGraph()->getNumOfNodes();j++)
				cout<<plan[j]<<", ";
			cout<<endl<<flush;

			query->getGraph()->isIsomorphic(dataGraph, result, domains_values, plan, -1, -1, false);

			long elapsedTime = TimeUtility::GetCounterMicro();

			//printing elapsed time
			cout<<"elapsedtime = "<<elapsedTime<<endl;

			for(int j=0;j<result.size();j++)
			{
				delete result.at(j);
			}
		}

		for(int j=0;j<plans.size();j++)
		{
			delete[] plans[j];
		}
	}
}

/**
 * discover all possible plans for the given queries
 * Output their features list along with elapsed time in the Wika format
 */
/*void Queries::discoverPlansAsFeatures(GraphX* dataGraph)
{
	vector<Features* > allFeatures;
	tr1::unordered_set<string> featuresNames;

	for(int i=0;i<queries->size();i++)
	{
		Query* query = queries->at(i);
		vector<int* > plans = query->getPossiblePlans(-1, dataGraph);
//		cout<<"Query#: "<<i<<" generated "<<plans.size()<<" plans."<<endl;
//		cout<<"Query is: "<<(*query->getGraph())<<endl;

		for(int j=0;j<plans.size();j++)
		{
			int* plan = plans.at(j);

			TimeUtility::StartCounterMicro();

			vector<map<int, int>* > result;
			tr1::unordered_map<int, tr1::unordered_set<int>*> domains_values;

			//printing plan
//			for(int j=0;j<query->getGraph()->getNumOfNodes();j++)
//				cout<<plan[j]<<", ";
//			cout<<endl<<flush;

			query->getGraph()->isIsomorphic(dataGraph, result, domains_values, plan, -1, -1, false);

			long elapsedTime = TimeUtility::GetCounterMicro();

			//given the plan and the subgraph, print the features representing them
			Features* fs = Features::generateFS_1(query->getGraph(), plan);
			allFeatures.push_back(fs);


			fs->addFeature("Time", elapsedTime);

			fs->addToFeaturesNames(featuresNames);

			//fs->print(cout);

			//printing elapsed time
			//cout<<"elapsedtime = "<<elapsedTime<<endl;
			//cout<<elapsedTime<<endl;

			for(int j=0;j<result.size();j++)
			{
				delete result.at(j);
			}
		}

//		for(int j=0;j<plans.size();j++)
//		{
//			delete[] plans[j];
//		}
	}

	//print in ARFF format
	ofstream out;
	out.open ("out.arff");

	ofstream queryMapping;
	queryMapping.open("out.map");

	printAsARFF(out, queryMapping, featuresNames, allFeatures);
}*/

/**
 * discover all possible plans for the given queries
 * Output their features list along with elapsed time in the Wika format using option 2 features
 */
/*void Queries::discoverPlansAsFeatures_2(GraphX* dataGraph)
{
	vector<Features* > allFeatures;
	tr1::unordered_set<string> featuresNames;

	for(int i=0;i<queries->size();i++)
	{
		if(i<500) continue;
//		if(i>=500) continue;
		cout<<i<<endl;
		Query* query = queries->at(i);
		vector<int* > plans = query->getPossiblePlans(-1, dataGraph);

		for(int j=0;j<plans.size();j++)
		{
			int* plan = plans.at(j);

			TimeUtility::StartCounterMicro();

			vector<map<int, int>* > result;
			tr1::unordered_map<int, tr1::unordered_set<int>*> domains_values;

			query->getGraph()->isIsomorphic(dataGraph, result, domains_values, plan, -1, -1, false);

			long elapsedTime = TimeUtility::GetCounterMicro();

			//given the plan and the subgraph, print the features representing them
			Features* fs = Features::generateFS_2(dataGraph, query->getGraph(), plan, -1);
			fs->setQueryRelatedData(query->getID(), plan, query->getGraph()->getNumOfNodes());

			//fs->normalize(this->tempNameToNormalizeValue);

			allFeatures.push_back(fs);

			fs->addFeature("Time", elapsedTime);

			fs->addToFeaturesNames(featuresNames);

			//fs->print(cout);
//			fs->printAsARFF(cout, dataGraph->getNumDistinctLabels());

			//printing elapsed time
			//cout<<"elapsedtime = "<<elapsedTime<<endl;
			//cout<<elapsedTime<<endl;

			for(int j=0;j<result.size();j++)
			{
				delete result.at(j);
			}
		}

//		for(int j=0;j<plans.size();j++)
//		{
//			delete[] plans[j];
//		}
	}

	//print in ARFF format
	ofstream featuresFile;
	featuresFile.open ("out_yeast100X_testing.csv");
	//featuresFile.open ("out_2.arff");

	ofstream queryMapping;
	queryMapping.open("out_yeast100X_testing.map");

	//printAsARFF(featuresFile, queryMapping, featuresNames, allFeatures);
	printAsFANNCSV(featuresFile, queryMapping, featuresNames, allFeatures, ',');
}*/

void Queries::createBestPlanIndex(char* fileName)
{
	ofstream myfile;
	myfile.open (fileName);

	//loop over queries
	for(int i=0;i<queries->size();i++)
	{
		Query* query = queries->at(i);
		myfile << (*query->getGraph());
		//output best plan
		int* bestPlan =  query->getBestPlan();
		for(int j=0;j<query->getGraph()->getNumOfNodes();j++)
			myfile<<bestPlan[j]<<",";
		myfile<<endl;
	}

	myfile.close();
}

void Queries::executeQueriesUsingMLResults(GraphX* dataGraph, string modelFile, string mapFile) {

	//load predicted execution times
	ifstream instTime;
	instTime.open(modelFile.c_str());//out_q3_testing.results");

	if(!instTime.good()) {
		cout<<"Could not open file"<<endl;
		return;
	}

	vector<double> predictedTimes;
	predictedTimes.push_back(0);

	string line;
	std::getline(instTime, line);

	char dummy;

	while(!instTime.eof()) {
		int inst;instTime>>inst;instTime>>dummy;
		double actual;instTime>>actual;instTime>>dummy;
		double predicted;instTime>>predicted;instTime>>dummy;
		double error;instTime>>error;

		predictedTimes.push_back(predicted);
	}

	//load query and plans, get the predicted times using the above data
	tr1::unordered_map<int, tr1::unordered_map<string, double>*> queryPlanTime;

	ifstream queryPlans;
	queryPlans.open(mapFile.c_str());
	while(!queryPlans.eof()) {
		int inst;queryPlans>>inst;
		int queryID;queryPlans>>queryID;

		int planLength = queriesByID.find(queryID)->second->getGraph()->getNumOfNodes();

		stringstream st;
		for(int i=0;i<planLength;i++) {
			int a;
			queryPlans>>a;
			st<<a<<",";
			queryPlans>>dummy;
		}

		tr1::unordered_map<int, tr1::unordered_map<string, double>*>::iterator iter = queryPlanTime.find(queryID);
		tr1::unordered_map<string, double>* planTime;
		if(iter==queryPlanTime.end()) {
			planTime = new tr1::unordered_map<string, double>();
			queryPlanTime.insert(std::pair<int, tr1::unordered_map<string, double>*>(queryID, planTime));
		}
		else
			planTime = iter->second;

		planTime->insert(std::pair<string, double>(st.str(), predictedTimes[inst]));
		if(inst==42436)
			cout<<inst<<endl;
	}

	cout<<"Loading precomputed files done."<<endl;

	long elapsedTime = 0;

	//execute queries using the predicted times for plans
	for(int i=0;i<queries->size();i++)
	{
		if(i<500) continue;
//		if(i>=500) continue;
		Query* query = queries->at(i);
		vector<int* > plans = query->getPossiblePlans(-1, dataGraph);

		tr1::unordered_map<int, tr1::unordered_map<string, double>*>::iterator iter = queryPlanTime.find(query->getID());
		tr1::unordered_map<string, double>* planTime;
		if(iter==queryPlanTime.end()) {
			cout<<"Error892849834234. queryID = "<<query->getID()<<endl;
			exit(0);
		}
		planTime = iter->second;

		double minPredcitedTime = 1000000;
		int* bestPlan = NULL;

		int planLength = query->getGraph()->getNumOfNodes();

		for(int j=0;j<plans.size();j++)
		{
			int* plan = plans.at(j);

			//get its signature
			stringstream st;
			for(int i=0;i<planLength;i++) {
				st<<plan[i]<<",";
			}

			//cout<<st.str()<<endl<<planTime->size()<<endl;
			double predictedTime = planTime->find(st.str())->second;
			if(minPredcitedTime>predictedTime) {
				minPredcitedTime = predictedTime;
				bestPlan = plan;
			}
		}

		cout<<"Best --> predicted time = "<<minPredcitedTime<<endl;
		for(int l = 0;l<query->getGraph()->getNumOfNodes();l++) {
			cout<<bestPlan[l]<<",";
		}
		cout<<endl;

		vector<map<int, int>* > result;
		tr1::unordered_map<int, tr1::unordered_set<int>*> domains_values;

		TimeUtility::StartCounterMicro();//StartCounterMill();
		query->getGraph()->isIsomorphic(dataGraph, result, domains_values, bestPlan, -1, -1, false);
		elapsedTime+=TimeUtility::GetCounterMicro();//GetCounterMill();

		cout<<i<<":"<<result.size()<<endl;

		for(int j=0;j<result.size();j++)
		{
			delete result.at(j);
		}
	}

	cout<<"Elapsed Time (microseconds) = "<<elapsedTime<<endl;
}

/**
 * load trained model, select execution plan for each query based on model predictions,
 * then execute the query using the predicted plan
 */
/*void Queries::executeQueriesUisngML(GraphX* graph, string modelFile) {

	struct fann *ann;

	ann =  fann_create_from_file(modelFile.c_str());

	//prepare query features
	tr1::unordered_set<string> featuresNames;

	ofstream dummyFile;
	dummyFile.open("dummy_removeme");

	long elapsedExecTime = 0;
	long elapsedPredictionTime = 0;
	long elapsedPlanGenTime = 0;
	long elapsedTestCasesGenTime = 0;

	bool featureNamesGenerated = false;

	for(int i=0;i<queries->size();i++)
	{
//		if(i<500) continue;
		cout<<"-->"<<i<<endl;
//		if(i>=501) break;
//		if(i>=500) continue;
		Query* query = queries->at(i);

		TimeUtility::StartCounterMicro();
		vector<int* > plans = query->getPossiblePlans(5, graph);
		elapsedPlanGenTime+=TimeUtility::GetCounterMicro();

		double minPredcitedTime = 10000000;
		int* bestPlan = NULL;

		int planLength = query->getGraph()->getNumOfNodes();

		//queryPlan<<plans.size()<<" 78 1"<<endl;

		TimeUtility::StartCounterMicro();

		//vector<Features* > allFeatures;

		for(int j=0;j<plans.size();j++)
		{
			//to select a random subset of the plans
			int* plan = plans.at(j);

			//preparing plan data

			TimeUtility::StartCounterMicro();

			Features* features = Features::generateFS_2(graph, query->getGraph(), plan, -1);

			if(!featureNamesGenerated) {
				features->addToFeaturesNames(featuresNames);
				featureNamesGenerated = true;
			}

			fann_type* fannF = features->getFeaturesAsFann(featuresNames);

			scale_fanns_using_factors(fannF, 24, 0, 1, 0, 70, 1, 0.014286);

			elapsedTestCasesGenTime+=(TimeUtility::GetCounterMicro());


			//conduct prediction
			TimeUtility::StartCounterMicro();

			fann_type* predictedTime;
			predictedTime = my_fann_run(ann, fannF);
			elapsedPredictionTime+=TimeUtility::GetCounterMicro();

//			cout<<"prediction: "<<predictedTime[0]<<endl;

			if(minPredcitedTime>predictedTime[0]) {
				minPredcitedTime = predictedTime[0];
				bestPlan = plan;
			}
		}

//		cout<<"Best --> predicted time = "<<minPredcitedTime<<endl;
//		for(int l = 0;l<query->getGraph()->getNumOfNodes();l++) {
//			cout<<bestPlan[l]<<",";
//		}
//		cout<<endl;

		vector<map<int, int>* > result;
		tr1::unordered_map<int, tr1::unordered_set<int>*> domains_values;

		TimeUtility::StartCounterMicro();
		query->getGraph()->isIsomorphic(graph, result, domains_values, bestPlan, -1, -1, false);
		long elapsedTemp = TimeUtility::GetCounterMicro();
		cout<<"Elapsed time for this query: "<<elapsedTemp<<endl;
		cout<<"Number of results for this query: "<<result.size()<<endl;
		elapsedExecTime+=elapsedTemp;

		for(int j=0;j<result.size();j++)
		{
			delete result.at(j);
		}
	}

	cout<<"Elapsed execution Time (microseconds) = "<<elapsedExecTime<<endl;
	cout<<"Elapsed prediction Time (microseconds) = "<<elapsedPredictionTime<<endl;
	cout<<"Elapsed plan generation Time (microseconds) = "<<elapsedPlanGenTime<<endl;
	cout<<"Elapsed test data generation Time (microseconds) = "<<elapsedTestCasesGenTime<<endl;
}*/

Queries::~Queries()
{
	for(int i=0;i<queries->size();i++)
	{
		delete queries->at(i);
	}

	delete queries;
}

