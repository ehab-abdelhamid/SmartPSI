/*
 * utils.h
 *
 *  Created on: Mar 19, 2013
 *      Author: ehab
 */

#ifndef UTILS_H_
#define UTILS_H_

#include<map>
#include<vector>
#include<string>
#include<sys/time.h>
#include <tr1/unordered_map>
#include"GraphX.h"

using namespace std;

string intToString(int a);
string doubleToString(double a);
int getPos(char* str, char c);
long long getmsofday();
char* getCmdOption(char ** begin, char ** end, const std::string & option);
bool cmdOptionExists(char** begin, char** end, const std::string& option);
int getNumElems(vector<map<string, void*>* >* );
int* selectGoodPlan(GraphX* , GraphX* , int );

class PlanTimesPair {
private:
	int planLength;
	int* plan;
	vector<long> time;
	long sig;

public:
	PlanTimesPair(int* plan, int planLength);
	void addTime(long t);
	long getSignature() {return sig;}
	long getMaxAcceptableTime();
	long getAvgAcceptableTime();
	long getTopPercentileTime(double percentile);
	static long getSignature(int* plan, int length);
	int getNUmberofTimes() { return time.size(); }
	int* getPlan() { return plan; }
};

class PlansStats {
private:
	tr1::unordered_map<long, PlanTimesPair* > plans;

public:
	void addPlan(int* plan, int length);
	void addTime(int* plan, int length, long time);
	long getMaxAcceptableTime(int* plan, int length);
	long getAvgAcceptableTime(int* plan, int length);
	long getAcceptableTime(int* plan, int length);
	int static getPlanNumber(vector<int*> plans, int length, int* plan);
	int* getMostPopularPlan();
};

#endif /* UTILS_H_ */
