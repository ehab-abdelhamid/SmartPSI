/*
 * Features.h
 *
 *  Created on: Sep 21, 2016
 *      Author: abdelhe
 */

#ifndef FEATURES_H_
#define FEATURES_H_

#include <string>
#include <tr1/unordered_map>
#include <set>
#include <vector>
#include "Feature.h"
#include "GraphX.h"
//#include "fann.h"

using namespace std;

class Features {
private:
	tr1::unordered_map<int, Feature* > fsList;
	vector<Feature*> fsListV;

	//data related to a query
	int queryID;
	int* plan;
	int planLength;
	double sumSquares = 0;

public:
	~Features();

	//add new features to the list of features
	void addFeature(Feature* feature);
	void addFeature(int name, double value);

	//sum to the values of the features list
	void addFeaturesValue(Features* , double mult = 1);
	void addFeatureValue(Feature* );
	void addFeatureValue(int name, double value);

	void setFeatures(Features* );

	Feature* getFeature(int name);
	Feature* getFeature_Sequential(int name);

	vector<Feature*>::iterator getVectorBegin() { return fsListV.begin(); }
	vector<Feature*>::iterator getVectorEnd() { return fsListV.end(); }

	//multiply all feature values by the given value
	void multiply(double v);
	void clear();

	void print(ostream& out);
	void printAsARFF(ostream& out, tr1::unordered_set<int>& names, int );
	void printAsFANNCSV(ostream& out, tr1::unordered_set<int>& names, char c, int& );
	void printAsCSV(ostream& out, tr1::unordered_set<int>& names, int& );

//	fann_type* getFeaturesAsFann(tr1::unordered_set<string>& names);

	//add features names to a list of features names
	void addToFeaturesNames(tr1::unordered_set<int>& names);

	void setQueryRelatedData(int qID, int* plan, int planLength);
	int getQueryID() { return queryID; }
	int* getPlan() { return plan; }
	int getPlanLength() { return planLength; }

	void normalize(tr1::unordered_map<int, double >& normalizeBy);

	double getSumOfSquares();
	double getCosineSimilarity(Features* );
	double isSatisfiedBy(Features* );
	double avgDifference(Features* );
	double minSatisfyingDifference(Features* );
	double maxSatisfyingDifference(Features* );
	double getHeighestSimilarity(tr1::unordered_map<string, void* >* );

	int getFeatuesSize() { return fsList.size(); }

	//generate query features based on neighborhods signatures
	//generate features based on the subgraph structure and the used execution plan order
	static Features* generateFS_1(GraphX* subgraph, int* plan);

	//generate features for a given node in a subgraph
	//this relies on the label signature of neighbor nodes
	static Features* generateFSForNode(GraphX* subgraph, int nodeID, int depth=-1);
	//***************************************************//

	//generate query features based on input graph stats and simple query structure info
	//generate features for the whole query
//	static Features* generateFS_2(GraphX* graph, GraphX* subgraph, int* plan, int maxNumNodes);
	//generate features of a given node given a subgraph and the input graph
//	static Features* generateFSForNode_2(GraphX* graph, GraphX* subgraph, int nodeID, int nodeOrder);
};



#endif /* FEATURES_H_ */
