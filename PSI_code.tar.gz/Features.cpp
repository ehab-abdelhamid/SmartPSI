/*
 * Features.cpp
 *
 *  Created on: Sep 27, 2016
 *      Author: abdelhe
 */

#include <iostream>
#include <tr1/unordered_set>
#include <sstream>
#include <math.h>
#include "Features.h"

void Features::addFeature(Feature* feature) {
	//remove me!
//	int name = feature->getName();
//	if(name!=6 && name!=11 && name!=12 && name!=13 && name!=14 && name!=16 && name!=17)
//		return;

	fsList.insert(std::make_pair<int,Feature* >(feature->getName(),feature));
//	fsListV.push_back(feature);
	vector<Feature*>::iterator iter = fsListV.begin();
	for(;iter!=fsListV.end();iter++) {
		if(feature->getName()<(*iter)->getName())
			break;
	}
	fsListV.insert(iter, feature);
	sumSquares = 0;
}

void Features::addFeature(int name, double value) {
	Feature* f = new Feature(name, value);
	addFeature(f);
}

void Features::clear() {
	for(vector<Feature*>::iterator iter = fsListV.begin();iter!=fsListV.end();iter++) {
		delete (*iter);
	}
	fsList.clear();
	fsListV.clear();
	sumSquares = 0;
}

Feature* Features::getFeature(int name) {
	tr1::unordered_map<int, Feature* >::iterator iter = fsList.find(name);
	if(iter==fsList.end())
		return NULL;
	return iter->second;
}

Feature* Features::getFeature_Sequential(int name) {
	for(vector<Feature* >::iterator iter = fsListV.begin();iter!=fsListV.end();iter++) {
		if((*iter)->getName()==name)
			return *iter;
	}
	return NULL;
}

void Features::multiply(double v) {
	tr1::unordered_map<int, Feature* >::iterator iter = fsList.begin();
	for(;iter!=fsList.end();iter++) {
		Feature* f = iter->second;
		double value = f->getValue()*v;
		f->updateValue(value);
	}
}

//void Features::addFeaturesValue(Features* fs) {
//	tr1::unordered_map<string, Feature* >::iterator iter = fs->fsList.begin();
//	for(;iter!=fs->fsList.end();iter++) {
//		Feature* f = iter->second;
//		addFeatureValue(f);
//	}
//}
void Features::addFeaturesValue(Features* fs, double mult) {

	for(vector<Feature*>::iterator iter = fs->getVectorBegin();iter!=fs->getVectorEnd();iter++) {
//	tr1::unordered_map<string, Feature* >::iterator iter = fs->fsList.begin();
//	for(;iter!=fs->fsList.end();iter++) {
		Feature* f = *iter;
//		Feature* f = iter->second;
		addFeatureValue(f->getName(), f->getValue()*mult);

	}
}

void Features::addFeatureValue(Feature* f) {
	Feature* existingF = this->getFeature(f->getName());
	if(existingF!=NULL) {
		existingF->updateValue(existingF->getValue()+f->getValue());
	} else {
		this->addFeature(f->getName(), f->getValue());
	}
}

void Features::addFeatureValue(int name, double value) {
	Feature* existingF = this->getFeature(name);
	if(existingF!=NULL) {
		existingF->updateValue(existingF->getValue()+value);
	} else {
		this->addFeature(name, value);
	}
}

/**
 * set 'this' features list to the given ones, without checking for existence
 */
void Features::setFeatures(Features* fs) {
	this->clear();

	for(vector<Feature*>::iterator iter = fs->getVectorBegin();iter!=fs->getVectorEnd();iter++) {
		Feature* f = *iter;
		Feature* newF = new Feature(f->getName(), f->getValue());
		fsList.insert(std::make_pair<int,Feature* >(newF->getName(),newF));
		fsListV.push_back(newF);
	}
}

void Features::print(ostream& out) {
	tr1::unordered_map<int, Feature* >::iterator iter = fsList.begin();
	for(;iter!=fsList.end();iter++) {
		Feature* f = iter->second;
		f->print(out);
		out<<",";
	}
}

void Features::addToFeaturesNames(tr1::unordered_set<int>& names) {

	tr1::unordered_map<int, Feature* >::iterator iter = fsList.begin();
	for(;iter!=fsList.end();iter++) {
		int name = iter->first;
		names.insert(name);
	}
}

void Features::setQueryRelatedData(int qID, int* plan, int planLength) {
	this->queryID = qID;
	this->plan = plan;
	this->planLength = planLength;
}

/**
 * feature weights are printed in the order given by names
 */
void Features::printAsARFF(ostream& out, tr1::unordered_set<int>& names, int lastColumn) {

	/*out<<"@Regression data"<<endl;
	for(int i=0;i<=max;i++) {
		out<<"@ATTRIBUTE "<<i<<" NUMERIC"<<endl;
	}
	out<<"@ATTRIBUTE TIME NUMERIC"<<endl;

	out<<endl;
	out<<"@DATA"<<endl;*/

	tr1::unordered_set<int>::iterator iter = names.begin();
	for(;iter!=names.end();iter++) {
		int labelStr = *iter;

		if(labelStr==lastColumn) continue;

		Feature* f = this->getFeature(labelStr);
		double value = 0;
		if(f!=NULL)
			value = f->getValue();

		out<<value<<",";
	}

	Feature* f = this->getFeature(lastColumn);
	double time = -1;
	if(f!=NULL)
		time = f->getValue();
	out<<time;
}

/**
 * feature weights are printed in the order given by names
 */
void Features::printAsFANNCSV(ostream& out, tr1::unordered_set<int>& names, char c, int& str) {//it was "Time"

	tr1::unordered_set<int>::iterator iter = names.begin();
	for(;iter!=names.end();iter++) {
		int labelStr = *iter;

		//check if we need to ignore this feature
		/*bool ignore = false;
		string ignoreNames[] = {"betweennessCentrality", "closenessCentrality", "eigenvectorCentrality", "eccentricity", "qSelectivity",
		"authority", "degree", "hub", "pageRank"};
		for(int l=0;l<9;l++) {
			if(labelStr.find(ignoreNames[l])==0) {
				ignore = true;
				break;
			}
		}
		if(ignore) continue;*/

		if(labelStr==str) continue;

		Feature* f = this->getFeature(labelStr);
		double value = 0;
		if(f!=NULL)
			value = f->getValue();

		out<<value<<c;//this was multiplied by 10000
	}

	out<<endl;

	Feature* feature = this->getFeature(str);
	if(feature==NULL)
		out<<"-1";
	else
		out<<feature->getValue();
}

/**
 * feature weights are printed in the order given by names
 */
void Features::printAsCSV(ostream& out, tr1::unordered_set<int>& names, int& str) {

	tr1::unordered_set<int>::iterator iter = names.begin();
	for(;iter!=names.end();iter++) {
		int labelStr = *iter;

		if(labelStr==str) continue;

		Feature* f = this->getFeature(labelStr);
		double value = 0;
		if(f!=NULL)
			value = f->getValue();

		out<<value<<",";//this was multiplied by 10000
	}

	Feature* feature = this->getFeature(str);
	if(feature==NULL)
		out<<"-1";
	else
		out<<feature->getValue();
}

/*fann_type* Features::getFeaturesAsFann(tr1::unordered_set<string>& names) {
	fann_type* fanns = new fann_type[names.size()-1];

	int index = 0;
	tr1::unordered_set<string>::iterator iter = names.begin();
	for(;iter!=names.end();iter++) {
		string labelStr = *iter;

		bool ignore = false;
		string ignoreNames[] = {"betweennessCentrality", "closenessCentrality", "eigenvectorCentrality", "eccentricity", "qSelectivity",
		"authority", "degree", "hub", "pageRank"};
		for(int l=0;l<9;l++) {
			if(labelStr.find(ignoreNames[l])==0) {
				ignore = true;
				break;
			}
		}
		if(ignore) continue;

		if(labelStr.compare("Time")==0) continue;

		Feature* f = this->getFeature(labelStr);
		double value = 0;
		if(f!=NULL)
			fanns[index] = (f->getValue());//*10000);
		index++;
	}

	return fanns;
}*/


Features* Features::generateFS_1(GraphX* subgraph, int* plan) {
	Features* fs = new Features();

	//go over subgraph nodes ordered according to the plan
	for(int i=0;i<subgraph->getNumOfNodes();i++) {
		int currNodeID = plan[i];

		//get the features of a node
		Features* nodeFS = generateFSForNode(subgraph, currNodeID);
		//nodeFS->print(cout);

		double multiplyBy = 1.0/(i+1);
		nodeFS->multiply(multiplyBy);

		//add the generated feature of a node to the cumulative features vector
		fs->addFeaturesValue(nodeFS);
	}

	return fs;
}

Features* Features::generateFSForNode(GraphX* subgraph, int nodeID, int depth) {
	Features* fs = new Features();

	//used list for iterations
	tr1::unordered_set<int> visited;
	vector<int> toBeVisitedNodeID;
	vector<double> toBeVisitedWeight;

	toBeVisitedNodeID.push_back(nodeID);
	toBeVisitedWeight.push_back(1);

	while(toBeVisitedNodeID.size()>0) {
//		cout<<toBeVisitedNodeID.size()<<endl;
		//get the to be visited node and its weight
		int nodeID = (*toBeVisitedNodeID.begin());
		toBeVisitedNodeID.erase(toBeVisitedNodeID.begin());
		double weight = (*toBeVisitedWeight.begin());
		toBeVisitedWeight.erase(toBeVisitedWeight.begin());

		if(depth>-1 && (1.0/pow (2.0, depth))>=weight)
			continue;

		//check with visited, if not found proceed
		if(visited.find(nodeID)!=visited.end())
			continue;
		visited.insert(nodeID);

		//add to the features list
		NodeX* node = subgraph->getNodeWithID(nodeID);
		int labelStr = node->getLabel();//getLabelStr();
		//Feature* f = new Feature(labelStr, weight);
		//fs->addFeatureValue(f);
		fs->addFeatureValue(labelStr, weight);
		//delete f;

		//get its neighbors
		for(map<int, void*>::iterator iter = node->getEdgesIterator();iter!=node->getEdgesEndIterator();++iter)
		{
			int id = iter->first;
			if(visited.find(id)!=visited.end())
				continue;

			if((1.0/pow (2.0, depth))<(weight/2))
			{
				toBeVisitedNodeID.push_back(id);
				toBeVisitedWeight.push_back(weight/2);
			}
		}
	}

	return fs;
}

/**
 * Improve peformance by improving generateFSForNode_2. check it, it is obvious!
 */
/*Features* Features::generateFS_2(GraphX* graph, GraphX* subgraph, int* plan, int maxNumNodes) {
	Features* fs = new Features();

	int numNodes = subgraph->getNumOfNodes();
	if(maxNumNodes!=-1)
		numNodes = maxNumNodes;

	//go over subgraph nodes ordered according to the plan
	for(int i=0;i<numNodes;i++) {
		int currNodeID = plan[i];

		//get the features of a node
		Features* nodeFS = generateFSForNode_2(graph, subgraph, currNodeID, i);

		//add the generated feature of a node to the cumulative features vector
		fs->addFeaturesValue(nodeFS);
	}

	return fs;
}*/

/*Features* Features::generateFSForNode_2(GraphX* graph, GraphX* subgraph, int nodeID, int nodeOrder) {
	Features* fs = new Features();

	//features order as follows:
	//Input graph related (average across all nodes with the same label):
	//degree;weightedDegree;eccentricity;closenessCentrality;betweennessCentrality;authority;hub;pageRank;clusteringCoefficient;numTriangles;eigenvectorCentrality;
	//Subgraph related:
	//degree;selectivity

	NodeX* node = subgraph->getNodeWithID(nodeID);
	double label = node->getLabel();

	NodeStats* nodeStats = graph->getAvgNodeStats(label);

	//input graph related
	double avgDegree = nodeStats->degree;
	double avgWeightedDegree = nodeStats->weightedDegree;
	double avgEccentricity = nodeStats->eccentricity;
	double avgClosenessCentrality = nodeStats->closenessCentrality;
	double avgBetweennessCentrality = nodeStats->betweennessCentrality;
	double avgAuthority = nodeStats->authority;
	double avgHub = nodeStats->hub;
	double avgPageRank = nodeStats->pageRank;
	double avgClusteringCoefficient = nodeStats->clusteringCoefficient;
	double avgNumTriangles = nodeStats->numTriangles;
	double avgEigenvectorCentrality = nodeStats->eigenvectorCentrality;
//	set<int>* nodes = graph->getNodesByLabel(label);
//	if(nodes!=NULL) {
//		set<int>::iterator iter = nodes->begin();
//		for(;iter!=nodes->end();iter++) {
//			int tempNodeID = (*iter);
//			NodeX* tempNode = graph->getNodeWithID(tempNodeID);
//			NodeStats* nodeStats = tempNode->getNodeStats();
//
//			avgDegree += nodeStats->degree;
//			avgWeightedDegree += nodeStats->weightedDegree;
//			avgEccentricity += nodeStats->eccentricity;
//			avgClosenessCentrality += nodeStats->closenessCentrality;
//			avgBetweennessCentrality += nodeStats->betweennessCentrality;
//			avgAuthority += nodeStats->authority;
//			avgHub += nodeStats->hub;
//			avgPageRank += nodeStats->pageRank;
//			avgClusteringCoefficient += nodeStats->clusteringCoefficient;
//			avgNumTriangles += nodeStats->numTriangles;
//			avgEigenvectorCentrality += nodeStats->eigenvectorCentrality;
//		}
//	}

	std::ostringstream oss;
//	if(nodes!=NULL)
//		avgDegree /= nodes->size();
	oss << "degree" << nodeOrder;
	fs->addFeature(oss.str(), avgDegree);
	oss.str(std::string());

//	if(nodes!=NULL)
//		avgWeightedDegree /= nodes->size();
	oss << "weightedDegree" << nodeOrder;
	fs->addFeature(oss.str(), avgWeightedDegree);
	oss.str(std::string());

//	if(nodes!=NULL)
//		avgEccentricity /= nodes->size();
	oss << "eccentricity" << nodeOrder;
	fs->addFeature(oss.str(), avgEccentricity);
	oss.str(std::string());

//	if(nodes!=NULL)
//		avgClosenessCentrality /= nodes->size();
	oss << "closenessCentrality" << nodeOrder;
	fs->addFeature(oss.str(), avgClosenessCentrality);
	oss.str(std::string());

//	if(nodes!=NULL)
//		avgBetweennessCentrality /= nodes->size();
	oss << "betweennessCentrality" << nodeOrder;
	fs->addFeature(oss.str(), avgBetweennessCentrality);
	oss.str(std::string());

//	if(nodes!=NULL)
//		avgAuthority /= nodes->size();
	oss << "authority" << nodeOrder;
	fs->addFeature(oss.str(), avgAuthority);
	oss.str(std::string());

//	if(nodes!=NULL)
//		avgHub /= nodes->size();
	oss << "hub" << nodeOrder;
	fs->addFeature(oss.str(), avgHub);
	oss.str(std::string());

//	if(nodes!=NULL)
//		avgPageRank /= nodes->size();
	oss << "pageRank" << nodeOrder;
	fs->addFeature(oss.str(), avgPageRank);
	oss.str(std::string());

//	if(nodes!=NULL)
//		avgClusteringCoefficient /= nodes->size();
	oss << "clusteringCoefficient" << nodeOrder;
	fs->addFeature(oss.str(), avgClusteringCoefficient);
	oss.str(std::string());

//	if(nodes!=NULL)
//		avgNumTriangles /= nodes->size();
	oss << "numTriangles" << nodeOrder;
	fs->addFeature(oss.str(), avgNumTriangles);
	oss.str(std::string());

//	if(nodes!=NULL)
//		avgEigenvectorCentrality /= nodes->size();
	oss << "eigenvectorCentrality" << nodeOrder;
	fs->addFeature(oss.str(), avgEigenvectorCentrality);
	oss.str(std::string());

	//query related features
	//query node degree
	int qDegree = node->getEdgesSize();
	oss << "qDegree" << nodeOrder;
	fs->addFeature(oss.str(), qDegree);
	oss.str(std::string());

	//minimum selectivity of neighbor edges
	double minSelect = graph->getNumOfEdges();
	for(map<int, void*>::iterator iter = node->getEdgesIterator();iter!=node->getEdgesEndIterator();++iter)
	{
		int otherNodeID = iter->first;
		double otherNodeLabel = subgraph->getNodeWithID(otherNodeID)->getLabel();

		std::ostringstream key;
		if(label<otherNodeLabel)
			key<<label<<"_"<<otherNodeLabel;
		else
			key<<otherNodeLabel<<"_"<<label;

		tr1::unordered_map<string, int >* edgesCount = graph->getEdgesCount();
		tr1::unordered_map<string, int >::iterator searchIter = edgesCount->find(key.str());

		if(searchIter==edgesCount->end())
		{
			continue;
		}

		if(minSelect>searchIter->second)
		{
			minSelect = searchIter->second;
		}
	}
	oss << "qSelectivity" << nodeOrder;
	fs->addFeature(oss.str(), minSelect);
	oss.str(std::string());

	return fs;
}*/

void Features::normalize(tr1::unordered_map<int, double >& normalizeBy) {

	for(tr1::unordered_map<int, Feature* >::iterator iter = fsList.begin();iter!=fsList.end();iter++) {
		int name = iter->first;
		double divideBy = normalizeBy.find(name)->second;

		Feature* feature = iter->second;
		feature->updateValue(feature->getValue()/divideBy);
	}
}

double Features::isSatisfiedBy(Features* fs) {

	if(fsList.size()>fs->getFeatuesSize())
		return -1;

	double score = 0;

	for(vector<Feature*>::iterator iter = fsListV.begin();iter!=fsListV.end();iter++) {

		int name = (*iter)->getName();

		Feature* f;
		if(fs->getFeatuesSize()<10)
			f = fs->getFeature_Sequential(name);
		else
			 f = fs->getFeature(name);

		if(f==NULL)
			return -1;

		double value = (*iter)->getValue();
		if(f->getValue()<value)
			return -1;
		else
			score+=(f->getValue()-value);
	}

	return score;
}

double Features::avgDifference(Features* fs) {

	if(fsList.size()>fs->getFeatuesSize())
		return -1;

	double score = 0;

	for(vector<Feature*>::iterator iter = fsListV.begin();iter!=fsListV.end();iter++) {

		int name = (*iter)->getName();

		Feature* f;
		if(fs->getFeatuesSize()<10)
			f = fs->getFeature_Sequential(name);
		else
			 f = fs->getFeature(name);

		if(f==NULL)
			return -1;

		double value = (*iter)->getValue();
		if(f->getValue()<value)
			return -1;
		else
			score+=(f->getValue()/value);
	}

	return score/fsListV.size();
}

/**
 * returns the minimum value diferrence between corresponding features (difference is done by division)
 */
double Features::minSatisfyingDifference(Features* fs) {

	if(fsList.size()>fs->getFeatuesSize())
		return -1;

	double score = 10000000;//this was wrong, it was set to 0

	for(vector<Feature*>::iterator iter = fsListV.begin();iter!=fsListV.end();iter++) {
		int name = (*iter)->getName();

		Feature* f;
		if(fs->getFeatuesSize()<10)
			f = fs->getFeature_Sequential(name);
		else
			 f = fs->getFeature(name);

		if(f==NULL)
			return -1;

		double value = (*iter)->getValue();
		if(f->getValue()<value)
			return -1;
		else {
			if(score>(f->getValue()/value)) score=(f->getValue()/value);//this was wrong by using - instead of / in the if condition
		}
	}

	return score;
}

/**
 * returns the maximum value diferrence between corresponding features (difference is done by division)
 */
double Features::maxSatisfyingDifference(Features* fs) {

	if(fsList.size()>fs->getFeatuesSize())
		return -1;

	double score = 0;//this was wrong, it was set to 0

	for(vector<Feature*>::iterator iter = fsListV.begin();iter!=fsListV.end();iter++) {
		int name = (*iter)->getName();

		Feature* f;
		if(fs->getFeatuesSize()<10)
			f = fs->getFeature_Sequential(name);
		else
			 f = fs->getFeature(name);

		if(f==NULL)
			return -1;

		double value = (*iter)->getValue();
		if(f->getValue()<value)
			return -1;
		else {
			if(score<(f->getValue()/value)) score=(f->getValue()/value);//this was wrong by using - instead of / in the if condition
		}
	}

	return score;
}

double Features::getSumOfSquares() {
	if(sumSquares==0)
	{
		for(vector<Feature*>::iterator ii=fsListV.begin(); ii!=fsListV.end(); ++ii)
		{
			double v = (*ii)->getValue();
			sumSquares+=(v * v);
		}
	}
	return sumSquares;
}

double Features::getCosineSimilarity(Features* fs) {
	//cosine similarity = A*B/(|A|*|B|)
	//get |A|
	double IAI = this->getSumOfSquares();
	IAI = sqrt(IAI);

	//get |B|
	double IBI = fs->getSumOfSquares();
	IBI = sqrt(IBI);

	//get A*B
	double sum = 0;
	for(tr1::unordered_map<int, Feature* >::iterator ii=fsList.begin(); ii!=fsList.end(); ++ii)
	{
		int key = ii->first;
		double weight1 = ii->second->getValue();
		//get the other weight
		double weight2 = 0;
		Feature* ff = fs->getFeature(key);
		if(ff!=NULL)
			weight2 = ff->getValue();
		sum += weight1*weight2;
	}

	//get the cosine similarity value
	return sum/(IAI*IBI);
}

double Features::getHeighestSimilarity(tr1::unordered_map<string, void* >* nodesFeatures) {
	double maxSim = 0;
	int maxIndex = -1;
	int counter = 0;
	for(tr1::unordered_map<string, void* >::iterator iter = nodesFeatures->begin(); iter!=nodesFeatures->end();iter++)
	{
		double tempSim = this->getCosineSimilarity(((Features*)iter->second));
		if(tempSim>maxSim) {
			maxSim = tempSim;
			maxIndex = counter;
		}
		counter++;
	}
//	cout<<"maxIndex = "<<maxIndex<<endl;
	return maxSim;
}

Features::~Features()
{
	for(vector<Feature*>::iterator iter = fsListV.begin();iter!=fsListV.end();iter++) {
		delete (*iter);
	}
}
