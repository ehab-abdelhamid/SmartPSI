/*
 * FastExistenceList.cpp
 *
 *  Created on: Oct 26, 2016
 *      Author: abdelhe
 */

#include<iostream>
#include <stdlib.h>
#include "FastExistenceList.h"

FastExistenceList::FastExistenceList(int size) {
	this->size = size;
	list = new NodeX*[size];
	pos = 0;
}

/**
 * check for the existence of an element a
 * returns true if exists, otherwise return false
 */
bool FastExistenceList::exists(NodeX* a){
	for(int i=0;i<pos;i++) {
		if(list[i]->getID()==a->getID())
			return true;
	}
	return false;
}

/**
 * Add an element a it pos to the list, then increase pos
 * if pos equals the max size, then try adding at a position where NULL exists
 * [WE ASSUME NO NEGATIVE VALUES ARE ALLOWED]
 */
void FastExistenceList::add(NodeX* a) {
	if(pos<size) {
		list[pos] = a;
		pos++;
	}
	else
	{
		pos = 0;
		while(pos<size && list[pos]!=NULL)
			pos++;
		if(pos>size) {
			cout<<"ERR2362673"<<endl;
			exit(0);
		}
		list[pos] = a;
		pos = size;
	}
//	cout<<"["<<a->getID()<<"]Added!"<<endl;
//	this->print();cout<<endl;
}

void FastExistenceList::remove(NodeX* a) {
//	cout<<"removed!"<<a->getID();
	for(int i=0;i<pos;i++) {
		if(list[i]->getID()==a->getID()) {
			list[i] = NULL;
			if(i==pos-1) pos--;
			return;
		}
	}
}

void FastExistenceList::clear() {
//	cout<<"cleared!";
	pos = 0;
}

void FastExistenceList::print() {
	for(int i=0;i<pos;i++)
		std::cout<<list[i]->getID()<<",";
}

FastExistenceList::~FastExistenceList() {
	delete[] list;
}
